export type UserRole = 'user' | 'admin' | 'instructor';

export type JLPTLevel = 'N5' | 'N4' | 'N3' | 'N2' | 'N1';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  passwordSalt: string;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
  resetToken?: string;
  resetTokenExpiry?: string;
}

export interface UserProfile {
  userId: string;
  displayName: string;
  nativeLanguage: string;
  targetLevel: JLPTLevel;
  dailyGoalMinutes: number;
  bio?: string;
  avatarSeed?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserProgress {
  userId: string;
  currentLevel: JLPTLevel;
  currentCourseId?: string;
  currentModuleId?: string;
  currentLessonId?: string;
  completedLessonIds: string[];
  totalStudyMinutes: number;
  currentStreak: number;
  longestStreak: number;
  lastActiveDate: string; // YYYY-MM-DD
  experiencePoints: number;
  updatedAt: string;
}

export interface Course {
  id: string;
  title: string;
  titleJa: string;
  description: string;
  level: JLPTLevel;
  order: number;
  isPublished: boolean;
  estimatedHours: number;
  coverImage?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Module {
  id: string;
  courseId: string;
  title: string;
  titleJa?: string;
  description: string;
  order: number;
  level: JLPTLevel;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export type LessonItemType = 'vocabulary' | 'grammar' | 'kanji' | 'reading' | 'listening' | 'conversation';

export interface VocabularyItem {
  id: string;
  japanese: string;
  furigana?: string;
  romaji: string;
  english: string;
  banglaMeaning?: string;
  partOfSpeech: string;
  level: JLPTLevel;
  exampleSentenceJa: string;
  exampleSentenceEn: string;
  exampleFurigana?: string;
  audioText?: string;
  audioUrl?: string;
  notes?: string;
  sourceDerived?: boolean;
  sourcePage?: number;
}

export interface GrammarItem {
  id: string;
  title: string;
  titleJa: string;
  structure: string;
  meaning: string;
  explanation: string;
  level: JLPTLevel;
  examples: {
    japanese: string;
    english: string;
    furigana?: string;
    breakdown?: string;
  }[];
  cautionNotes?: string;
}

export interface KanjiItem {
  id: string;
  character: string;
  meaning: string;
  onyomi: string[];
  kunyomi: string[];
  strokes: number;
  radicals: string;
  level: JLPTLevel;
  examples: {
    word: string;
    reading: string;
    meaning: string;
  }[];
}

export interface LessonDialogue {
  speaker: string;
  speakerRole?: string;
  japanese: string;
  furigana?: string;
  english: string;
}

export interface LessonPracticeExercise {
  id: string;
  instruction: string;
  questionJa: string;
  hint?: string;
  type: 'fill_blank' | 'order_words' | 'translate' | 'multiple_choice';
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface Lesson {
  id: string;
  moduleId: string;
  courseId: string;
  level: JLPTLevel;
  lessonNumber: number;
  title: string;
  titleJa: string;
  summary: string;
  explanation: string;
  isPublished: boolean;
  estimatedMinutes: number;
  
  // Rich embedded learning contents
  vocabulary: VocabularyItem[];
  grammar: GrammarItem[];
  kanji: KanjiItem[];
  dialogue?: LessonDialogue[];
  practiceExercises: LessonPracticeExercise[];
  quizId?: string;
  
  createdAt: string;
  updatedAt: string;
}

export type QuestionType =
  | 'multiple_choice'
  | 'ja_to_en'
  | 'en_to_ja'
  | 'vocab_recognition'
  | 'grammar_selection'
  | 'kanji_reading'
  | 'listening_selection';

export interface QuizQuestion {
  id: string;
  question: string;
  questionJa?: string;
  furigana?: string;
  audioText?: string;
  type: QuestionType;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  lessonId?: string;
  courseId?: string;
  level: JLPTLevel;
  title: string;
  description: string;
  passingScore: number; // percentage e.g. 70
  questions: QuizQuestion[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  quizId: string;
  lessonId?: string;
  level: JLPTLevel;
  score: number; // percentage 0 - 100
  totalQuestions: number;
  correctCount: number;
  answers: {
    questionId: string;
    selectedIndex: number;
    isCorrect: boolean;
  }[];
  passed: boolean;
  createdAt: string;
}

export type WorkJapaneseCategory =
  | 'Keigo'
  | 'Business Conversation'
  | 'Email Japanese'
  | 'Telephone Japanese'
  | 'Customer Service'
  | 'Hotel Japanese'
  | 'Workplace Communication';

export interface WorkJapaneseItem {
  id: string;
  category: WorkJapaneseCategory;
  title: string;
  titleJa: string;
  scenario: string;
  level: 'N5' | 'N4' | 'N3' | 'All';
  description: string;
  keyPhrases: {
    japanese: string;
    furigana?: string;
    politeLevel: 'Sonkeigo' | 'Kenjougo' | 'Teineigo' | 'Standard';
    english: string;
    usageContext: string;
  }[];
  dialogue: {
    speaker: string;
    role: string;
    japanese: string;
    furigana?: string;
    english: string;
    notes?: string;
  }[];
  culturalTips: string[];
  exercises: LessonPracticeExercise[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AISessionMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  mode: 'conversation' | 'grammar_explanation' | 'vocabulary_explanation' | 'correction' | 'translation';
  correctionData?: {
    userSentence: string;
    correctSentence: string;
    whyIncorrect: string;
    naturalAlternative: string;
  };
  timestamp: string;
}

export interface AISession {
  id: string;
  userId: string;
  mode: string;
  title: string;
  messages: AISessionMessage[];
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// RECURRING REVENUE & SUBSCRIPTION ENGINE
// ==========================================

export type PlanId = 'free' | 'starter' | 'pro' | 'japan_ready' | 'n5_pro' | 'n5_lifetime' | 'lifetime';

export type BillingInterval = 'monthly' | 'yearly';

export type SubscriptionStatus =
  | 'trialing'
  | 'active'
  | 'past_due'
  | 'paused'
  | 'cancelled'
  | 'expired';

export type PaymentStatus =
  | 'initiated'
  | 'pending'
  | 'paid'
  | 'failed'
  | 'cancelled'
  | 'refunded';

export type PaymentProviderType = 'bkash' | 'nagad' | 'sslcommerz' | 'shurjopay' | 'stripe' | 'apple_pay' | 'google_pay' | 'manual';

export type InvoiceStatus = 'paid' | 'open' | 'void' | 'uncollectible';

export type EntitlementFeature =
  | 'n5'
  | 'n4'
  | 'n3'
  | 'ai_coach'
  | 'business_japanese'
  | 'jlpt_pro'
  | 'japan_ready'
  | 'quizzes'
  | 'certificates'
  | 'priority_ai';

export interface PlanPrice {
  id: string;
  planId: PlanId;
  billingInterval: BillingInterval;
  amount: number; // In BDT ৳
  currency: 'BDT';
  savingsPercent?: number; // e.g. 30%
  savingsAmount?: number; // e.g. 2198 ৳
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Plan {
  id: PlanId;
  name: string;
  displayNameJa?: string;
  tagline: string;
  description: string;
  badge?: string; // 'Recommended' | 'Best Value' | 'Most Popular'
  isRecommended?: boolean;
  order: number;
  monthlyPrice: number; // 0, 299, 599, 999
  yearlyPrice: number; // 0, 2490, 4990, 8490
  currency: 'BDT';
  aiMonthlyLimit: number; // Free: 10, Starter: 100, Pro: 1000 (fair use), Japan Ready: 3000
  features: string[];
  entitlements: EntitlementFeature[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Subscription {
  id: string; // sub-...
  userId: string;
  planId: PlanId;
  billingInterval: BillingInterval;
  status: SubscriptionStatus;
  currentPeriodStart: string; // ISO
  currentPeriodEnd: string; // ISO
  trialStart?: string;
  trialEnd?: string;
  cancelAtPeriodEnd: boolean;
  cancelledAt?: string;
  pausedAt?: string;
  expiredAt?: string;
  paymentMethod?: string; // 'bKash' | 'SSLCommerz' | 'Card' | 'Manual'
  lastPaymentId?: string;
  gracePeriodEnd?: string; // for past_due dunning
  createdAt: string;
  updatedAt: string;
}

export interface SubscriptionItem {
  id: string;
  subscriptionId: string;
  planId: PlanId;
  quantity: number;
  priceId: string;
  createdAt: string;
}

export interface Payment {
  id: string; // pay-...
  userId: string;
  subscriptionId?: string;
  invoiceId?: string;
  planId: PlanId;
  planName: string;
  billingInterval: BillingInterval;
  amount: number; // Final charged BDT
  originalAmount: number; // Before discount
  discountAmount: number;
  couponCode?: string;
  currency: 'BDT';
  provider: PaymentProviderType;
  providerTransactionId?: string;
  providerReference?: string;
  status: PaymentStatus;
  paymentMethodDetails?: {
    type: string;
    accountNumberMasked?: string;
    cardBrand?: string;
    bankName?: string;
    gatewayName?: string;
    senderPhone?: string;
    verificationStatus?: string;
  };
  paidAt?: string;
  failedAt?: string;
  failureReason?: string;
  metadata?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface SavedPaymentMethod {
  id: string; // pm_...
  userId: string;
  type: 'bkash' | 'card' | 'nagad' | 'rocket';
  isDefault: boolean;
  bKashNumberMasked?: string;
  bKashAgreementId?: string;
  cardLast4?: string;
  cardBrand?: string;
  cardExpiry?: string;
  cardHolderName?: string;
  tokenStatus?: 'active' | 'refreshing' | 'expired';
  tokenExpiresAt?: string;
  lastRefreshedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentAttempt {
  id: string;
  paymentId: string;
  userId: string;
  provider: string;
  attemptNumber: number;
  requestPayload?: any;
  responsePayload?: any;
  status: string;
  errorMessage?: string;
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  description: string;
  amount: number;
  quantity: number;
  unitPrice: number;
}

export interface Invoice {
  id: string; // inv-...
  userId: string;
  subscriptionId: string;
  planId: PlanId;
  planName: string;
  invoiceType?: 'subscription' | 'top_up';
  amount: number;
  currency: 'BDT';
  billingPeriod: string; // "August 17, 2026 - September 17, 2026"
  paymentId: string;
  status: InvoiceStatus;
  customerName: string;
  customerEmail: string;
  subtotal: number;
  discount: number;
  tax: number;
  items: InvoiceItem[];
  paymentMethodName: string;
  issuedAt: string;
  paidAt?: string;
  createdAt: string;
  transactionId?: string;
  billingAddress?: string;
  gatewayResponse?: string;
}

export interface Entitlement {
  id: string;
  planId: PlanId;
  featureKey: EntitlementFeature;
  accessLevel: 'full' | 'limited' | 'none';
  limits?: Record<string, any>;
}

export interface UsageRecord {
  id: string;
  userId: string;
  periodYearMonth: string; // e.g. "2026-09"
  periodStart: string;
  periodEnd: string;
  aiCoachInteractions: number;
  tokensUsed?: number;
  featureKey?: string;
  activeLockId?: string;
  activeLockUntil?: string;
  rateMinuteWindow?: number;
  rateMinuteCount?: number;
  lastInteractionAt: string;
  updatedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percent' | 'fixed';
  discountValue: number; // e.g. 20 for 20% or 100 for 100 BDT
  applicablePlans?: PlanId[];
  applicableIntervals?: BillingInterval[];
  maxRedemptions: number;
  currentRedemptions: number;
  expiresAt?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Discount {
  id: string;
  couponId: string;
  couponCode: string;
  userId: string;
  paymentId: string;
  amountSaved: number;
  appliedAt: string;
}

export interface Refund {
  id: string;
  paymentId: string;
  invoiceId: string;
  amount: number;
  reason: string;
  status: 'pending' | 'succeeded' | 'failed';
  processedBy: string;
  createdAt: string;
}

export type FeatureKey =
  | 'n5_basic'
  | 'n5_full'
  | 'n4_full'
  | 'grammar_bank'
  | 'kanji_master'
  | 'n3_full'
  | 'jlpt_mock_exams'
  | 'keigo_mastery'
  | 'business_japanese'
  | 'japan_readiness'
  | 'interview_prep'
  | 'living_in_japan'
  | 'certificates'
  | 'ai_coach'
  | 'priority_ai'
  | 'n5'
  | 'n4'
  | 'n3'
  | 'jlpt_pro'
  | 'japan_ready'
  | 'quizzes';

export type AccessDecisionReason =
  | 'TIER_RESTRICTED'
  | 'QUOTA_EXCEEDED'
  | 'SUBSCRIPTION_EXPIRED'
  | 'PAST_DUE_RESTRICTED';

export type RequiredTier = 'STARTER' | 'PRO' | 'JAPAN_READY';

export interface AccessDecision {
  allowed: boolean;
  reason?: AccessDecisionReason;
  requiredTier?: RequiredTier;
  currentUsage?: number;
  usageLimit?: number;
}

export type WebhookStatus = 'success' | 'failed' | 'ignored' | 'pending' | 'retry';

export interface WebhookEvent {
  id: string;
  eventId: string;
  provider: string; // 'bkash' | 'sslcommerz' | 'shurjopay' | 'stripe'
  eventType: string;
  transactionId?: string;
  signature?: string;
  signatureVerified?: boolean;
  rawHeaders?: Record<string, string>;
  rawPayload?: any;
  status: WebhookStatus;
  errorMessage?: string;
  ipAddress?: string;
  payloadReference?: string;
  deliveryAttempts?: number;
  processed: boolean;
  processedAt?: string;
  createdAt: string;
}

export type SubscriptionEventType =
  | 'signup'
  | 'trial_started'
  | 'trial_converted'
  | 'subscription_started'
  | 'subscription_renewed'
  | 'upgrade'
  | 'downgrade'
  | 'cancellation_scheduled'
  | 'cancellation_immediate'
  | 'payment_failed'
  | 'payment_recovered'
  | 'subscription_expired';

export interface SubscriptionEvent {
  id: string;
  userId: string;
  subscriptionId?: string;
  eventType: SubscriptionEventType;
  metadata?: Record<string, any>;
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  adminUserId: string;
  adminEmail: string;
  action: string;
  targetUserId?: string;
  targetResource: string;
  details: Record<string, any>;
  ipAddress?: string;
  createdAt: string;
}

export interface RevenueMetrics {
  mrr: number; // Monthly Recurring Revenue
  arr: number; // Annual Run Rate
  totalRevenue: number;
  activeSubscribers: number;
  newSubscribersThisMonth: number;
  cancelledSubscribers: number;
  churnRate: number; // percentage
  trialConversionRate: number; // percentage
  revenueByPlan: {
    free: number;
    starter: number;
    pro: number;
    japan_ready: number;
  };
  subscribersByPlan: {
    free: number;
    starter: number;
    pro: number;
    japan_ready: number;
  };
  monthlyVsAnnualRevenue: {
    monthly: number;
    yearly: number;
  };
  failedPaymentsCount: number;
  pastDueAccountsCount: number;
  upcomingRenewalsCount: number;
}

export interface MRRTrendPoint {
  month: string;
  mrr: number;
  arr: number;
  subscribers: number;
  newRevenue: number;
  churnedRevenue: number;
}

export interface ConversionTrendPoint {
  month: string;
  trialsStarted: number;
  trialsConverted: number;
  trialsDropped: number;
  conversionRate: number;
}

export interface RevenueTrends {
  mrrTrends: MRRTrendPoint[];
  conversionTrends: ConversionTrendPoint[];
  providerBreakdown: Array<{
    provider: string;
    volume: number;
    revenue: number;
    percentage: number;
  }>;
}

// Content Engine V1.0 Types
export type ContentSourceProcessingStatus =
  | 'UPLOADED'
  | 'EXTRACTING'
  | 'AI_PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'SCANNED_PDF_OCR_REQUIRED';

export type ContentDraftStatus =
  | 'AI_GENERATED'
  | 'UNDER_REVIEW'
  | 'REVISION_REQUIRED'
  | 'APPROVED'
  | 'REJECTED'
  | 'PUBLISHED';

export type ContentEngineType =
  | 'lesson'
  | 'vocabulary'
  | 'grammar'
  | 'kanji'
  | 'reading'
  | 'listening'
  | 'speaking'
  | 'exercises'
  | 'quiz';

export interface ContentSource {
  id: string;
  title: string;
  originalFilename: string;
  storagePath: string;
  storageUrl?: string;
  cloudStorageKey?: string;
  storageBucket?: string;
  mimeType: string;
  fileSize: number;
  sourceLanguage: string;
  targetJlptLevel: JLPTLevel;
  courseId?: string;
  moduleId?: string;
  lessonId?: string;
  processingStatus: ContentSourceProcessingStatus;
  processingError?: string;
  pageCount?: number;
  extractedText?: string;
  ocrApplied?: boolean;
  ocrConfidence?: number;
  contentHash?: string;
  uploadedBy: string;
  uploadedByEmail?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ReadingPassageItem {
  id?: string;
  title: string;
  passage: string;
  furigana?: string;
  translationEn: string;
  translationBn: string;
  questions: Array<{
    question: string;
    options: string[];
    answer: string;
    explanation: string;
  }>;
  sourcePage?: number;
}

export interface ListeningScriptItem {
  id?: string;
  title: string;
  situation: string;
  dialogue: LessonDialogue[];
  comprehensionQuestions: Array<{
    question: string;
    options: string[];
    answer: string;
  }>;
  sourcePage?: number;
}

export interface SpeakingScenarioItem {
  id?: string;
  situation: string;
  roles: string[];
  targetExpressions: string[];
  pronunciationNotes: string;
  rolePlayInstructions: string;
  sourcePage?: number;
}

export interface StructuredEducationalContent {
  vocabulary: VocabularyItem[];
  grammar: GrammarItem[];
  kanji: KanjiItem[];
  dialogue?: LessonDialogue[];
  practiceExercises: LessonPracticeExercise[];
  readingPassages?: ReadingPassageItem[];
  listeningScripts?: ListeningScriptItem[];
  speakingScenarios?: SpeakingScenarioItem[];
  baitoSimulation?: {
    workplaceType: string;
    scenarioBn: string;
    keigoPhrases: Array<{
      phraseJa: string;
      reading: string;
      meaningBn: string;
      formality: string;
      customerContextBn: string;
    }>;
    drillPromptBn: string;
    expectedResponseJa: string;
  };
  srsFlashcardPayload?: Array<{
    id: string;
    itemType: string;
    frontJa: string;
    furigana: string;
    romaji: string;
    backBn: string;
    backEn: string;
    pitchAccent?: string;
    sampleSentenceJa?: string;
    sampleSentenceBn?: string;
    leitnerBox: number;
  }>;
  homeworkTasks?: Array<{
    id: string;
    titleBn: string;
    instructionBn: string;
    taskType: string;
    estimatedMinutes: number;
    memoryOsSync: boolean;
  }>;
  masteryChecklist?: {
    canDoChecklist: Array<{ id: string; statementBn: string; verified: boolean }>;
    jlptQuestionTypesCovered: string[];
    recommendedReviewDayIntervals: number[];
  };
  quiz?: {
    title: string;
    passingScore: number;
    questions: QuizQuestion[];
  };
}

export interface ContentDraftGenerationMetadata {
  modelUsed: string;
  sourceDerived: boolean;
  aiEnriched: boolean;
  generatedAt: string;
  tokenEstimate?: number;
  sourcePageReferences?: number[];
  confidenceScore?: number;
  disclaimer: string;
}

export interface ContentDraft {
  id: string;
  sourceId: string;
  courseId: string;
  moduleId?: string;
  lessonId?: string;
  contentType: ContentEngineType;
  title: string;
  titleJa: string;
  summary: string;
  explanation: string;
  level: JLPTLevel;
  structuredContent: StructuredEducationalContent;
  status: ContentDraftStatus;
  reviewNotes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  generationMetadata: ContentDraftGenerationMetadata;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ContentVersionMetadata {
  title?: string;
  titleJa?: string;
  summary?: string;
  explanation?: string;
  level?: JLPTLevel;
  courseId?: string;
  moduleId?: string;
}

export interface ContentVersion {
  id: string;
  draftId: string;
  sourceId: string;
  versionNumber: number;
  contentJson: StructuredEducationalContent;
  metadataJson?: ContentVersionMetadata;
  targetLessonId?: string;
  targetCourseId?: string;
  changelogSummary?: string;
  checksumSha256?: string;
  rollbackFromVersion?: number;
  approvedBy: string;
  publishedBy: string;
  approvedAt: string;
  publishedAt: string;
  createdAt: string;
}

export interface ContentDiffFieldChange {
  field: string;
  oldValue: any;
  newValue: any;
}

export interface ContentDiffItem<T = any> {
  id: string;
  title?: string;
  changeType: 'ADDED' | 'REMOVED' | 'MODIFIED' | 'UNCHANGED';
  fieldChanges?: ContentDiffFieldChange[];
  oldItem?: T;
  newItem?: T;
}

export interface ContentDifferentialDiff {
  entityId: string;
  baseVersion: string | number;
  targetVersion: string | number;
  timestamp: string;
  stats: {
    totalChanges: number;
    vocabularyChanges: { added: number; removed: number; modified: number };
    grammarChanges: { added: number; removed: number; modified: number };
    kanjiChanges: { added: number; removed: number; modified: number };
    dialogueChanges: { added: number; removed: number; modified: number };
    exerciseChanges: { added: number; removed: number; modified: number };
    quizChanges: { added: number; removed: number; modified: number };
    metadataChanges: number;
  };
  metadataDiff: ContentDiffFieldChange[];
  vocabularyDiff: ContentDiffItem<VocabularyItem>[];
  grammarDiff: ContentDiffItem<GrammarItem>[];
  kanjiDiff: ContentDiffItem<KanjiItem>[];
  dialogueDiff: ContentDiffItem<LessonDialogue>[];
  exerciseDiff: ContentDiffItem<LessonPracticeExercise>[];
  quizQuestionDiff: ContentDiffItem<QuizQuestion>[];
}

export interface DatabaseSchema {
  users: User[];
  profiles: UserProfile[];
  progress: UserProgress[];
  courses: Course[];
  modules: Module[];
  lessons: Lesson[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  workJapanese: WorkJapaneseItem[];
  aiSessions: AISession[];

  // Subscription & Billing Tables
  plans: Plan[];
  planPrices: PlanPrice[];
  subscriptions: Subscription[];
  subscriptionItems: SubscriptionItem[];
  payments: Payment[];
  paymentAttempts: PaymentAttempt[];
  invoices: Invoice[];
  invoiceItems: InvoiceItem[];
  entitlements: Entitlement[];
  usageRecords: UsageRecord[];
  coupons: Coupon[];
  discounts: Discount[];
  refunds: Refund[];
  webhookEvents: WebhookEvent[];
  subscriptionEvents: SubscriptionEvent[];
  adminAuditLogs: AdminAuditLog[];
  savedPaymentMethods?: SavedPaymentMethod[];

  // Content Engine Tables
  contentSources: ContentSource[];
  contentDrafts: ContentDraft[];
  contentVersions: ContentVersion[];
  backgroundJobs?: BackgroundJob[];
  publishingQueue?: PublishingQueueItem[];

  // MemoryOS™ & Ghost Mode SRS Tables
  ghostWeaknesses?: GhostWeaknessItem[];
  studentErrorLogs?: StudentErrorLog[];
  mistakeRecords?: MistakeRecord[];

  // JLPT Mock Exam Engine Tables
  mockExams?: MockExam[];
  mockExamAttempts?: MockExamAttempt[];

  // Personalized Study Plan & Daily SRS Quota Tables
  studyPlans?: JLPTStudyPlan[];
  dailyStudySessions?: DailyStudySessionRecord[];

  // Task 8: BaitoOS™ 2.0 & Tokyo Relocation Simulation Hub Tables
  baitoScenarios?: BaitoScenarioItem[];
  conbiniProducts?: ConbiniPosProduct[];
  conbiniOrders?: ConbiniCustomerOrder[];
  rirekishoProfiles?: JisRirekishoData[];

  // P1-04: Adaptive SRS (Spaced Repetition System) Engine Tables
  srsCards?: SrsCardRecord[];
  srsLogs?: SrsReviewLog[];

  // P1-05: Materialized Learner Analytics & Real-Time Telemetry Summaries
  learnerAnalyticsSummaries?: LearnerAnalyticsSummary[];

  // P1-06: Multimodal Voice & Tokyo Pitch-Accent Assessments
  voiceAssessments?: TokyoPitchAccentAssessment[];
  pitchDrills?: TokyoPitchDrill[];
  accentMasterySessions?: AccentMasterySession[];
  accentSrsCards?: AccentSrsCard[];
  speakingCertificates?: SpeakingReadinessCertificate[];
  roleplaySessions?: RoleplaySessionState[];
  studentNotifications?: Array<{
    id: string;
    type: string;
    title: string;
    titleBn?: string;
    message: string;
    messageBn?: string;
    lessonId?: string;
    courseId?: string;
    level?: string;
    createdAt: string;
    read: boolean;
  }>;

  // Gate 2: Company Brain & Founder HQ Collections
  mrrTargets?: MrrTarget[];
  marketTargets?: MarketTarget[];
  aiOfficeDepartments?: AiOfficeDepartment[];
  approvalRequests?: ApprovalRequest[];
  budgetWallets?: BudgetWallet[];
  founderAuditLogs?: FounderAuditLog[];
  companyBrainRecords?: CompanyBrainItem[];
}

export type MockExamSectionType = 'vocabulary' | 'grammar_reading' | 'listening';

export type MockExamQuestionType =
  | 'kanji_reading'
  | 'orthography'
  | 'contextual_usage'
  | 'paraphrase'
  | 'sentence_grammar'
  | 'sentence_composition'
  | 'text_grammar'
  | 'short_reading'
  | 'mid_reading'
  | 'information_retrieval'
  | 'task_listening'
  | 'point_listening'
  | 'quick_response'
  | 'utterance_expression';

export interface MockExamQuestion {
  id: string;
  sectionType: MockExamSectionType;
  questionNumber: number;
  type: MockExamQuestionType;
  questionText: string;
  questionTextJa?: string;
  furigana?: string;
  readingPassage?: {
    id: string;
    title?: string;
    passageJa: string;
    passageFurigana?: string;
    contextNote?: string;
  };
  audioScript?: {
    narratorText: string;
    dialogue: {
      speaker: string;
      textJa: string;
      romaji?: string;
      bangla?: string;
    }[];
    audioPrompt: string;
    questionAudioPromptJa: string;
  };
  scrambledParts?: string[]; // 4 items: [1], [2], [3], [4] for ★ questions
  starPositionIndex?: number; // 0, 1, 2, or 3
  options: string[];
  correctOptionIndex: number;
  explanationJa?: string;
  explanationBn: string;
  explanationEn?: string;
  pointValue: number;
  conceptCode?: string;
}

export interface MockExamSection {
  id: string;
  sectionType: MockExamSectionType;
  title: string;
  titleJa: string;
  timeLimitMinutes: number;
  maxScaledScore: number; // 60
  passingThreshold: number; // 19
  questions: MockExamQuestion[];
}

export interface MockExam {
  id: string;
  examCode: string;
  title: string;
  titleJa: string;
  level: JLPTLevel;
  description: string;
  descriptionBn: string;
  totalTimeMinutes: number;
  totalPossibleScore: number; // 180
  overallPassingScore: number; // 80 for N5, 90 for N4, 95 for N3
  sections: MockExamSection[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SectionScoreResult {
  sectionType: MockExamSectionType;
  sectionTitle: string;
  totalQuestions: number;
  correctQuestions: number;
  rawScorePercent: number;
  scaledScore: number;
  maxScaledScore: number;
  passingThreshold: number;
  isSectionPassed: boolean;
}

export interface MockExamAttempt {
  id: string;
  userId: string;
  mockExamId: string;
  examCode: string;
  level: JLPTLevel;
  startedAt: string;
  submittedAt: string;
  timeSpentSeconds: number;
  sectionTimesSpentSeconds: Record<MockExamSectionType, number>;
  sectionScores: Record<MockExamSectionType, SectionScoreResult>;
  totalScaledScore: number; // 0 - 180
  overallPassingScore: number;
  isPassed: boolean;
  failReason?: string;
  percentileRank?: number;
  letterGrade: 'A' | 'B' | 'C' | 'F';
  certificateId: string;
  verificationHash?: string;
  isPro?: boolean;
  userAnswers: {
    questionId: string;
    sectionType: MockExamSectionType;
    selectedOptionIndex: number;
    isCorrect: boolean;
    timeSpentSeconds: number;
  }[];
  strengthSummaryBn: string;
  weaknessSummaryBn: string;
  actionableStudyPlanBn: string[];
}

export type ParticleConfusionType =
  | 'wa_vs_ga'
  | 'ni_vs_de'
  | 'o_vs_ga'
  | 'ni_vs_e'
  | 'kara_vs_made'
  | 'to_vs_ya'
  | 'te_form'
  | 'transitive_intransitive'
  | 'honorific_humble'
  | 'general_grammar';

export interface GhostWeaknessItem {
  id: string;
  userId: string;
  topic: string;
  conceptCode: string;
  confusionType: ParticleConfusionType;
  level: JLPTLevel;
  targetJapanese: string;
  romaji: string;
  bangla: string;
  failureCount: number;
  successStreak: number;
  masteryPercentage: number; // 0 - 100%
  firstSeenAt: string;
  lastFailedAt: string;
  lastReviewedAt?: string;
  nextReviewAt: string; // ISO date
  srsStage: 'apprentice' | 'guru' | 'master' | 'enlightened' | 'burned';
  intervalDays: number;
  easeFactor: number;
  lastFailedContext: string;
  newContextChallenge: string;
  scenarioPrompt: string;
  options: {
    text: string;
    isCorrect: boolean;
    explanation: string;
  }[];
  isResolved: boolean;
  resolvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudentErrorLog {
  id: string;
  userId: string;
  questionId?: string;
  quizId?: string;
  lessonId?: string;
  conceptCode: string;
  userSelected: string;
  correctAnswer: string;
  category: 'particle' | 'conjugation' | 'kanji' | 'vocabulary' | 'keigo' | 'grammar';
  details: string;
  timestamp: string;
}

export type LearningPace = 'relaxed' | 'moderate' | 'intensive' | 'turbo';

export interface StudyPlanSprintPhase {
  phaseNumber: number;
  totalPhases: number;
  name: string;
  nameJa: string;
  goalDescription: string;
  goalDescriptionBn: string;
  startDate: string;
  endDate: string;
  progressPercent: number;
  status: 'completed' | 'active' | 'upcoming';
  keyMilestones: string[];
}

export interface DailySrsQuota {
  newVocabTarget: number;
  vocabSrsReviewTarget: number;
  kanjiStrokeTarget: number;
  grammarPatternsTarget: number;
  particleWeakSpotsTarget: number;
  listeningMinutesTarget: number;
  totalDailyMinutes: number;
}

export interface WeeklyMilestoneItem {
  weekNumber: number;
  weekRange: string;
  milestoneTitle: string;
  milestoneTitleBn: string;
  targetLessons: string;
  targetKanjiCount: number;
  isCompleted: boolean;
  isCurrent: boolean;
}

export interface DailyRoadmapTask {
  id: string;
  taskType: 'vocab_srs' | 'kanji_drill' | 'grammar_lesson' | 'ghost_recovery' | 'listening_drill' | 'mock_exam';
  title: string;
  titleJa: string;
  titleBn: string;
  targetCount: number;
  completedCount: number;
  estimatedMinutes: number;
  isCompleted: boolean;
  xpReward: number;
  linkView: string;
  linkParams?: Record<string, any>;
}

export interface DailyStudySessionRecord {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  completedItems: {
    vocabSrsDone: number;
    kanjiDone: number;
    grammarDone: number;
    ghostsResolved: number;
    listeningMinutesDone: number;
    quizzesDone: number;
  };
  totalMinutesSpent: number;
  dailyQuotaMet: boolean;
  earnedXp: number;
  checklist: DailyRoadmapTask[];
  updatedAt: string;
}

export interface JLPTStudyPlan {
  id: string;
  userId: string;
  targetLevel: JLPTLevel;
  targetExamDate: string; // ISO string e.g. 2026-12-06
  examSessionName: string;
  targetScore: number; // out of 180
  dailyTimeMinutes: number;
  learningPace: LearningPace;
  focusAreas: string[];
  daysRemaining: number;
  weeksRemaining: number;
  currentSprintPhase: StudyPlanSprintPhase;
  sprintPhases: StudyPlanSprintPhase[];
  dailyQuota: DailySrsQuota;
  weeklySchedule: WeeklyMilestoneItem[];
  readinessScore: number; // 0 - 100%
  projectedScore: number; // e.g. 142 / 180
  passProbability: number; // e.g. 88%
  createdAt: string;
  updatedAt: string;
}

// ==============================================================================
// Task 8: BaitoOS™ 2.0 & Tokyo Relocation Simulation Hub Types
// ==============================================================================

export type BaitoScenarioType =
  | 'conbini_pos'
  | 'school_principal'
  | 'embassy_visa'
  | 'restaurant_izakaya'
  | 'train_metro'
  | 'ward_office';

export interface BaitoScenarioItem {
  id: string;
  type: BaitoScenarioType;
  title: string;
  titleJa: string;
  titleBn: string;
  subtitle: string;
  difficulty: 'N5' | 'N4' | 'N3';
  location: string;
  interlocutorName: string;
  interlocutorRole: string;
  interlocutorAvatar: string;
  initialDialogue: {
    ja: string;
    romaji: string;
    bn: string;
    en: string;
  };
  objectives: string[];
  contextDescription: string;
  keyVocabulary: Array<{
    ja: string;
    kana: string;
    meaningBn: string;
    meaningEn: string;
  }>;
}

export interface BaitoInterviewMessage {
  id: string;
  sender: 'interviewer' | 'student' | 'system';
  textJa: string;
  textRomaji?: string;
  textBn?: string;
  textEn?: string;
  audioText?: string;
  timestamp: string;
  evaluation?: {
    keigoAccuracy: number; // 0-100
    grammarScore: number; // 0-100
    fluencyScore: number; // 0-100
    feedbackJa: string;
    feedbackBn: string;
    betterAlternativeJa?: string;
    betterAlternativeRomaji?: string;
  };
}

export interface BaitoEvaluationResponse {
  success: boolean;
  messageId: string;
  userText: string;
  nextInterviewerDialogue: {
    ja: string;
    romaji: string;
    bn: string;
    en: string;
  };
  evaluation: {
    overallScore: number;
    keigoLevel: 'Teineigo (Polite)' | 'Kenjougo (Humble)' | 'Sonkeigo (Honorific)' | 'Informal (Needs Fix)';
    keigoAccuracy: number;
    grammarScore: number;
    fluencyScore: number;
    feedbackJa: string;
    feedbackBn: string;
    detectedMistakes: string[];
    polishedAlternativeJa: string;
    polishedAlternativeRomaji: string;
  };
  isFinished?: boolean;
  finalReadinessScore?: number;
}

export interface JisRirekishoData {
  id: string;
  userId: string;
  fullName: string;
  fullNameKana: string;
  fullNameRomaji: string;
  gender: 'male' | 'female' | 'other' | 'unspecified';
  birthDate: string; // YYYY-MM-DD
  japaneseEraBirth: string; // e.g. 平成12年10月1日
  age: number;
  phone: string;
  email: string;
  postalCode: string;
  currentAddress: string;
  currentAddressKana: string;
  photoUrl: string;
  visaStatus: string;
  visaExpiry: string;
  allowedHoursPerWeek: number; // e.g. 28
  educationHistory: Array<{
    year: number;
    month: number;
    schoolName: string;
    faculty: string;
    status: 'enrolled' | 'graduated' | 'expected_graduation';
  }>;
  workHistory: Array<{
    year: number;
    month: number;
    companyName: string;
    role: string;
    status: 'joined' | 'resigned' | 'current';
  }>;
  licensesCertifications: Array<{
    year: number;
    month: number;
    title: string;
  }>;
  jlptLevel: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | 'Studying N5' | 'Studying N4';
  motivationStatement: string; // 志望の動機
  motivationStatementPolished?: string;
  selfPr: string; // 自己PR
  selfPrPolished?: string;
  commuteTimeMinutes: number;
  dependentsCount: number;
  hasSpouse: boolean;
  hankoStampUrl?: string;
  updatedAt: string;
}

export interface ConbiniPosProduct {
  id: string;
  barcode: string;
  nameJa: string;
  nameRomaji: string;
  nameBn: string;
  priceYen: number;
  category: 'bento' | 'drink' | 'onigiri' | 'dessert' | 'alcohol_tobacco' | 'hot_snack';
  needsHeating?: boolean;
  needsAgeVerification?: boolean;
  imageIcon: string;
}

export interface ConbiniCustomerOrder {
  id: string;
  customerName: string;
  customerType: 'salaryman' | 'student' | 'grandma' | 'foreigner';
  customerSpeechJa: string;
  customerSpeechRomaji: string;
  customerSpeechBn: string;
  items: ConbiniPosProduct[];
  hasPointCard: boolean;
  pointCardName?: 'Ponta' | 'd-Point' | 'Rakuten' | 'None';
  needsBag: boolean;
  needsChopsticks: boolean;
  wantsBentoHeated: boolean;
  paymentMethod: 'cash' | 'suica' | 'paypay' | 'credit';
  tenderedCashAmount?: number;
}

export type BackgroundJobType =
  | 'pdf_extraction'
  | 'scanned_pdf_ocr'
  | 'curriculum_structuring'
  | 'audio_generation'
  | 'batch_media_sync'
  | 'database_backup_daily'
  | 'database_backup_weekly'
  | 'live_lesson_publishing'
  | 'batch_lesson_publish';
export type BackgroundJobStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled' | 'retrying';

export type PublishingQueuePriority = 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';
export type PublishingQueueStatus = 'queued' | 'validating' | 'snapshotting' | 'publishing' | 'completed' | 'failed' | 'cancelled';

export interface PreflightCheckItem {
  id: string;
  name: string;
  category: 'STRUCTURE' | 'VOCABULARY' | 'GRAMMAR' | 'KANJI' | 'QUIZ' | 'AUDIO' | 'CURRICULUM';
  status: 'PASS' | 'WARN' | 'FAIL';
  message: string;
  details?: Record<string, any>;
}

export interface PublishingPreflightReport {
  passed: boolean;
  score: number; // 0 - 100
  evaluatedAt: string;
  totalChecks: number;
  passedChecks: number;
  warningsCount: number;
  errorsCount: number;
  checks: PreflightCheckItem[];
}

export interface PublishingQueueLogEntry {
  timestamp: string;
  stage: string;
  level: 'info' | 'warn' | 'error';
  message: string;
  details?: Record<string, any>;
}

export interface PublishingQueueItem {
  id: string;
  draftId: string;
  lessonId?: string;
  title: string;
  titleJa?: string;
  level: JLPTLevel;
  priority: PublishingQueuePriority;
  status: PublishingQueueStatus;
  progress: number; // 0 - 100
  currentStage: string;
  scheduledFor?: string; // ISO timestamp
  changelog?: string;
  enqueuedBy: string;
  enqueuedAt: string;
  startedAt?: string;
  completedAt?: string;
  publishedLessonId?: string;
  createdVersionId?: string;
  versionNumber?: number;
  preflightReport?: PublishingPreflightReport;
  error?: string;
  retryCount: number;
  maxRetries: number;
  logs: PublishingQueueLogEntry[];
}

export interface BackgroundJob {
  id: string;
  type: BackgroundJobType;
  targetId: string; // sourceId or draftId
  status: BackgroundJobStatus;
  progress: number; // 0 - 100
  currentStage: string;
  totalPages?: number;
  processedPages?: number;
  result?: any;
  error?: string;
  retryCount: number;
  maxRetries: number;
  startedAt?: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, any>;
}

export interface StructuredLogEntry {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'debug';
  service: string;
  event: string;
  message: string;
  traceId?: string;
  userId?: string;
  route?: string;
  method?: string;
  statusCode?: number;
  durationMs?: number;
  metadata?: Record<string, any>;
}

export interface SystemAuditMetrics {
  totalJobsProcessed: number;
  activeJobsCount: number;
  completedJobsCount: number;
  failedJobsCount: number;
  averageJobDurationMs: number;
  totalPdfPagesProcessed: number;
  ocrExtractionCount: number;
  aiTokensBudgetUsed: number;
  queueDepth: number;
  uptimeSeconds: number;
  lastUpdated: string;
}

// ==============================================================================
// P1-04: Adaptive SRS (Spaced Repetition System) SuperMemo-2 / FSRS Types
// ==============================================================================

export type SrsCardStage = 'apprentice' | 'guru' | 'master' | 'enlightened' | 'burned';
export type SrsItemType = 'vocabulary' | 'kanji' | 'grammar';
export type SrsRatingGrade = 'again' | 'hard' | 'good' | 'easy';
export type SrsAlgorithmMode = 'sm2' | 'fsrs' | 'adaptive_hybrid';

export interface SrsCardRecord {
  id: string; // e.g. srs-vocab-123 or srs-kanji-日
  userId: string;
  itemType: SrsItemType;
  itemId: string; // Original vocabulary item id or kanji character
  lessonId?: string; // Sourced from published lesson (e.g. P1-03 live queue)
  level: JLPTLevel;
  front: string; // Word or Kanji character
  reading: string; // Kana reading / furigana
  meaning: string; // English definition
  meaningBn?: string; // Bengali translation
  partOfSpeech?: string;
  audioText?: string;
  audioUrl?: string;
  exampleSentenceJa?: string;
  exampleSentenceEn?: string;
  exampleSentenceBn?: string;
  // Kanji specific metadata
  kanjiStrokes?: number;
  kanjiRadicals?: string;
  kanjiOnyomi?: string[];
  kanjiKunyomi?: string[];

  // SM-2 & FSRS Algorithmic State Variables
  repetition: number; // Consecutive successful reviews
  intervalDays: number; // Current scheduled interval in days
  easeFactor: number; // SM-2 Ease Factor (min 1.3, standard default 2.5)
  stabilityDays: number; // FSRS Memory Stability S (days until retention drops to 90%)
  difficulty: number; // FSRS Memory Difficulty D (1.0 easiest - 10.0 hardest, standard default 5.0)
  retrievability: number; // Current predicted probability of recall R(t) in [0..1]
  retentionScore: number; // Current retention score percentage (0 - 100)
  lapses: number; // Number of times forgotten ('again') after graduating from apprentice
  totalReviews: number; // Lifetime review count
  consecutiveCorrect: number; // Current winning streak
  stage: SrsCardStage; // Apprentice -> Guru -> Master -> Enlightened -> Burned
  lastReviewedAt: string | null; // ISO timestamp of last review
  nextReviewAt: string; // ISO timestamp when card is due
  suspended?: boolean; // If user suspended the card
  metadata?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface SrsReviewLog {
  id: string;
  userId: string;
  cardId: string;
  itemId: string;
  itemType: SrsItemType;
  rating: SrsRatingGrade;
  algorithmUsed: SrsAlgorithmMode;
  scheduledDays: number;
  actualElapsedDays: number;
  responseTimeMs: number; // Learner telemetry latency tracking
  retentionBeforeReview: number;
  stageBefore: SrsCardStage;
  stageAfter: SrsCardStage;
  intervalDaysBefore: number;
  intervalDaysAfter: number;
  easeFactorBefore: number;
  easeFactorAfter: number;
  stabilityBefore: number;
  stabilityAfter: number;
  difficultyBefore: number;
  difficultyAfter: number;
  reviewedAt: string;
}

export interface SrsReviewSubmission {
  cardId: string;
  rating: SrsRatingGrade;
  responseTimeMs?: number;
  algorithmMode?: SrsAlgorithmMode;
  targetRetention?: number; // e.g. 0.90 (80% - 97%)
}

export interface SrsRetentionCurvePoint {
  day: number;
  theoreticalRetention: number; // Percentage 0 - 100 based on R(t) = exp(-t * ln(10/9) / S)
  empiricalRetention?: number; // Observed recall percentage from telemetry logs
  reviewCount?: number;
}

export interface SrsRetentionCurveReport {
  cardId?: string;
  itemTitle?: string;
  stabilityDays: number;
  halfLifeDays: number;
  currentElapsedDays: number;
  currentRetention: number;
  recommendedReviewDay: number;
  points: SrsRetentionCurvePoint[];
}

export interface SrsTelemetryStats {
  totalCards: number;
  dueCards: number;
  cardsByStage: Record<SrsCardStage, number>;
  cardsByType: Record<SrsItemType, number>;
  cardsByLevel: Record<JLPTLevel, number>;
  retentionRate7d: number;
  retentionRate30d: number;
  overallAccuracyRate: number;
  averageEaseFactor: number;
  averageStability: number;
  averageDifficulty: number;
  averageResponseTimeMs: number;
  totalReviewsLifetime: number;
  lapsesTotal: number;
  dueForecast: { date: string; count: number }[];
}

// ==============================================================================
// P1-05: Learner Analytics & Real-Time Telemetry Types
// ==============================================================================

export interface DailyRetentionDataPoint {
  date: string; // YYYY-MM-DD
  totalReviews: number;
  successfulReviews: number;
  againReviews: number;
  accuracyRate: number; // 0 - 100%
  averageResponseTimeMs: number;
  averageRetrievability: number; // 0.0 - 1.0
}

export interface DailyActivityDataPoint {
  date: string; // YYYY-MM-DD
  studyMinutes: number;
  srsReviews: number;
  xpEarned: number;
  quotaCompleted: boolean;
}

export interface MockExamSectionAverage {
  sectionType: MockExamSectionType;
  sectionTitle: string;
  averageRawPercent: number;
  averageScaledScore: number;
  maxScaledScore: number;
  passRatePercent: number;
}

export interface MockExamAttemptSummary {
  attemptId: string;
  examId: string;
  examCode: string;
  level: JLPTLevel;
  title: string;
  submittedAt: string;
  totalScaledScore: number;
  overallPassingScore: number;
  isPassed: boolean;
  letterGrade: 'A' | 'B' | 'C' | 'F';
  timeSpentSeconds: number;
}

export interface LeaderboardRankItem {
  userId: string;
  rank: number;
  name: string;
  nameJa?: string;
  avatar?: string;
  avatarText: string;
  location?: string;
  targetLevel: JLPTLevel;
  badgeTitle: string;
  xp: number;
  streakDays: number;
  isCurrentUser: boolean;
}

export interface LearnerAnalyticsSummary {
  id: string; // analytics-summary-{userId}
  userId: string;
  computedAt: string;
  targetLevel: JLPTLevel;
  
  // 1. SRS Retention Telemetry
  srsMetrics: {
    totalCards: number;
    dueCards: number;
    retentionRate7d: number;
    retentionRate30d: number;
    overallAccuracyRate: number;
    averageStabilityDays: number;
    averageDifficulty: number;
    averageResponseTimeMs: number;
    masteryBreakdown: Record<SrsCardStage, number>;
    dailyRetentionTrend: DailyRetentionDataPoint[];
  };

  // 2. Study Streak & Learning Pulse Telemetry
  streakMetrics: {
    currentStreak: number;
    longestStreak: number;
    lastActiveDate: string;
    totalStudyMinutes: number;
    activeDaysLast30d: number;
    consistencyScorePercent: number;
    averageDailyMinutes: number;
    recentDailyActivity: DailyActivityDataPoint[];
  };

  // 3. JLPT N5 / Mock Exam Telemetry
  mockExamMetrics: {
    targetLevel: JLPTLevel;
    totalAttempts: number;
    passedAttempts: number;
    passRatePercent: number;
    averageScaledScore: number;
    highestScaledScore: number;
    overallPassingScore: number;
    readinessScorePercent: number;
    sectionAverages: Record<MockExamSectionType, MockExamSectionAverage>;
    recentAttempts: MockExamAttemptSummary[];
  };

  // 4. XP Leaderboard Telemetry
  leaderboardMetrics: {
    currentXp: number;
    allTimeRank: number;
    weeklyRank: number;
    dailyRank: number;
    totalLearners: number;
    topPercentile: number; // e.g. 5 for Top 5%
    weeklyXpDelta: number;
    rankDelta7d: number;
  };

  // 5. Multimodal Voice & Tokyo Pitch-Accent Telemetry
  voiceTelemetry: VoicePronunciationTelemetry;

  lastRefreshed: string;
}

export interface PlatformCohortAnalytics {
  totalLearners: number;
  activeLearnersLast7d: number;
  totalSrsCardsInSystem: number;
  totalReviewsCompletedLifetime: number;
  averageCohortAccuracyPercent: number;
  jlptN5MockPassRatePercent: number;
  averageCohortStreakDays: number;
  topPerformingLevel: JLPTLevel;
  generatedAt: string;
}

// ==============================================================================
// P1-06: Multimodal Voice & Tokyo Pitch-Accent Telemetry Types
// ==============================================================================

export type PitchAccentPattern = 'heiban' | 'atamadaka' | 'nakadaka' | 'odaka';

export interface MoraEvaluation {
  moraIndex: number;
  mora: string;
  targetPitch: 'H' | 'L';
  detectedPitch: 'H' | 'L';
  isDropPoint?: boolean;
  isMatch: boolean;
  estimatedHz?: number;
}

export interface TokyoPitchAccentAssessment {
  id: string;
  userId: string;
  targetPhrase: string;
  targetRomaji?: string;
  targetMeaning?: string;
  targetPattern: PitchAccentPattern;
  targetDownstepMora: number; // 0 for Heiban, 1 for Atamadaka, 2..N-1 for Nakadaka, N for Odaka
  detectedPattern: PitchAccentPattern;
  detectedDownstepMora: number;
  moraBreakdown: MoraEvaluation[];
  patternMatch: boolean;
  pitchAccuracyScore: number; // 0 - 100
  moraRhythmScore: number; // 0 - 100
  clarityScore: number; // 0 - 100
  overallScore: number; // 0 - 100
  passed: boolean;
  audioDurationMs?: number;
  averageF0Hz?: number;
  pitchTrajectory?: number[];
  intensityTrajectory?: number[];
  feedbackEn: string;
  feedbackBn: string;
  coachingTips: string[];
  bengaliAcousticAnalysis?: BengaliAcousticAnalysis;
  recordedAt: string;
}

export type BengaliAcousticErrorCode =
  | 'DYNAMIC_STRESS_INSTEAD_OF_PITCH'
  | 'MORA_FLATTENING'
  | 'SHORT_LONG_VOWEL_MISMATCH'
  | 'SOKUON_GEMINATE_RUSHED'
  | 'NASAL_MORA_SHORTENED';

export interface BengaliPhoneticError {
  errorCode: BengaliAcousticErrorCode;
  affectedMora: string;
  moraIndex: number; // 1-indexed
  severity: 'high' | 'medium' | 'low';
  messageEn: string;
  messageBn: string;
  actionableCorrectionBn: string;
  acousticMetrics?: {
    detectedF0DeltaRatio?: number;
    detectedIntensitySpikeRatio?: number;
    detectedDurationMs?: number;
    expectedDurationMs?: number;
  };
}

export interface BengaliAcousticAnalysis {
  hasDynamicStressError: boolean;
  hasMoraFlattening: boolean;
  hasVowelLengthMismatch: boolean;
  hasSokuonRushedError: boolean;
  hasConsonantClusterEpenthesis?: boolean;
  pitchVsIntensityCorrelation: number; // -1.0 to 1.0
  detectedErrors: BengaliPhoneticError[];
  overallBengaliCoachingBn: string;
  actionableRecommendationsBn: string[];
  acousticSymptoms?: string[];
}

export interface TokyoPitchDrill {
  id: string;
  category: 'minimal_pair' | 'n5_essential' | 'n4_conversation' | 'n3_intermediate' | 'keigo_formula' | 'custom_input';
  kanji: string;
  readingKana: string;
  romaji: string;
  moraCount: number;
  morae: string[];
  pattern: PitchAccentPattern;
  patternNameJa: string;
  downstepMora: number; // 0 = Heiban, 1 = Atamadaka, 2..N-1 = Nakadaka, N = Odaka
  targetPitches: ('H' | 'L')[];
  relativeTargetContour: number[]; // Relative pitch factors (e.g. 1.0 for L, 1.28 for H)
  standardHzContour: number[]; // Standard frequency in Hz (e.g. [180, 230, 230])
  targetIntensityEnvelope: number[]; // Normalized expected intensity curve
  meaningEn: string;
  meaningBn: string;
  contextNote?: string;
  contrastGroup?: string;
  jlptLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1';
  createdAt?: string;
}

export interface DynamicDrillGenerationInput {
  word: string;
  readingKana?: string;
  meaningEn?: string;
  meaningBn?: string;
  category?: 'minimal_pair' | 'n5_essential' | 'n4_conversation' | 'n3_intermediate' | 'keigo_formula' | 'custom_input';
  jlptLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1';
  overridePattern?: PitchAccentPattern;
  overrideDownstepMora?: number;
  contrastGroup?: string;
  contextNote?: string;
}

export interface DynamicDrillGenerationResult {
  totalProcessed: number;
  drills: TokyoPitchDrill[];
}

export interface VoicePronunciationTelemetry {
  totalVoiceSessions: number;
  totalVoiceRecordings: number;
  averageClarityScore: number;
  averagePitchAccuracy: number;
  averageMoraRhythm: number;
  overallPronunciationScore: number;
  pitchPatternMastery: {
    heibanAccuracy: number;
    atamadakaAccuracy: number;
    nakadakaAccuracy: number;
    odakaAccuracy: number;
  };
  patternsEvaluatedCount: {
    heiban: number;
    atamadaka: number;
    nakadaka: number;
    odaka: number;
  };
  recentEvaluations: TokyoPitchAccentAssessment[];
  weakPhonemes: string[];
  tokyoAccentReadinessRate: number; // 0 - 100%
  lastVoiceSessionDate?: string;
}

export type AdaptiveWeaknessType =
  | 'dynamic_stress'
  | 'mora_flattening'
  | 'choon_shortening'
  | 'sokuon_rushed'
  | 'atamadaka_downstep'
  | 'nakadaka_timing'
  | 'heiban_elevation'
  | 'general_intonation';

export interface AdaptiveRecommendedPair {
  contrastGroup: string;
  targetRemediation: string;
  remediationRationaleBn: string;
  remediationRationaleEn: string;
  drills: TokyoPitchDrill[];
}

export interface AdaptiveDrillRecommendation {
  userId: string;
  primaryWeakness: AdaptiveWeaknessType;
  secondaryWeakness?: AdaptiveWeaknessType;
  diagnosticSummaryBn: string;
  diagnosticSummaryEn: string;
  errorFrequency: {
    dynamicStressCount: number;
    moraFlatteningCount: number;
    choonShorteningCount: number;
    sokuonRushedCount: number;
    patternFailures: Record<string, number>;
    totalEvaluationsAnalyzed: number;
  };
  recommendedPairs: AdaptiveRecommendedPair[];
  synthesizedDrillCount: number;
  generatedAt: string;
}

export interface AccentMasteryStep {
  stepIndex: number;
  drillId: string;
  kanji: string;
  readingKana: string;
  pattern: PitchAccentPattern;
  targetPitches: ('H' | 'L')[];
  userPitchAssessment?: TokyoPitchAccentAssessment;
  bengaliCoachingTip?: string;
  stepScore?: number;
  passed?: boolean;
  completedAt?: string;
}

export interface AccentMasterySession {
  id: string;
  userId: string;
  title: string;
  status: 'in_progress' | 'completed' | 'abandoned';
  currentStepIndex: number;
  totalSteps: number;
  targetDrillIds: string[];
  steps: AccentMasteryStep[];
  masteryIndex: number; // 0 - 100 aggregate pronunciation score
  bengaliAcousticFlagsDetected: string[];
  summaryBn?: string;
  summaryEn?: string;
  startedAt: string;
  completedAt?: string;
  lastActivityAt: string;
}

// ==============================================================================
// P1-07: Phrasal Particle Sandhi, Accent SRS & Autonomous Sensei Audit Types
// ==============================================================================

export type GrammaticalParticle = 'が' | 'は' | 'を' | 'に' | 'で' | 'の' | 'から' | 'まで';

export type PhrasalSandhiRule =
  | 'heiban_high_propagation'
  | 'odaka_boundary_drop'
  | 'atamadaka_catathesis_propagation'
  | 'nakadaka_catathesis_propagation';

export interface PhrasalPreviewInput {
  word?: string;
  drillId?: string;
  readingKana?: string;
  romaji?: string;
  pattern?: PitchAccentPattern;
  downstepMora?: number;
  particle: string;
  meaningEn?: string;
  meaningBn?: string;
}

export interface PhrasalPitchPreview {
  word: string;
  readingKana: string;
  romaji: string;
  pattern: PitchAccentPattern;
  wordDownstepMora: number;
  particle: string;
  particleRomaji: string;
  particleMeaningBn: string;
  particleFunctionEn: string;
  phraseKanji: string;
  phraseKana: string;
  phraseRomaji: string;
  wordMoraCount: number;
  particleMoraCount: number;
  totalMoraCount: number;
  morae: string[];
  targetPitches: ('H' | 'L')[];
  downstepMora: number; // Downstep locus in combined phrase (0 = none)
  hasDownstepAtParticleBoundary: boolean;
  sandhiRule: PhrasalSandhiRule;
  downstepExplanationBn: string;
  downstepExplanationEn: string;
  relativeContour: number[];
  standardHzContour: number[];
  targetIntensityEnvelope: number[];
  contrastTipBn: string;
}

export interface AccentSrsCard {
  id: string;
  userId: string;
  drillId: string;
  targetPhrase: string;
  readingKana: string;
  romaji: string;
  pattern: PitchAccentPattern;
  downstepMora: number;
  meaningBn: string;
  meaningEn: string;
  category: string;
  stabilityDays: number;
  difficulty: number; // 0.1 to 1.0 (higher = harder)
  repetition: number;
  lapses: number;
  intervalHours: number;
  nextReviewAt: string;
  lastReviewedAt: string | null;
  retentionRate: number; // 0 - 100%
  stage: 'apprentice' | 'guru' | 'master' | 'enlightened' | 'burned';
  acousticRiskLevel: 'low' | 'medium' | 'high';
  chronicDynamicStressCount: number;
  chronicMoraFlatteningCount: number;
  chronicChoonShorteningCount: number;
  lastOverallScore: number;
  lastPitchAccuracyScore: number;
  createdAt: string;
  updatedAt: string;
}

export interface AccentSrsSummary {
  totalDue: number;
  heibanDue: number;
  atamadakaDue: number;
  nakadakaDue: number;
  odakaDue: number;
  highAcousticRiskCount: number;
  upcomingNext24h: number;
  totalTrackedCards: number;
}

export interface AccentSrsReviewSubmission {
  cardId?: string;
  drillId?: string;
  assessment?: Partial<TokyoPitchAccentAssessment>;
  userGrade?: 1 | 2 | 3 | 4; // 1 = Again, 2 = Hard, 3 = Good, 4 = Easy
  hasDynamicStressError?: boolean;
  hasMoraFlatteningError?: boolean;
  hasChoonShorteningError?: boolean;
}

export interface SenseiDiagnosticArea {
  area: string;
  riskLevel: 'critical' | 'moderate' | 'mild';
  detectedAcousticSymptomBn: string;
  neuromuscularCorrectionActionBn: string;
  recommendedDrills: string[];
}

export interface SenseiDiagnosticReport {
  studentId: string;
  generatedAt: string;
  analysisPeriodDays: number;
  evaluationsAnalyzed: number;
  readinessGrade: 'S' | 'A' | 'B' | 'C' | 'D';
  readinessGradeTitleBn: string;
  readinessScore: number; // 0 - 100
  moraConsistencyIndex: number; // 0 - 100
  pitchVsIntensityCorrelation: number; // -1.0 to 1.0
  chronicInterferenceMetrics: {
    dynamicStressTransferRate: number; // 0 - 100%
    moraFlatteningRate: number; // 0 - 100%
    choonVowelRushingRate: number; // 0 - 100%
    sokuonPauseOmissionRate: number; // 0 - 100%
  };
  patternMastery: Record<
    PitchAccentPattern,
    {
      evaluationsCount: number;
      accuracyRate: number;
      passRate: number;
      primaryStumblingBlockBn: string;
    }
  >;
  highRiskInterferenceAreas: SenseiDiagnosticArea[];
  institutionalTeacherSummaryBn: string;
  institutionalTeacherSummaryEn: string;
  srsRetentionForecast: {
    projected7DayRetention: number;
    projected30DayRetention: number;
    activeCardsCount: number;
    burnedCardsCount: number;
  };
}

// ============================================================================
// STEP 6: SENTENCE-LEVEL PROSODY, SHADOWING & SPEAKING READINESS TYPES
// ============================================================================

export interface MoraTimingPoint {
  mora: string;
  startMs: number;
  endMs: number;
  expectedHz: number;
  targetPitch: 'H' | 'L';
}

export interface AccentualPhrase {
  id: string;
  phraseIndex: number;
  text: string;
  readingKana: string;
  romaji: string;
  morae: string[];
  pattern: PitchAccentPattern;
  downstepMora: number; // 0 for Heiban, 1..N for accented
  targetPitches: ('H' | 'L')[];
  boundaryPitchMovement: 'flat' | 'fall' | 'rise';
  hasPauseAfter: boolean;
  pauseDurationMs?: number;
  baseF0Hz: number;
  moraTimingsMs: MoraTimingPoint[];
}

export interface SentenceF0Point {
  timeMs: number;
  f0Hz: number;
  mora: string;
  apIndex: number;
}

export interface SentenceProsodyModel {
  id: string;
  sentenceText: string;
  readingKana: string;
  romaji: string;
  meaningEn: string;
  meaningBn: string;
  jlptLevel: 'N5' | 'N4' | 'N3' | 'N2' | 'N1';
  category: 'daily' | 'baito_interview' | 'keigo_business' | 'directions' | 'travel';
  isQuestion: boolean;
  accentualPhrases: AccentualPhrase[];
  targetF0Contour: SentenceF0Point[];
  totalDurationMs: number;
  tempoMultiplier: number;
}

export interface SentenceProsodyAnalysisInput {
  sentenceText: string;
  readingKana?: string;
  meaningEn?: string;
  meaningBn?: string;
  jlptLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1';
  category?: 'daily' | 'baito_interview' | 'keigo_business' | 'directions' | 'travel';
}

export interface ShadowingApResetEvaluation {
  apIndex: number;
  expectedReset: boolean;
  detectedReset: boolean;
  deltaF0: number;
  feedbackBn: string;
}

export interface ShadowingEvaluationResult {
  evaluationId: string;
  sentenceId: string;
  studentId: string;
  overallScore: number; // 0 - 100
  pitchContourScore: number; // 0 - 100
  rhythmIsochronyScore: number; // 0 - 100
  boundaryResetAccuracyScore: number; // 0 - 100
  questionIntonationScore?: number; // 0 - 100
  dtwDistance: number;
  isPassed: boolean;
  detectedApResets: ShadowingApResetEvaluation[];
  bengaliPhoneticIssues: string[];
  feedbackEn: string;
  feedbackBn: string;
  coachingTipsBn: string[];
  evaluatedAt: string;
}

export interface ShadowingSubmission {
  sentenceId?: string;
  sentenceText?: string;
  userF0Trajectory: number[];
  audioDurationMs: number;
  audioBase64?: string;
  spokenTranscript?: string;
}

export interface SpeakingReadinessCertificate {
  certificateId: string;
  studentId: string;
  studentName: string;
  overallReadinessIndex: number; // 0 - 100%
  certifiedLevel: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | 'Baito-Certified' | 'Business-Certified';
  readinessGrade: 'S' | 'A' | 'B' | 'C' | 'D';
  issueDate: string;
  verificationHash: string;
  evaluationsSampledCount: number;
  subScores: {
    pitchAccuracy: number;
    moraIsochrony: number;
    intonationResetAccuracy: number;
    stressSuppressionScore: number;
    conversationalPacing: number;
  };
  strengthsBn: string[];
  growthAreasBn: string[];
  institutionalSummaryBn: string;
  institutionalSummaryEn: string;
}

// ==============================================================================
// Step 7: Multi-Turn Scenario Roleplay & Institutional Credentialing Types
// ==============================================================================

export interface RoleplaySuggestedResponse {
  ja: string;
  romaji: string;
  bn: string;
  pitchPattern: 'heiban' | 'atamadaka' | 'nakadaka' | 'odaka';
}

export interface RoleplayTurnDefinition {
  turnIndex: number;
  speakerJa: string;
  speakerRomaji: string;
  speakerBn: string;
  expectedIntent: string;
  expectedKeywords: string[];
  targetContourHint: string;
  suggestedResponses: RoleplaySuggestedResponse[];
}

export interface RoleplayScenario {
  id: string;
  titleJa: string;
  titleRomaji: string;
  titleBn: string;
  descriptionBn: string;
  category: 'interview' | 'customer_service' | 'immigration' | 'daily_life';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  turnsCount: number;
  interviewerPersona: {
    name: string;
    roleJa: string;
    roleBn: string;
    avatarIcon: string;
  };
  turns: RoleplayTurnDefinition[];
}

export interface RoleplayTurnEvaluation {
  turnIndex: number;
  userTranscript: string;
  communicationScore: number; // 0 - 100 (Intent, Keigo & keywords)
  acousticResonanceScore: number; // 0 - 100 (Pitch conformity & Bengali stress suppression)
  overallTurnScore: number;
  intentMatched: boolean;
  detectedKeywords: string[];
  missingKeywords: string[];
  pitchContourScore: number;
  stressSuppressionScore: number;
  feedbackBn: string;
  suggestedAlternativeJa: string;
  suggestedAlternativeBn: string;
}

export interface RoleplaySessionState {
  sessionId: string;
  userId: string;
  scenarioId: string;
  currentTurnIndex: number;
  completedTurns: RoleplayTurnEvaluation[];
  isCompleted: boolean;
  finalScores?: {
    communicationScore: number;
    acousticResonanceScore: number;
    overallScore: number;
    feedbackBn: string;
    cefrSpeakingTier: 'A1' | 'A2' | 'B1' | 'B2';
  };
  startedAt: string;
  updatedAt: string;
}

export interface CohortInterferenceHotspot {
  phoneticRuleId: string;
  ruleNameJa: string;
  ruleNameBn: string;
  failureRatePct: number;
  sampleCount: number;
  severity: 'critical' | 'moderate' | 'low';
  averageStressSpikeRate: number;
  remediationTipBn: string;
}

export interface CohortAcousticTelemetry {
  totalLearnersSampled: number;
  totalVoiceAssessmentsSampled: number;
  heibanVsOdakaErrorRatio: number;
  dynamicStressTransferRatePct: number;
  moraFlatteningRatePct: number;
  chōonShorteningRatePct: number;
  hotspots: CohortInterferenceHotspot[];
  tierDistribution: Record<string, number>;
  generatedAt: string;
}

export interface MistakeRecord {
  id: string;
  userId: string;
  itemType: 'KANA' | 'VOCAB' | 'GRAMMAR' | 'KANJI' | 'PARTICLE' | string;
  conceptId: string;
  studentAnswer: string;
  correctAnswer: string;
  notes?: string;
  confusionTag?: string;
  mistakeCount: number;
  resolved: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface WeakAreaRecommendation {
  id: string;
  conceptId: string;
  topic: string;
  itemType: string;
  mistakeCount: number;
  confusionPattern: string;
  confusionExplanationBn: string;
  recommendedLessonId: string;
  recommendationTitle: string;
  recommendationAction: string;
  recommendedDrillType: 'KANA_DRILL' | 'PARTICLE_DRILL' | 'GRAMMAR_DRILL' | 'VOCAB_DRILL' | 'KANJI_DRILL';
}

// ==============================================================================
// GATE 2: NIHOMI FOUNDER HQ & COMPANY BRAIN TYPES
// ==============================================================================

export interface MrrTarget {
  id: string;
  targetAmount: number;
  currency: 'USD' | 'BDT';
  deadline: string; // YYYY-MM-DD
  operatingBudget: number;
  operatingBudgetCurrency: 'USD' | 'BDT';
  growthPriority: 'Bootstrapped' | 'Balanced' | 'Aggressive' | 'Hyper-Growth';
  riskLevel: 'Low' | 'Medium' | 'High';
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MarketTarget {
  id: string;
  primaryMarket: string; // e.g. Bangladesh
  secondaryMarket: string; // e.g. Japan
  experimentalMarket: string; // e.g. Global
  geography: string; // e.g. Dhaka, Chittagong, Sylhet, Tokyo, Osaka
  customerSegment: string; // e.g. Japanese N5 Learners & SSW Aspirants
  language: string; // e.g. Bangla, Japanese, English
  priceRange: string; // e.g. ৳299 - ৳999/mo ($3 - $10)
  acquisitionChannels: string[]; // e.g. Facebook Groups, YouTube Organic, Campus Ambassadors
  priority: 'P0' | 'P1' | 'P2';
  timeframe: string; // e.g. Q4 2026 (30-90 Days)
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ActiveBusinessObjective {
  goal: string;
  market: string;
  segment: string;
  timeframe: string;
  budget: string;
  status: 'ACTIVE' | 'PAUSED' | 'ACHIEVED' | 'REVIEW_REQUIRED';
  mrrTarget?: MrrTarget;
  marketTarget?: MarketTarget;
}

export type AiDepartmentStatus = 
  | 'RUNNING'
  | 'PAUSED'
  | 'BLOCKED'
  | 'NEEDS_APPROVAL'
  | 'ERROR'
  | 'NOT_CONFIGURED';

export interface AiOfficeDepartment {
  id: string;
  code: string;
  name: string;
  role: string;
  description: string;
  status: AiDepartmentStatus;
  statusDetails?: string;
  currentTask?: string;
  lastActiveAt?: string;
  monthlyBudgetLimit: number;
  monthlyBudgetCurrency: 'BDT';
  spentThisMonth: number;
  concurrencyLimit: number;
}

export type ApprovalRequestStatus =
  | 'PENDING'
  | 'APPROVED'
  | 'REJECTED'
  | 'CHANGES_REQUESTED'
  | 'CANCELLED'
  | 'COMPLETED';

export interface ApprovalRequest {
  request_id: string;
  request: string;
  department: string;
  amount: number;
  currency: 'BDT' | 'USD';
  risk: 'Low' | 'Medium' | 'High' | 'Critical';
  expected_outcome: string;
  AI_recommendation: string;
  status: ApprovalRequestStatus;
  founder_decision?: string;
  founder_notes?: string;
  created_at: string;
  decided_at?: string;
  result?: string;
}

export interface BudgetWallet {
  id: string;
  name: string;
  description: string;
  monthly_limit: number;
  daily_limit: number;
  approval_threshold: number;
  alert_threshold: number;
  spent_amount: number;
  remaining_amount: number;
  currency: 'BDT';
  status: 'HEALTHY' | 'ALERT_TRIGGERED' | 'LOCKED';
  updatedAt: string;
}

export interface FounderAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  actorEmail: string;
  action: string;
  target: string;
  reason: string;
  dataSource: string;
  risk: 'Low' | 'Medium' | 'High' | 'Critical';
  approvalStatus: 'NOT_REQUIRED' | 'PENDING' | 'APPROVED' | 'REJECTED';
  result: 'SUCCESS' | 'DENIED' | 'FAILED' | 'QUEUED';
  ipAddress?: string;
  metadata?: Record<string, any>;
}

export type CompanyBrainCategory =
  | 'CONSTITUTION'
  | 'VISION_MISSION'
  | 'BUSINESS_GOALS'
  | 'MARKET_STRATEGY'
  | 'PRODUCT_STRATEGY'
  | 'CUSTOMER_INTELLIGENCE'
  | 'EXPERIMENT_REGISTRY'
  | 'DECISION_LOG'
  | 'RISK_REGISTER'
  | 'INCIDENT_LOG'
  | 'CEO_REPORTS'
  | 'LESSONS_LEARNED'
  | 'SOP_REFERENCE';

export interface CompanyBrainItem {
  id: string;
  category: CompanyBrainCategory;
  title: string;
  summary: string;
  content: string;
  author: string;
  tags: string[];
  status: 'ACTIVE' | 'ARCHIVED' | 'DRAFT';
  createdAt: string;
  updatedAt: string;
}






