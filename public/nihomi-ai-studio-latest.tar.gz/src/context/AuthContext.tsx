import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { setStoredToken, apiRequest, getStoredToken } from '../lib/api';

export interface User {
  id: string;
  email: string;
  name: string;
  displayName?: string;
  full_name?: string;
  nameJa?: string;
  phone?: string;
  avatar?: string;
  avatarUrl?: string;
  role: 'student' | 'instructor' | 'admin' | 'founder' | string;
  planId: 'free' | 'starter' | 'pro' | 'japan_ready' | string;
  status: 'ACTIVE' | 'SUSPENDED' | 'ARCHIVED' | string;
  studentId: string;
  nihomiAccountId: string;
  country?: string;
  streakDays?: number;
  currentLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | string;
  targetLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | string;
  enrolledDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  userId: string;
  name?: string;
  displayName?: string;
  avatar?: string;
  avatarUrl?: string;
  targetLevel: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | string;
  currentLevel?: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | string;
  targetExam: string;
  targetExamDate: string;
  preferredSensei: string;
  preferredLanguage: string;
  nativeLanguage?: string;
  bio?: string;
  dailyGoalMinutes: number;
  nihomiAccountId?: string;
}

export interface UserProgress {
  userId: string;
  currentLevel: 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | string;
  streakDays: number;
  currentStreak?: number;
  longestStreak?: number;
  totalHours: number;
  totalStudyMinutes?: number;
  completedLessonsCount: number;
  completedLessonIds?: string[];
  experiencePoints?: number;
  retentionRate?: number;
  lastActivityDate?: string;
}

export interface UserSubscription {
  userId: string;
  planId: 'free' | 'starter' | 'pro' | 'japan_ready' | string;
  planName: string;
  status: 'active' | 'trial' | 'expired' | 'cancelled' | string;
  validUntil: string;
  billingCycle: 'monthly' | 'yearly' | string;
  aiCreditsRemaining: number;
  paymentMethod: 'bkash' | 'sslcommerz' | 'card' | 'eps' | 'paddle' | string;
  features?: string[];
  subscription?: any;
  usage?: any;
  plan?: any;
}

export interface LearningDNAData {
  userId: string;
  vocabMasteryRate: number;
  grammarMasteryRate: number;
  kanjiMasteryRate: number;
  listeningScore: number;
  speakingScore: number;
  learningVelocity: number;
  diagnosedWeaknesses: Array<{
    category: string;
    item: string;
    description: string;
    frequency: number;
  }>;
  lastPracticedAt: string;
}

export interface CoinWalletData {
  userId: string;
  coinBalance: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
}

export const PLAN_CONFIGS: Record<string, any> = {
  free: {
    planId: 'free',
    planName: 'Nihomi Free Basic',
    priceUSD: 0,
    priceBDT: 0,
    features: ['Hiragana & Katakana Mastery', 'N5 Lessons 1–3 Access', 'Basic Spaced Repetition', 'Community Support'],
  },
  starter: {
    planId: 'starter',
    planName: 'Starter Learner',
    priceUSD: 9,
    priceBDT: 990,
    features: ['Full JLPT N5 Curriculum', 'Standard AI Sensei Q&A', '100 Monthly Nihomi Coins', 'Digital Student ID'],
  },
  pro: {
    planId: 'pro',
    planName: 'Nihomi PRO Learning',
    priceUSD: 19,
    priceBDT: 1990,
    features: ['Complete JLPT N5 + N4 Curriculum', 'Voice & Photo OCR Sensei', '500 Monthly Nihomi Coins', 'Full Learning DNA Memory'],
  },
  japan_ready: {
    planId: 'japan_ready',
    planName: 'Japan Ready Continuous Track',
    priceUSD: 39,
    priceBDT: 3990,
    features: ['Unrestricted N5 to N1 Access', '1,500 Monthly Nihomi Coins', 'Interview & Visa Simulation', 'Priority AI Routing'],
  },
};

export interface AuthContextType {
  token: string | null;
  user: User | null;
  profile: UserProfile | null;
  progress: UserProgress | null;
  subscription: UserSubscription | null;
  subscriptionDetails: UserSubscription | null;
  activePlanId: string;
  learningDNA: LearningDNAData | null;
  coinWallet: CoinWalletData | null;
  loading: boolean;
  isLoading: boolean;
  isAuthModalOpen: boolean;
  openAuthModal: (mode?: string) => void;
  openLoginModal: (mode?: string) => void;
  closeAuthModal: () => void;
  setUserData: (user: User) => void;
  loginWithGoogle: () => Promise<boolean>;
  loginWithGoogleFirebase: () => Promise<boolean>;
  loginWithToken: (idToken: string) => Promise<boolean>;
  login: (email?: string, password?: string) => Promise<boolean>;
  register: (data?: any) => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfileData: (data: Partial<UserProfile & { name?: string; nameJa?: string; phone?: string; displayName?: string; bio?: string; nativeLanguage?: string }>) => Promise<void>;
  updateProfile: (data: any) => Promise<void>;
  updateSubscriptionPlan: (planId: 'free' | 'starter' | 'pro' | 'japan_ready' | string, method?: 'card' | 'eps' | 'paddle' | 'bkash' | string) => Promise<void>;
  topUpCredits: (amount: number) => Promise<void>;
  refreshSubscription: () => Promise<void>;
  refreshProgress: () => Promise<void>;
  refreshUser: () => Promise<void>;
  refreshAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  token: null,
  user: null,
  profile: null,
  progress: null,
  subscription: null,
  subscriptionDetails: null,
  activePlanId: 'starter',
  learningDNA: null,
  coinWallet: null,
  loading: false,
  isLoading: false,
  isAuthModalOpen: false,
  openAuthModal: () => {},
  openLoginModal: () => {},
  closeAuthModal: () => {},
  setUserData: () => {},
  loginWithGoogle: async () => false,
  loginWithGoogleFirebase: async () => false,
  loginWithToken: async () => false,
  login: async () => true,
  register: async () => true,
  logout: async () => {},
  updateProfileData: async () => {},
  updateProfile: async () => {},
  updateSubscriptionPlan: async () => {},
  topUpCredits: async () => {},
  refreshSubscription: async () => {},
  refreshProgress: async () => {},
  refreshUser: async () => {},
  refreshAuth: async () => {},
});

const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return localStorage.getItem(key);
      }
    } catch {}
    return null;
  },
  setItem: (key: string, value: string): void => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(key, value);
      }
    } catch {}
  },
  removeItem: (key: string): void => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.removeItem(key);
      }
    } catch {}
  }
};

const bootstrapDefaultLearningPath = (userId: string) => {
  const pathKey = `nihomi_learning_path_${userId}`;
  if (safeStorage.getItem(pathKey)) return;
  const phases = [
    { days: [1, 2, 3, 4, 5, 6, 7], focus: 'Hiragana foundations' },
    { days: [8, 9, 10, 11, 12, 13, 14], focus: 'Katakana foundations' },
    { days: [15, 16, 17, 18, 19, 20, 21], focus: 'N5 vocabulary and particles' },
    { days: [22, 23, 24, 25, 26, 27], focus: 'N5 conversation and review' },
  ];
  const learningPath = phases.flatMap((phase) => phase.days.map((day) => ({
    day,
    title: `Day ${day}: ${phase.focus}`,
    status: day === 1 ? 'available' : 'upcoming',
    completed: false,
  })));
  safeStorage.setItem(pathKey, JSON.stringify({ userId, level: 'N5', learningPath, bootstrappedAt: new Date().toISOString() }));
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = safeStorage.getItem('nihomi_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [profile, setProfile] = useState<UserProfile | null>(() => {
    try {
      const saved = safeStorage.getItem('nihomi_profile');
      return saved ? JSON.parse(saved) : {
        userId: 'default_user',
        targetLevel: 'N5',
        targetExam: 'JLPT July 2026',
        targetExamDate: '2026-07-05',
        preferredSensei: 'Yuki (Adaptive)',
        preferredLanguage: 'English',
        dailyGoalMinutes: 30,
      };
    } catch {
      return null;
    }
  });

  const [progress, setProgress] = useState<UserProgress | null>(() => {
    try {
      const saved = safeStorage.getItem('nihomi_progress');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      userId: 'guest',
      currentLevel: 'N5',
      streakDays: 0,
      totalHours: 0,
      completedLessonsCount: 0,
    };
  });

  const [subscription, setSubscription] = useState<UserSubscription | null>(() => {
    try {
      const saved = safeStorage.getItem('nihomi_subscription');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      userId: 'guest',
      planId: 'free',
      planName: 'Nihomi Free Basic',
      status: 'active',
      validUntil: '2026-12-31',
      billingCycle: 'monthly',
      aiCreditsRemaining: 100,
      paymentMethod: 'bkash',
    };
  });

  const [learningDNA] = useState<LearningDNAData | null>({
    userId: user?.id || 'default_user',
    vocabMasteryRate: 78,
    grammarMasteryRate: 82,
    kanjiMasteryRate: 65,
    listeningScore: 74,
    speakingScore: 80,
    learningVelocity: 1.25,
    diagnosedWeaknesses: [
      { category: 'Grammar', item: 'Particle に vs で', description: 'Action location vs destination context', frequency: 3 },
      { category: 'Kanji', item: 'Time & Days', description: 'Onyomi/Kunyomi confusion on 日 and 月', frequency: 2 }
    ],
    lastPracticedAt: new Date().toISOString(),
  });

  const [coinWallet] = useState<CoinWalletData | null>({
    userId: user?.id || 'default_user',
    coinBalance: 500,
    lifetimeEarned: 1200,
    lifetimeSpent: 700,
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  const openAuthModal = (_mode?: string) => setIsAuthModalOpen(true);
  const closeAuthModal = () => setIsAuthModalOpen(false);

  const setUserData = (newUser: User) => {
    // Ensure Digital Student ID and Nihomi Account ID
    if (!newUser.studentId) {
      newUser.studentId = 'NHO-' + Math.floor(100000 + Math.random() * 900000);
    }
    if (!newUser.nihomiAccountId) {
      newUser.nihomiAccountId = 'ACC-' + Math.floor(1000 + Math.random() * 9000);
    }
    // Allocate starter 50 Coins + 100 AI Credits for all new students
    if (!safeStorage.getItem('nihomi_student_coins')) {
      safeStorage.setItem('nihomi_student_coins', '50');
    }
    if (!safeStorage.getItem('nihomi_ai_credits')) {
      safeStorage.setItem('nihomi_ai_credits', '100');
    }
    setUser(newUser);
    safeStorage.setItem('nihomi_user', JSON.stringify(newUser));
  };

  // Listen to Supabase Session & extract Google Avatar
  useEffect(() => {
    // Check initial stored token and verify with /api/auth/me
    const initialToken = getStoredToken();
    if (initialToken) {
      apiRequest('/api/auth/me')
        .then((res) => {
          if (res?.authenticated && res.user) {
            setUserData(res.user);
            if (res.profile) setProfile(res.profile);
            if (res.progress) setProgress(res.progress);
          }
        })
        .catch(() => {});
    }

    if (typeof window !== 'undefined' && window.location.hash && window.location.hash.includes('access_token')) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user && session.access_token) {
          setStoredToken(session.access_token);
          setToken(session.access_token);
          safeStorage.setItem('nihomi_auth_token', session.access_token);
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      });
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        if (session.access_token) {
          setStoredToken(session.access_token);
          setToken(session.access_token);
          safeStorage.setItem('nihomi_auth_token', session.access_token);
        }
        const u = session.user;
        const isFounder = u.email === 'mdtanvirkabirbiplob@gmail.com';
        const avatar =
          u.user_metadata?.avatar_url ||
          u.user_metadata?.picture ||
          u.user_metadata?.avatar ||
          undefined;

        const activeUser: User = {
          id: u.id,
          email: u.email || 'nihomibd@gmail.com',
          name: u.user_metadata?.full_name || u.user_metadata?.name || u.email?.split('@')[0] || 'Nihomi Student',
          avatarUrl: avatar,
          role: isFounder ? 'founder' : 'student',
          planId: isFounder ? 'japan_ready' : 'starter',
          status: 'ACTIVE',
          studentId: 'NHO-' + Math.floor(100000 + Math.random() * 900000),
          nihomiAccountId: 'ACC-' + Math.floor(1000 + Math.random() * 9000),
          createdAt: u.created_at || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        bootstrapDefaultLearningPath(activeUser.id);
        setUserData(activeUser);

        // Sync with backend /api/auth/me to populate verified profile & progress
        apiRequest('/api/auth/me').then((res) => {
          if (res?.authenticated && res.user) {
            if (res.profile) setProfile(res.profile);
            if (res.progress) setProgress(res.progress);
          }
        }).catch(() => {});
      }
    });

    const { data: { subscription: authListener } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        if (session.access_token) {
          setStoredToken(session.access_token);
          setToken(session.access_token);
          safeStorage.setItem('nihomi_auth_token', session.access_token);
        }
        const u = session.user;
        const isFounder = u.email === 'mdtanvirkabirbiplob@gmail.com';
        const avatar =
          u.user_metadata?.avatar_url ||
          u.user_metadata?.picture ||
          u.user_metadata?.avatar ||
          undefined;

        const activeUser: User = {
          id: u.id,
          email: u.email || 'nihomibd@gmail.com',
          name: u.user_metadata?.full_name || u.user_metadata?.name || u.email?.split('@')[0] || 'Nihomi Student',
          avatarUrl: avatar,
          role: isFounder ? 'founder' : 'student',
          planId: isFounder ? 'japan_ready' : 'starter',
          status: 'ACTIVE',
          studentId: 'NHO-' + Math.floor(100000 + Math.random() * 900000),
          nihomiAccountId: 'ACC-' + Math.floor(1000 + Math.random() * 9000),
          createdAt: u.created_at || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        bootstrapDefaultLearningPath(activeUser.id);
        setUserData(activeUser);

        // Sync with backend /api/auth/me
        apiRequest('/api/auth/me').then((res) => {
          if (res?.authenticated && res.user) {
            if (res.profile) setProfile(res.profile);
            if (res.progress) setProgress(res.progress);
          }
        }).catch(() => {});
      } else if (_event === 'SIGNED_OUT') {
        setUser(null);
        setStoredToken(null);
        setToken(null);
        safeStorage.removeItem('nihomi_user');
        safeStorage.removeItem('nihomi_auth_token');
      }
    });

    return () => {
      authListener?.unsubscribe();
    };
  }, []);

  const loginWithGoogle = async (): Promise<boolean> => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          queryParams: { prompt: 'select_account' },
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
      return true;
    } catch (err: any) {
      console.error('[Supabase Google Sign-In Error]:', err);
      return false;
    }
  };

  const loginWithGoogleFirebase = async (): Promise<boolean> => {
    return loginWithGoogle();
  };

  const loginWithToken = async (idToken: string): Promise<boolean> => {
    if (!idToken) return false;
    try {
      const res = await apiRequest<{
        token: string;
        user: User;
        profile: UserProfile;
        progress: UserProgress;
      }>('/api/auth/google', {
        method: 'POST',
        body: JSON.stringify({ googleToken: idToken })
      });
      if (res.token) {
        setStoredToken(res.token);
        setToken(res.token);
      }
      if (res.user) {
        setUserData(res.user);
      }
      if (res.profile) {
        setProfile(res.profile);
        safeStorage.setItem('nihomi_profile', JSON.stringify(res.profile));
      }
      if (res.progress) {
        setProgress(res.progress);
      }
      return true;
    } catch (err: any) {
      console.error('[Google ID Token Login Error]:', err);
      return false;
    }
  };

  const logout = async () => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST' }).catch(() => {});
    } catch {}
    await supabase.auth.signOut().catch(() => {});
    setStoredToken(null);
    setToken(null);
    setUser(null);
    setProfile(null);
    setProgress({
      userId: 'guest',
      currentLevel: 'N5',
      streakDays: 0,
      totalHours: 0,
      completedLessonsCount: 0,
    });
    safeStorage.removeItem('nihomi_user');
    safeStorage.removeItem('nihomi_profile');
    safeStorage.removeItem('nihomi_progress');
    safeStorage.removeItem('nihomi_subscription');
  };

  const updateProfileData = async (data: Partial<UserProfile & { name?: string; nameJa?: string; phone?: string }>) => {
    if (profile) {
      const updated = { ...profile, ...data };
      setProfile(updated as UserProfile);
      safeStorage.setItem('nihomi_profile', JSON.stringify(updated));
    }
  };

  const updateSubscriptionPlan = async (planId: 'free' | 'starter' | 'pro' | 'japan_ready', method: 'card' | 'eps' | 'paddle' | 'bkash' = 'bkash') => {
    if (user) {
      const updatedUser = { ...user, planId };
      setUserData(updatedUser);
      if (subscription) {
        const updatedSub = { ...subscription, planId, paymentMethod: method };
        setSubscription(updatedSub);
      }
    }
  };

  const login = async (email?: string, password?: string): Promise<boolean> => {
    if (!email || !password) return false;
    try {
      const data = await apiRequest<{
        token: string;
        user: User;
        profile: UserProfile;
        progress: UserProgress;
      }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });

      if (data.token) {
        setStoredToken(data.token);
        setToken(data.token);
      }
      if (data.user) {
        setUserData(data.user);
      }
      if (data.profile) {
        setProfile(data.profile);
        safeStorage.setItem('nihomi_profile', JSON.stringify(data.profile));
      }
      if (data.progress) {
        setProgress(data.progress);
      }
      return true;
    } catch (err: any) {
      console.error('[AuthContext Login Error]:', err);
      return false;
    }
  };

  const register = async (regData?: any): Promise<boolean> => {
    if (!regData || !regData.email || !regData.password) return false;
    try {
      const data = await apiRequest<{
        token: string;
        user: User;
        profile: UserProfile;
        progress: UserProgress;
      }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(regData)
      });

      if (data.token) {
        setStoredToken(data.token);
        setToken(data.token);
      }
      if (data.user) {
        setUserData(data.user);
      }
      if (data.profile) {
        setProfile(data.profile);
        safeStorage.setItem('nihomi_profile', JSON.stringify(data.profile));
      }
      if (data.progress) {
        setProgress(data.progress);
      }
      return true;
    } catch (err: any) {
      console.error('[AuthContext Register Error]:', err);
      return false;
    }
  };

  const updateProfile = async (data: any) => updateProfileData(data);
  const topUpCredits = async (amount: number) => {
    if (subscription) {
      setSubscription({
        ...subscription,
        aiCreditsRemaining: (subscription.aiCreditsRemaining || 0) + amount,
      });
    }
  };

  const refreshSubscription = useCallback(async () => {
    try {
      const token = getStoredToken();
      if (!token) return;
      const res = await apiRequest('/api/billing/subscription');
      if (res && res.subscription) {
        setSubscription(res.subscription);
      }
    } catch {}
  }, []);

  const refreshProgress = useCallback(async () => {
    try {
      const token = getStoredToken();
      if (!token) return;
      const res = await apiRequest('/api/learning/progress');
      if (res && res.progress) {
        setProgress(res.progress);
      }
    } catch {}
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const token = getStoredToken();
      if (!token) return;
      const res = await apiRequest('/api/auth/me');
      if (res && res.user) {
        setUserData(res.user);
        if (res.profile) setProfile(res.profile);
        if (res.progress) setProgress(res.progress);
      }
    } catch {}
  }, []);

  const refreshAuth = useCallback(async () => {
    await refreshUser();
    await refreshSubscription();
    await refreshProgress();
  }, [refreshUser, refreshSubscription, refreshProgress]);

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        profile,
        progress,
        subscription,
        subscriptionDetails: subscription,
        activePlanId: user?.planId || 'starter',
        learningDNA,
        coinWallet,
        loading: false,
        isLoading: false,
        isAuthModalOpen,
        openAuthModal,
        openLoginModal: openAuthModal,
        closeAuthModal,
        setUserData,
        loginWithGoogle,
        loginWithGoogleFirebase,
        loginWithToken,
        login,
        register,
        logout,
        updateProfileData,
        updateProfile,
        updateSubscriptionPlan,
        topUpCredits,
        refreshSubscription,
        refreshProgress,
        refreshUser,
        refreshAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);




