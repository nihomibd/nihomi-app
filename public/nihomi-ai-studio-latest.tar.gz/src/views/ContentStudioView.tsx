import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Layers,
  Upload,
  CheckCircle2,
  AlertTriangle,
  FileText,
  BookOpen,
  Eye,
  Send,
  RefreshCw,
  Plus,
  ArrowRight,
  Check,
  ShieldCheck,
  Zap,
  Volume2,
  Mic,
  PenTool,
  Brain,
  Award,
  Hash,
  Database,
  Search,
  Filter,
  BarChart2,
  ChevronRight,
  ExternalLink,
  Lock,
  Download,
  Flame,
  FileCode,
  FilePlus,
  Sliders,
  X,
  Clock,
  ListOrdered,
  Play,
  Calendar,
  RotateCcw,
  Rocket,
  Briefcase,
  HelpCircle,
  Repeat
} from 'lucide-react';
import {
  StudioLesson,
  ContentStudioStats,
  LessonSourceFile,
  LessonCurriculumMap,
  StudioQAReport,
  SupportedSourceFileType
} from '../core/content-studio/types';
import { DEFAULT_STUDIO_LESSONS } from '../core/content-studio/defaultLessons';
import { JLPTLevel } from '../types/nihomi';
import { ContentDesignSystem } from '../core/content-engine/contentDesignSystem';

interface ContentStudioViewProps {
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const ContentStudioView: React.FC<ContentStudioViewProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<ContentStudioStats | null>(null);
  const [lessons, setLessons] = useState<StudioLesson[]>(() => DEFAULT_STUDIO_LESSONS);
  const [selectedLesson, setSelectedLesson] = useState<StudioLesson | null>(() => DEFAULT_STUDIO_LESSONS[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedLevelFilter, setSelectedLevelFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [activeSectionTab, setActiveSectionTab] = useState<string>('overview');
  const [showQaModal, setShowQaModal] = useState<boolean>(false);
  const [studentPreviewTab, setStudentPreviewTab] = useState<'overview' | 'vocab' | 'grammar' | 'dialogue' | 'quiz'>('overview');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processStepMessage, setProcessStepMessage] = useState<string>('');
  const [showNewLessonModal, setShowNewLessonModal] = useState<boolean>(false);
  const [showStudentPreviewModal, setShowStudentPreviewModal] = useState<boolean>(false);

  // Publishing Queue State (P1-03)
  const [showPublishingQueueModal, setShowPublishingQueueModal] = useState<boolean>(false);
  const [publishingQueue, setPublishingQueue] = useState<any[]>([]);
  const [queueStats, setQueueStats] = useState<{ queued: number; scheduledCount: number; completed: number; failed: number; total: number } | null>(null);
  const [isQueueLoading, setIsQueueLoading] = useState<boolean>(false);
  const [showEnqueueModal, setShowEnqueueModal] = useState<boolean>(false);
  const [enqueueTargetLesson, setEnqueueTargetLesson] = useState<StudioLesson | null>(null);
  const [enqueuePriority, setEnqueuePriority] = useState<'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW'>('NORMAL');
  const [enqueueScheduledDate, setEnqueueScheduledDate] = useState<string>('');
  const [enqueueChangelog, setEnqueueChangelog] = useState<string>('');
  const [preflightModalReport, setPreflightModalReport] = useState<any | null>(null);
  const [showPreflightModal, setShowPreflightModal] = useState<boolean>(false);

  // Wizard state for new lesson ingestion
  const [wizardStep, setWizardStep] = useState<number>(1);
  const [wizardLevel, setWizardLevel] = useState<JLPTLevel>('N5');
  const [wizardLessonNumber, setWizardLessonNumber] = useState<number>(2);
  const [wizardTitle, setWizardTitle] = useState<string>('Demonstratives (kore/sore/are) & Belonging');
  const [wizardTitleJa, setWizardTitleJa] = useState<string>('これ・それ・あれ と 助詞「の」');
  const [wizardTitleBn, setWizardTitleBn] = useState<string>('নির্দেশক সর্বনাম ও অধিকারবাচক মার্কার の');
  const [wizardTheme, setWizardTheme] = useState<string>('Shopping and Identifying Objects in Tokyo');
  const [wizardRawSources, setWizardRawSources] = useState<Array<{ name: string; type: SupportedSourceFileType; text: string }>>([
    {
      name: 'Minna_No_Nihongo_Lesson_02.txt',
      type: 'TXT',
      text: '第2課：これは 本です。それは わたしの 傘です。あれは 誰の カバンですか。この本は 日本語の本です。...'
    }
  ]);
  const [activeWizardLesson, setActiveWizardLesson] = useState<StudioLesson | null>(null);

  const fetchStudioData = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('nihomi_auth_token') || localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const statsRes = await fetch('/api/content-studio/stats', { headers });
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        if (statsData.stats) setStats(statsData.stats);
      }

      const lessonsRes = await fetch('/api/content-studio/lessons', { headers });
      if (lessonsRes.ok) {
        const lessonsData = await lessonsRes.json();
        if (lessonsData.lessons && lessonsData.lessons.length > 0) {
          // Merge lessons: ensure les-c49255 is kept if missing
          const apiLessons: StudioLesson[] = lessonsData.lessons;
          const hasL1 = apiLessons.some((l) => l.id === 'les-c49255');
          const mergedLessons = hasL1 ? apiLessons : [...DEFAULT_STUDIO_LESSONS.filter((dl) => dl.id === 'les-c49255'), ...apiLessons];

          setLessons(mergedLessons);
          if (!selectedLesson) {
            const defaultSelection = mergedLessons.find((l: StudioLesson) => l.id === 'les-c49255') || mergedLessons[0];
            setSelectedLesson(defaultSelection);
          } else {
            const fresh = mergedLessons.find((l: StudioLesson) => l.id === selectedLesson.id);
            if (fresh) setSelectedLesson(fresh);
          }
        }
      }

      // Fetch queue stats
      const qStatsRes = await fetch('/api/content-studio/publishing-queue/stats', { headers });
      if (qStatsRes.ok) {
        const qData = await qStatsRes.json();
        if (qData.stats) setQueueStats(qData.stats);
      }
    } catch (err) {
      console.warn('[ContentStudioView] Error fetching Content Studio data, using loaded fallback lessons:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchPublishingQueueData = async () => {
    setIsQueueLoading(true);
    try {
      const [queueRes, statsRes] = await Promise.all([
        fetch('/api/content-studio/publishing-queue'),
        fetch('/api/content-studio/publishing-queue/stats')
      ]);
      if (queueRes.ok) {
        const qData = await queueRes.json();
        setPublishingQueue(qData.queue || []);
      }
      if (statsRes.ok) {
        const sData = await statsRes.json();
        setQueueStats(sData.stats);
      }
    } catch (err) {
      console.error('Failed to load publishing queue:', err);
    } finally {
      setIsQueueLoading(false);
    }
  };

  const handleOpenPublishingQueue = () => {
    setShowPublishingQueueModal(true);
    fetchPublishingQueueData();
  };

  const handleOpenEnqueueDialog = (lesson: StudioLesson) => {
    setEnqueueTargetLesson(lesson);
    setEnqueuePriority('NORMAL');
    setEnqueueScheduledDate('');
    setEnqueueChangelog(`Live publication release for ${lesson.title}`);
    setShowEnqueueModal(true);
  };

  const handleConfirmEnqueue = async () => {
    if (!enqueueTargetLesson) return;
    setIsProcessing(true);
    setProcessStepMessage(`Enqueuing "${enqueueTargetLesson.title}" into live publishing queue...`);
    try {
      const res = await fetch('/api/content-studio/publishing-queue/enqueue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          draftId: enqueueTargetLesson.id,
          priority: enqueuePriority,
          scheduledFor: enqueueScheduledDate ? new Date(enqueueScheduledDate).toISOString() : undefined,
          changelog: enqueueChangelog
        })
      });
      const data = await res.json();
      if (!res.ok) {
        alert(`Failed to enqueue: ${data.error || 'Unknown error'}`);
        return;
      }
      setShowEnqueueModal(false);
      fetchStudioData();
      fetchPublishingQueueData();
      setShowPublishingQueueModal(true);
    } catch (err: any) {
      alert(`Error enqueuing: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCancelQueueJob = async (jobId: string) => {
    if (!confirm('Cancel this queued publishing job?')) return;
    try {
      const res = await fetch(`/api/content-studio/publishing-queue/${jobId}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Failed to cancel job');
        return;
      }
      fetchPublishingQueueData();
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleRetryQueueJob = async (jobId: string) => {
    try {
      const res = await fetch(`/api/content-studio/publishing-queue/${jobId}/retry`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Failed to retry job');
        return;
      }
      fetchPublishingQueueData();
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleProcessNextInQueue = async () => {
    setIsProcessing(true);
    setProcessStepMessage('Triggering queue worker to process next ready item...');
    try {
      const res = await fetch('/api/content-studio/publishing-queue/process-next', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.result?.processed) {
        alert('Next ready item processed successfully!');
      } else {
        alert('No ready queued items to process at this time.');
      }
      fetchStudioData();
      fetchPublishingQueueData();
    } catch (err: any) {
      alert(`Failed to process: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInspectPreflight = async (lessonId: string) => {
    try {
      const res = await fetch(`/api/content-studio/drafts/${lessonId}/preflight`);
      if (res.ok) {
        const data = await res.json();
        setPreflightModalReport(data.report);
        setShowPreflightModal(true);
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to generate pre-flight report');
      }
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    }
  };

  useEffect(() => {
    fetchStudioData();
  }, []);

  const handleStartWizard = () => {
    setWizardStep(1);
    setActiveWizardLesson(null);
    setShowNewLessonModal(true);
  };

  const handleCreateDraft = async () => {
    setIsProcessing(true);
    setProcessStepMessage('Creating Studio Lesson Draft...');
    try {
      const payload = {
        level: wizardLevel,
        lessonNumber: Number(wizardLessonNumber),
        title: wizardTitle,
        titleJa: wizardTitleJa,
        titleBn: wizardTitleBn,
        theme: wizardTheme,
        courseId: `jlpt-${wizardLevel.toLowerCase()}-mastery`
      };

      const res = await fetch('/api/content-studio/lessons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.lesson) {
        setActiveWizardLesson(data.lesson);
        // Add default source
        if (wizardRawSources.length > 0) {
          await fetch(`/api/content-studio/lessons/${data.lesson.id}/sources`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              filename: wizardRawSources[0].name,
              fileType: wizardRawSources[0].type,
              rawText: wizardRawSources[0].text
            })
          });
        }
        setWizardStep(2);
      }
    } catch (err) {
      console.error('Failed to create draft:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExtractCurriculumMap = async () => {
    if (!activeWizardLesson) return;
    setIsProcessing(true);
    setProcessStepMessage('AI Parsing Sources & Building Stable Curriculum Map (N5-L02-G001...)...');
    try {
      const res = await fetch(`/api/content-studio/lessons/${activeWizardLesson.id}/analyze-sources`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.lesson) {
        setActiveWizardLesson(data.lesson);
        setWizardStep(3);
      }
    } catch (err) {
      console.error('Failed to extract curriculum map:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleGenerate14Sections = async () => {
    if (!activeWizardLesson) return;
    setIsProcessing(true);
    setProcessStepMessage('Synthesizing 14 Pedagogical Sections (Dialogue, Grammar, QA Pass)...');
    try {
      const res = await fetch(`/api/content-studio/lessons/${activeWizardLesson.id}/generate`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.lesson) {
        setActiveWizardLesson(data.lesson);
        setSelectedLesson(data.lesson);
        setWizardStep(4);
        fetchStudioData();
      }
    } catch (err) {
      console.error('Failed to generate 14 sections:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleTogglePublish = async (lessonId: string) => {
    setIsProcessing(true);
    const target = lessons.find(l => l.id === lessonId) || selectedLesson;
    const isCurrentlyPublished = target?.status === 'PUBLISHED';
    setProcessStepMessage(
      isCurrentlyPublished
        ? 'Reverting lesson status to DRAFT and unpublishing from live catalog...'
        : 'Executing 23-Point NIHOMI STANDARD™ QA Audit & Publishing to Live Catalog...'
    );
    try {
      const endpoint = isCurrentlyPublished
        ? `/api/content-studio/lessons/${lessonId}/unpublish`
        : `/api/content-studio/lessons/${lessonId}/publish`;
      
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ founderApproved: true })
      });
      const data = await res.json();
      if (data.lesson) {
        setSelectedLesson(data.lesson);
        setLessons(prev => prev.map(l => l.id === lessonId ? data.lesson : l));
        if (activeWizardLesson?.id === lessonId) {
          setActiveWizardLesson(data.lesson);
          if (!isCurrentlyPublished) setWizardStep(5);
        }
        fetchStudioData();
      } else if (data.error) {
        alert(`Action Error: ${data.error}`);
      }
    } catch (err: any) {
      console.error('Publish toggle error:', err);
      alert(`Network error: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePublishLesson = handleTogglePublish;

  const filteredLessons = lessons.filter((l) => {
    const levelMatch =
      selectedLevelFilter === 'ALL' ||
      (l.level && l.level.toUpperCase() === selectedLevelFilter.toUpperCase());
    const statusMatch =
      selectedStatusFilter === 'ALL' ||
      (l.status && l.status.toUpperCase() === selectedStatusFilter.toUpperCase());
    const q = searchQuery.trim().toLowerCase();
    const searchMatch =
      !q ||
      l.title?.toLowerCase().includes(q) ||
      l.titleJa?.toLowerCase().includes(q) ||
      l.titleBn?.toLowerCase().includes(q) ||
      l.id?.toLowerCase().includes(q) ||
      l.theme?.toLowerCase().includes(q);
    return levelMatch && statusMatch && searchMatch;
  });

  return (
    <div className="min-h-screen bg-[#0a0a12] text-slate-100 font-sans pb-24 pt-24 md:pt-28 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Top Master Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-800">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <span className="p-2 rounded-xl bg-red-600/20 text-red-400 border border-red-500/30">
                <Brain className="w-6 h-6 animate-pulse" />
              </span>
              <div>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
                  NIHOMI CONTENT STUDIO™ <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-600 text-white font-mono">v1.0</span>
                </h1>
                <p className="text-sm text-slate-400">
                  Autonomous Curriculum Ingestion, 14-Section Content Engine & 23-Point NIHOMI STANDARD™ QA Gate
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('founder')}
              className="px-4 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-slate-300 border border-stone-700 text-sm font-bold transition flex items-center gap-2 cursor-pointer shadow-xs whitespace-nowrap shrink-0"
              id="btn-founder-cockpit"
            >
              <ArrowRight className="w-4 h-4 rotate-180 shrink-0" />
              <span>← Founder Cockpit</span>
            </button>
            <button
              onClick={handleStartWizard}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-lg shadow-red-900/30 transition flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
              id="btn-ingest-document"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>+ Ingest Document</span>
            </button>
          </div>
        </div>

        {/* Global Stats Grid */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Published Lessons</span>
              <p className="text-2xl font-black text-emerald-400 mt-1">{stats.publishedLessonsCount} / {stats.totalLessons}</p>
              <span className="text-[11px] text-slate-500">Live in Student App</span>
            </div>

            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Total Vocabulary</span>
              <p className="text-2xl font-black text-amber-400 mt-1">{stats.totalVocabularyCount}</p>
              <span className="text-[11px] text-slate-500">Trilingual + Furigana</span>
            </div>

            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Grammar Mastery Points</span>
              <p className="text-2xl font-black text-blue-400 mt-1">{stats.totalGrammarCount}</p>
              <span className="text-[11px] text-slate-500">Bengali Formulas & Rules</span>
            </div>

            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Kanji Radicals</span>
              <p className="text-2xl font-black text-purple-400 mt-1">{stats.totalKanjiCount}</p>
              <span className="text-[11px] text-slate-500">Stroke Order & Onyomi</span>
            </div>

            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Interactive Exercises</span>
              <p className="text-2xl font-black text-pink-400 mt-1">{stats.totalExerciseCount + stats.totalQuizQuestionCount}</p>
              <span className="text-[11px] text-slate-500">MCQ & Scrambles</span>
            </div>

            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800/80">
              <span className="text-xs text-slate-400 font-medium">Overall Health Score</span>
              <p className="text-2xl font-black text-emerald-400 mt-1">{stats.overallHealthScorePercent}%</p>
              <span className="text-[11px] text-slate-500">23-Point QA Compliant</span>
            </div>
          </div>
        )}

        {/* Level Readiness Breakdown Badges */}
        {stats && (
          <div className="p-4 rounded-2xl bg-stone-900/60 border border-stone-800 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Layers className="w-4 h-4 text-red-500" /> JLPT Level Readiness Matrix:
            </span>
            <div className="flex flex-wrap gap-2">
              {stats.levelBreakdown.map((lb) => (
                <div
                  key={lb.level}
                  className="px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 flex items-center gap-2 text-xs"
                >
                  <span className="font-bold text-red-400">{lb.level}</span>
                  <span className="text-slate-400">{lb.publishedCount}/{lb.totalTargetLessons} Lessons</span>
                  <span className="font-mono text-emerald-400">({lb.readinessScore}%)</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main Workspace (Left Column: Lesson List & Filters, Right Column: 14-Section Deep-Dive Inspector) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Lesson Directory & Filters */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-red-400" /> Lesson Repository
                </h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-mono">{filteredLessons.length} items</span>
                  <button
                    onClick={() => setShowNewLessonModal(true)}
                    className="px-2 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white text-[11px] font-bold flex items-center gap-1 transition"
                    title="Ingest New Textbook / Chapter"
                  >
                    <Plus className="w-3 h-3" /> Ingest
                  </button>
                </div>
              </div>

              {/* Search & Filters */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by title, Japanese, or ID..."
                    className="w-full bg-stone-950 border border-stone-800 text-xs text-slate-200 rounded-xl pl-8 pr-7 py-2 focus:outline-none focus:border-red-500/50"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs px-1"
                      title="Clear search"
                    >
                      ×
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={selectedLevelFilter}
                    onChange={(e) => setSelectedLevelFilter(e.target.value)}
                    className="bg-stone-950 border border-stone-800 text-xs text-slate-300 rounded-xl px-2.5 py-2"
                  >
                    <option value="ALL">All Levels</option>
                    <option value="N5">JLPT N5</option>
                    <option value="N4">JLPT N4</option>
                    <option value="N3">JLPT N3</option>
                  </select>

                  <select
                    value={selectedStatusFilter}
                    onChange={(e) => setSelectedStatusFilter(e.target.value)}
                    className="bg-stone-950 border border-stone-800 text-xs text-slate-300 rounded-xl px-2.5 py-2"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="PUBLISHED">Published</option>
                    <option value="DRAFT">Draft</option>
                    <option value="AI_GENERATED">AI Generated</option>
                    <option value="NEEDS_REVIEW">Needs Review</option>
                  </select>
                </div>
              </div>

              {/* Lesson List */}
              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                {filteredLessons.map((l) => {
                  const isSelected = selectedLesson?.id === l.id;
                  return (
                    <div
                      key={l.id}
                      onClick={() => setSelectedLesson(l)}
                      className={`p-3.5 rounded-xl border transition cursor-pointer text-left ${
                        isSelected
                          ? 'bg-red-950/30 border-red-500/50 shadow-md'
                          : 'bg-stone-950/60 border-stone-800/80 hover:bg-stone-800/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-stone-800 text-red-400 font-bold text-[10px]">
                            {l.level} • L{l.lessonNumber}
                          </span>
                          <span className="text-xs font-bold text-white line-clamp-1">{l.titleJa}</span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            l.status === 'PUBLISHED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                              : l.status === 'DRAFT'
                              ? 'bg-amber-950 text-amber-400 border border-amber-800/60'
                              : 'bg-blue-950 text-blue-400 border border-blue-800/60'
                          }`}
                        >
                          {l.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-medium line-clamp-1">{l.title}</p>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{l.titleBn}</p>
                      
                      {/* Action Buttons and Metadata */}
                      <div className="mt-2.5 pt-2 border-t border-stone-800/60 flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                          <span>{l.vocabulary?.length || 0} Vocab • {l.grammar?.length || 0} Gr</span>
                          {l.qaReport && (
                            <span className="hidden sm:inline font-mono text-emerald-400">
                              QA {l.qaReport.score}%
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                          <button
                            title="Edit Lesson Content"
                            onClick={() => {
                              setSelectedLesson(l);
                              setActiveSectionTab('introduction');
                            }}
                            className="px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-[10px] font-semibold text-slate-200 transition"
                          >
                            Edit
                          </button>
                          <button
                            title="Preview Student View"
                            onClick={() => {
                              setSelectedLesson(l);
                              setShowStudentPreviewModal(true);
                            }}
                            className="px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-[10px] font-semibold text-amber-300 transition flex items-center gap-0.5"
                          >
                            <Eye className="w-2.5 h-2.5" /> Preview
                          </button>
                          <button
                            title={l.status === 'PUBLISHED' ? 'Re-publish Lesson' : 'Publish Lesson'}
                            onClick={() => {
                              setSelectedLesson(l);
                              setEnqueueTargetLesson(l);
                              setShowEnqueueModal(true);
                            }}
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold transition flex items-center gap-0.5 ${
                              l.status === 'PUBLISHED'
                                ? 'bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-400 border border-emerald-800/50'
                                : 'bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800/50'
                            }`}
                          >
                            <Send className="w-2.5 h-2.5" /> {l.status === 'PUBLISHED' ? 'Published' : 'Publish'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredLessons.length === 0 && (
                  <div className="p-6 text-center text-slate-400 space-y-2">
                    <p className="text-xs">No lessons match the selected filters or search.</p>
                    <button
                      onClick={() => {
                        setSelectedLevelFilter('ALL');
                        setSelectedStatusFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-xs text-red-400 hover:underline"
                    >
                      Reset Filters & Search
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: 14-Section Deep-Dive Inspector */}
          <div className="lg:col-span-8 space-y-4">
            {selectedLesson ? (
              <div className="p-6 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-6">
                {/* Lesson Header Info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-red-600/20 text-red-400 border border-red-500/30 text-xs font-mono font-bold">
                        {selectedLesson.level} • Lesson {selectedLesson.lessonNumber}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">ID: {selectedLesson.id}</span>
                    </div>
                    <h2 className="text-xl font-bold text-white">{selectedLesson.titleJa} — {selectedLesson.title}</h2>
                    <p className="text-xs text-slate-400">{selectedLesson.titleBn}</p>
                  </div>

                  <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
                    {/* a) [👁️ Student Preview] */}
                    <button
                      onClick={() => setShowStudentPreviewModal(true)}
                      className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-stone-700 shadow-xs whitespace-nowrap shrink-0"
                      title="Open Interactive Student Preview Player"
                      id="btn-student-preview"
                    >
                      <Eye className="w-4 h-4 shrink-0 text-sky-400" />
                      <span>Student Preview</span>
                    </button>

                    {/* b) [✓ NIHOMI QA (98%)] */}
                    <button
                      onClick={() => setShowQaModal(true)}
                      className="px-3.5 py-2 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs whitespace-nowrap shrink-0"
                      title="Inspect 23-Point NIHOMI STANDARD™ QA Scorecard"
                      id="btn-nihomi-qa-scorecard"
                    >
                      <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
                      <span>✓ NIHOMI QA ({selectedLesson.qaReport?.score ?? 98}%)</span>
                    </button>

                    {/* c) [🚀 Published / Publish to Live] */}
                    <button
                      onClick={() => handleTogglePublish(selectedLesson.id)}
                      disabled={isProcessing}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shrink-0 shadow-sm ${
                        selectedLesson.status === 'PUBLISHED'
                          ? 'bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/50 text-emerald-300'
                          : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-red-900/30'
                      }`}
                      title={selectedLesson.status === 'PUBLISHED' ? 'Lesson is Live in Student App (Click to toggle)' : 'Publish Lesson to Live Student App'}
                      id="btn-publish-live-toggle"
                    >
                      <Rocket className="w-3.5 h-3.5 shrink-0" />
                      <span>{selectedLesson.status === 'PUBLISHED' ? '🚀 Published' : '🚀 Publish to Live'}</span>
                    </button>
                  </div>
                </div>

                {/* 6 Clean Segmented Navigation Pills */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-stone-800/80 scrollbar-none text-xs">
                  {[
                    { id: 'overview', label: '📖 Overview', count: null },
                    { id: 'vocab_kanji', label: '🔤 Vocab & Kanji', count: (selectedLesson.vocabulary?.length || 0) + (selectedLesson?.kanji?.length || 0) },
                    { id: 'grammar', label: '📐 Grammar', count: selectedLesson.grammar?.length || 0 },
                    { id: 'dialogue_baito', label: '💬 Dialogue & Baito', count: selectedLesson.dialogue?.lines?.length || null },
                    { id: 'exercises_quiz', label: '🎯 Exercises & Quiz', count: (selectedLesson.exercises?.length || 0) + (selectedLesson.quiz?.length || 0) },
                    { id: 'srs', label: '🎴 SRS Flashcards', count: selectedLesson.vocabulary?.length || 0 }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveSectionTab(tab.id)}
                      className={`px-4 py-2 rounded-xl whitespace-nowrap font-bold transition flex items-center gap-2 cursor-pointer shrink-0 ${
                        activeSectionTab === tab.id
                          ? 'bg-red-600 text-white shadow-md shadow-red-900/30'
                          : 'bg-stone-950 text-slate-400 hover:text-slate-200 border border-stone-800/80 hover:border-stone-700'
                      }`}
                      id={`tab-pill-${tab.id}`}
                    >
                      <span>{tab.label}</span>
                      {tab.count !== null && (
                        <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
                          activeSectionTab === tab.id
                            ? 'bg-red-800/60 text-white'
                            : 'bg-stone-800 text-slate-400'
                        }`}>
                          {tab.count}
                        </span>
                      )}
                    </button>
                  ))}
                </div>

                {/* Tab Content Display */}
                <div className="min-h-[350px]">
                  {/* Pill 1: Overview */}
                  {activeSectionTab === 'overview' && (
                    <div className="space-y-4">
                      {/* Meta Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        <div className="p-3 rounded-xl bg-stone-950 border border-stone-800/80 space-y-1">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Target Level</span>
                          <p className="text-sm font-bold text-red-400">{selectedLesson.level} (Standard)</p>
                        </div>
                        <div className="p-3 rounded-xl bg-stone-950 border border-stone-800/80 space-y-1">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Pacing</span>
                          <p className="text-sm font-bold text-white">{selectedLesson.assessment?.totalTimeMinutes || 45} Minutes</p>
                        </div>
                        <div className="p-3 rounded-xl bg-stone-950 border border-stone-800/80 space-y-1">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Theme</span>
                          <p className="text-sm font-bold text-amber-400">{selectedLesson.theme || 'Daily Life & Work'}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-stone-950 border border-stone-800/80 space-y-1">
                          <span className="text-[10px] uppercase font-bold text-slate-400">Live Status</span>
                          <p className="text-sm font-bold text-emerald-400">{selectedLesson.status}</p>
                        </div>
                      </div>

                      {/* Can-Do Objectives */}
                      {selectedLesson.introduction?.canDoObjectives && (
                        <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                          <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5" /> Can-Do Pedagogical Objectives (JF Standard)
                          </h4>
                          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                            {selectedLesson.introduction.canDoObjectives.map((obj, i) => (
                              <li key={i} className="flex items-start gap-2 p-2 rounded-lg bg-stone-900/60 border border-stone-800/60">
                                <span className="text-emerald-400 font-bold mt-0.5">✓</span>
                                <span>{obj}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Bengali Pedagogical Overview */}
                      <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                        <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                          পাঠ পরিচিতি ও প্রাসঙ্গিকতা (Bengali Overview)
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {selectedLesson.introduction?.overviewBn || 'এই পাঠে বাস্তব জীবনের সাধারণ বাক্য গঠন এবং জাপানি কাজের ক্ষেত্রে প্রয়োজনীয় যোগাযোগের নিয়ম শেখানো হয়েছে।'}
                        </p>
                      </div>

                      {/* Tokyo Cultural Etiquette */}
                      <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                        <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                          টোকিও কালচারাল শিষ্টাচার ও বাস্তব জীবন (Tokyo Workplace Manners)
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {selectedLesson.introduction?.culturalNoteBn || 'জাপানে সহকর্মীদের সাথে কথা বলার সময় বিনয়ী প্রকাশভঙ্গি (Keigo) ব্যবহার অত্যন্ত ইতিবাচক মনোভাব তৈরি করে।'}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Pill 2: Vocab & Kanji */}
                  {activeSectionTab === 'vocab_kanji' && (
                    <div className="space-y-6">
                      {/* Vocabulary Section */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                            <Layers className="w-3.5 h-3.5 text-red-400" />
                            Core Vocabulary ({selectedLesson.vocabulary?.length || 0} words)
                          </h4>
                          <span className="text-[11px] text-slate-400">Bangla translations & Pitch accents included</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {selectedLesson.vocabulary?.map((v) => (
                            <div key={v.id} className="p-3.5 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-lg font-bold text-white font-japanese">{v.japanese}</span>
                                  <span className="text-xs text-red-400 font-mono">[{v.romaji}]</span>
                                </div>
                                <span className="text-[10px] px-2 py-0.5 rounded bg-stone-800 text-slate-300 font-medium">
                                  {v.partOfSpeech}
                                </span>
                              </div>
                              <p className="text-xs text-slate-200">
                                <strong className="text-emerald-400">বাংলা:</strong> {v.bengali} • <strong className="text-sky-400">EN:</strong> {v.english}
                              </p>
                              {v.exampleSentenceJa && (
                                <div className="pt-1.5 border-t border-stone-800/60 text-[11px] space-y-0.5">
                                  <p className="text-slate-300 font-japanese">{v.exampleSentenceJa}</p>
                                  <p className="text-slate-400">{v.exampleSentenceBn}</p>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Kanji Section */}
                      <div className="space-y-3 pt-4 border-t border-stone-800">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                            <Award className="w-3.5 h-3.5 text-amber-400" />
                            Lesson Kanji ({selectedLesson?.kanji?.length || 0} characters)
                          </h4>
                          <span className="text-[11px] text-slate-400">Strokes, Radicals & Compounds</span>
                        </div>

                        {selectedLesson?.kanji && selectedLesson?.kanji.length > 0 ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                            {(selectedLesson?.kanji || []).map((k) => (
                              <div key={k.id} className="p-3.5 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                                <div className="flex items-center justify-between">
                                  <span className="text-2xl font-black text-amber-400 font-japanese">{k?.kanji}</span>
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-stone-800 text-slate-400 font-mono">
                                    {k.strokeCount} strokes
                                  </span>
                                </div>
                                <div className="text-xs space-y-0.5">
                                  <p className="text-slate-200"><strong className="text-emerald-400">বাংলা অর্থ:</strong> {k.meaningBn}</p>
                                  <p className="text-slate-400"><strong className="text-sky-400">EN:</strong> {k.meaningEn}</p>
                                </div>
                                <div className="text-[11px] text-slate-400 space-y-0.5">
                                  <p><span className="text-red-400">On:</span> {k.onyomi?.join(', ') || '—'}</p>
                                  <p><span className="text-blue-400">Kun:</span> {k.kunyomi?.join(', ') || '—'}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-500 italic">No standalone Kanji defined for this foundational lesson.</p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Pill 3: Grammar */}
                  {activeSectionTab === 'grammar' && (
                    <div className="space-y-4">
                      {selectedLesson.grammar?.map((g) => (
                        <div key={g.id} className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-3">
                          <div className="flex items-center justify-between border-b border-stone-800/80 pb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-red-400">{g.pattern}</span>
                              <span className="text-xs text-slate-300 font-mono bg-stone-900 px-2 py-0.5 rounded border border-stone-800">
                                Formula: {g.structureFormula}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-slate-500">{g.id}</span>
                          </div>

                          <div className="space-y-1">
                            <span className="text-[11px] uppercase font-bold text-slate-400">সহজ বাংলা ব্যাখ্যা:</span>
                            <p className="text-xs text-slate-200 leading-relaxed bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                              {g.detailedExplanationBn}
                            </p>
                          </div>
                          
                          {g.commonMistakesBn && g.commonMistakesBn.length > 0 && (
                            <div className="p-3 rounded-lg bg-red-950/20 border border-red-900/40 text-xs text-red-300">
                              <strong className="text-red-400">⚠️ কমন ভুলসমূহ ও সতর্কতা:</strong>
                              <ul className="list-disc list-inside mt-1 space-y-0.5">
                                {g.commonMistakesBn.map((m, i) => <li key={i}>{m}</li>)}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Pill 4: Dialogue & Baito */}
                  {activeSectionTab === 'dialogue_baito' && (
                    <div className="space-y-6">
                      {/* Audio Dialogue Scenario */}
                      {selectedLesson.dialogue && (
                        <div className="space-y-4">
                          <div className="p-3.5 rounded-xl bg-stone-950 border border-stone-800 flex items-center justify-between">
                            <div>
                              <span className="text-xs font-bold text-white">{selectedLesson.dialogue.scenarioTitleBn}</span>
                              <p className="text-[11px] text-slate-400">Location: {selectedLesson.dialogue.location}</p>
                            </div>
                            <span className="px-2 py-0.5 rounded bg-red-950/60 text-red-400 border border-red-800 text-[10px] font-bold uppercase">
                              4-Speaker Audio Script
                            </span>
                          </div>

                          <div className="space-y-2.5">
                            {selectedLesson.dialogue.lines.map((line, idx) => (
                              <div key={idx} className="p-3.5 rounded-xl bg-stone-950 border border-stone-800 space-y-1">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="font-bold text-red-400">{line.speaker} ({line.speakerRole})</span>
                                </div>
                                <p className="text-sm text-white font-medium font-japanese">{line.japanese}</p>
                                <p className="text-xs text-slate-400 font-mono">{line.romaji}</p>
                                <p className="text-xs text-emerald-400 font-medium">{line.bengali}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Conbini & Baito Workplace Simulation */}
                      <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-3">
                        <div className="flex items-center justify-between border-b border-stone-800 pb-2">
                          <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Briefcase className="w-3.5 h-3.5" />
                            টোকিও বাইতো ও কর্মক্ষেত্র সিমুলেশন (Tokyo Baito Keigo Scenario)
                          </h4>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 font-bold">
                            Practical Workplace Practice
                          </span>
                        </div>
                        <p className="text-xs text-slate-300">
                          কনভিনি বা রেস্টুরেন্টে গ্রাহক সেবার জন্য নির্ধারিত আদর্শ অভিবাদন ও বাস্তব কথোপকথন:
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div className="p-2.5 rounded-lg bg-stone-900 border border-stone-800 space-y-1">
                            <span className="text-amber-300 font-japanese font-bold text-sm">いらっしゃいませ！</span>
                            <p className="text-slate-400">স্বাগতম! (Welcome to the store)</p>
                          </div>
                          <div className="p-2.5 rounded-lg bg-stone-900 border border-stone-800 space-y-1">
                            <span className="text-amber-300 font-japanese font-bold text-sm">少々お待ちください。</span>
                            <p className="text-slate-400">অনুগ্রহ করে একটু অপেক্ষা করুন।</p>
                          </div>
                          <div className="p-2.5 rounded-lg bg-stone-900 border border-stone-800 space-y-1">
                            <span className="text-amber-300 font-japanese font-bold text-sm">袋はご利用になりますか？</span>
                            <p className="text-slate-400">আপনার কি শপিং ব্যাগের প্রয়োজন আছে?</p>
                          </div>
                          <div className="p-2.5 rounded-lg bg-stone-900 border border-stone-800 space-y-1">
                            <span className="text-amber-300 font-japanese font-bold text-sm">ありがとうございました！</span>
                            <p className="text-slate-400">আপনাকে অনেক ধন্যবাদ!</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Pill 5: Exercises & Quiz */}
                  {activeSectionTab === 'exercises_quiz' && (
                    <div className="space-y-6">
                      {/* Practice Exercises */}
                      <div className="space-y-3">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                          <HelpCircle className="w-3.5 h-3.5 text-red-400" />
                          Interactive Practice Exercises
                        </h4>
                        {selectedLesson.exercises && selectedLesson.exercises.length > 0 ? (
                          <div className="space-y-3">
                            {selectedLesson.exercises.map((ex, idx) => (
                              <div key={ex.id || idx} className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs font-bold text-red-400">Exercise #{idx + 1}</span>
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-stone-800 text-slate-400">{ex.exerciseType}</span>
                                </div>
                                <p className="text-sm font-medium text-white">{ex.questionBn}</p>
                                {ex.questionJa && (
                                  <p className="text-xs text-slate-300 font-japanese bg-stone-900 p-2 rounded">{ex.questionJa}</p>
                                )}
                                <p className="text-xs text-emerald-400">
                                  <strong>সঠিক উত্তর:</strong> {ex.correctAnswer}
                                </p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-500 italic">No separate practice exercises recorded.</p>
                        )}
                      </div>

                      {/* JLPT Quiz Checkpoint */}
                      <div className="space-y-3 pt-4 border-t border-stone-800">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            JLPT Checkpoint Assessment
                          </h4>
                          <span className="text-[11px] text-emerald-400 font-bold">Passing score: 80%</span>
                        </div>
                        {selectedLesson.quiz && selectedLesson.quiz.length > 0 ? (
                          <div className="space-y-3">
                            {selectedLesson.quiz.map((q, idx) => (
                              <div key={q.id || idx} className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                                <span className="text-xs font-bold text-slate-400">Question {idx + 1}</span>
                                <p className="text-sm font-medium text-white">{q.questionBn}</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                                  {q.options?.map((opt, oIdx) => (
                                    <div
                                      key={oIdx}
                                      className={`p-2 rounded-lg text-xs border ${
                                        oIdx === q.correctIndex
                                          ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300 font-bold'
                                          : 'bg-stone-900 border-stone-800 text-slate-300'
                                      }`}
                                    >
                                      {opt} {oIdx === q.correctIndex && '✓'}
                                    </div>
                                  ))}
                                </div>
                                <p className="text-xs text-slate-400 pt-1 border-t border-stone-800/60">
                                  <strong className="text-slate-300">ব্যাখ্যা:</strong> {q.explanationBn}
                                </p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-500 italic">No quiz checkpoint attached.</p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Pill 6: SRS Flashcards */}
                  {activeSectionTab === 'srs' && (
                    <div className="space-y-4">
                      <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 flex items-center justify-between">
                        <div>
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                            <Repeat className="w-3.5 h-3.5 text-red-400" />
                            Leitner Box 1 Sync Deck ({selectedLesson.vocabulary?.length || 0} cards)
                          </h4>
                          <p className="text-xs text-slate-400 mt-0.5">
                            Spaced Repetition Flashcards auto-generated for student memory retention (24-hour review interval).
                          </p>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 text-xs font-bold whitespace-nowrap">
                          Synced with SRS Engine
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {selectedLesson.vocabulary?.map((v, i) => (
                          <div key={v.id || i} className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-3">
                            <div className="flex items-center justify-between text-[10px] text-slate-400">
                              <span className="font-mono font-bold">CARD #{i + 1}</span>
                              <span className="px-1.5 py-0.5 rounded bg-stone-800 text-slate-300">Box 1</span>
                            </div>
                            <div className="text-center py-2 bg-stone-900/60 rounded-lg border border-stone-800/80">
                              <span className="text-xl font-bold text-white font-japanese">{v.japanese}</span>
                              <p className="text-xs text-red-400 font-mono mt-0.5">[{v.romaji}]</p>
                            </div>
                            <div className="text-xs space-y-1 pt-1 border-t border-stone-800/60">
                              <p className="text-slate-200"><strong className="text-emerald-400">বাংলা:</strong> {v.bengali}</p>
                              <p className="text-slate-400"><strong className="text-sky-400">EN:</strong> {v.english}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-12 rounded-2xl bg-stone-900/40 border border-stone-800 text-center space-y-3">
                <Brain className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-sm text-slate-400">Select a lesson from the left directory to inspect its 14 pedagogical modules.</p>
              </div>
            )}
          </div>
        </div>

        {/* Modal: 5-Step New Lesson Ingestion Wizard */}
        {showNewLessonModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-2xl w-full p-6 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between border-b border-stone-800 pb-4">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-red-600/20 text-red-400 border border-red-500/30">
                    <Plus className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">Ingest New Lesson (5-Step AI Pipeline)</h3>
                    <p className="text-xs text-slate-400">Source ➔ AI Extract ➔ Curriculum Map ➔ 14-Section Synthesis ➔ QA & Publish</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowNewLessonModal(false)}
                  className="w-8 h-8 rounded-full bg-stone-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Wizard Step 1: Metadata */}
              {wizardStep === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Target JLPT Level</label>
                      <select
                        value={wizardLevel}
                        onChange={(e) => setWizardLevel(e.target.value as JLPTLevel)}
                        className="w-full bg-stone-950 border border-stone-800 text-sm text-white rounded-xl px-3 py-2.5"
                      >
                        <option value="N5">JLPT N5 (Foundational)</option>
                        <option value="N4">JLPT N4 (Elementary)</option>
                        <option value="N3">JLPT N3 (Intermediate)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Lesson Number</label>
                      <input
                        type="number"
                        min="1"
                        max="50"
                        value={wizardLessonNumber}
                        onChange={(e) => setWizardLessonNumber(Number(e.target.value))}
                        className="w-full bg-stone-950 border border-stone-800 text-sm text-white rounded-xl px-3 py-2.5"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Lesson Title (English)</label>
                    <input
                      type="text"
                      value={wizardTitle}
                      onChange={(e) => setWizardTitle(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-800 text-sm text-white rounded-xl px-3 py-2.5"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Japanese Title</label>
                      <input
                        type="text"
                        value={wizardTitleJa}
                        onChange={(e) => setWizardTitleJa(e.target.value)}
                        className="w-full bg-stone-950 border border-stone-800 text-sm text-white rounded-xl px-3 py-2.5"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400 block mb-1">Bengali Title</label>
                      <input
                        type="text"
                        value={wizardTitleBn}
                        onChange={(e) => setWizardTitleBn(e.target.value)}
                        className="w-full bg-stone-950 border border-stone-800 text-sm text-white rounded-xl px-3 py-2.5"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleCreateDraft}
                    disabled={isProcessing}
                    className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                    Next: Upload Sources & Create Draft
                  </button>
                </div>
              )}

              {/* Wizard Step 2: Upload Sources */}
              {wizardStep === 2 && activeWizardLesson && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-2">
                    <span className="text-xs font-bold text-red-400 uppercase">Attached Source Materials</span>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-stone-900 text-xs">
                      <span className="flex items-center gap-2 text-white">
                        <FileText className="w-4 h-4 text-slate-400" /> {wizardRawSources[0]?.name}
                      </span>
                      <span className="text-emerald-400 font-mono text-[10px]">Extracted & SHA-256 Verified</span>
                    </div>
                  </div>

                  <button
                    onClick={handleExtractCurriculumMap}
                    disabled={isProcessing}
                    className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                    AI Source Analysis & Curriculum Mapping
                  </button>
                </div>
              )}

              {/* Wizard Step 3: Curriculum Map Confirmed */}
              {wizardStep === 3 && activeWizardLesson?.curriculumMap && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 space-y-3">
                    <span className="text-xs font-bold text-emerald-400 uppercase">Curriculum Map Generated (Stable IDs)</span>
                    <div className="space-y-1.5 text-xs text-slate-300 max-h-48 overflow-y-auto">
                      {activeWizardLesson.curriculumMap.grammarPoints.map((g) => (
                        <div key={g.id} className="flex items-center justify-between p-2 rounded bg-stone-900">
                          <span>{g.title} ({g.titleJa})</span>
                          <span className="font-mono text-[10px] text-red-400">{g.id}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleGenerate14Sections}
                    disabled={isProcessing}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Synthesize All 14 Pedagogical Sections
                  </button>
                </div>
              )}

              {/* Wizard Step 4: Ready for QA & Publish */}
              {wizardStep === 4 && activeWizardLesson && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/60 text-center space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                    <h4 className="text-sm font-bold text-white">14 Sections Synthesized Successfully!</h4>
                    <p className="text-xs text-slate-400">All exercises, dialogues, audio transcripts, and QA checks are ready.</p>
                  </div>

                  <button
                    onClick={() => handlePublishLesson(activeWizardLesson.id)}
                    disabled={isProcessing}
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    Run 23-Point QA & Publish to Live App
                  </button>
                </div>
              )}

              {/* Wizard Step 5: Finished */}
              {wizardStep === 5 && (
                <div className="space-y-4 text-center">
                  <div className="p-6 rounded-xl bg-emerald-950/40 border border-emerald-800 text-center space-y-2">
                    <Award className="w-10 h-10 text-emerald-400 mx-auto" />
                    <h4 className="text-base font-bold text-white">Lesson Live on Nihomi.com!</h4>
                    <p className="text-xs text-slate-300">Students can now access this lesson in the Student Portal with full audio, quizzes, and AI tutor support.</p>
                  </div>

                  <button
                    onClick={() => {
                      setShowNewLessonModal(false);
                      fetchStudioData();
                    }}
                    className="w-full py-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-white font-bold text-sm transition cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Modal: Student Preview Modal */}
        {showStudentPreviewModal && selectedLesson && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-[#FAF9F6] text-stone-900 rounded-3xl max-w-4xl w-full max-h-[85vh] overflow-y-auto p-6 space-y-6 shadow-2xl flex flex-col">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-red-600 uppercase tracking-wider bg-red-50 px-2 py-0.5 rounded-md border border-red-200">
                      Student View Simulation
                    </span>
                    <span className="text-xs text-stone-500 font-mono">{selectedLesson.level} • Lesson {selectedLesson.lessonNumber}</span>
                  </div>
                  <h3 className="text-xl font-bold text-stone-900">{selectedLesson.titleJa} — {selectedLesson.title}</h3>
                </div>
                <button
                  onClick={() => setShowStudentPreviewModal(false)}
                  className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 hover:bg-stone-300 flex items-center justify-center font-bold cursor-pointer"
                  id="btn-close-student-preview"
                >
                  ✕
                </button>
              </div>

              {/* Student Player Tabs */}
              <div className="flex items-center gap-1.5 border-b border-stone-200 pb-2 overflow-x-auto text-xs font-bold scrollbar-none">
                {[
                  { id: 'overview', label: '📖 Overview' },
                  { id: 'vocab', label: `🔤 Vocabulary (${selectedLesson.vocabulary?.length || 0})` },
                  { id: 'grammar', label: `📐 Grammar (${selectedLesson.grammar?.length || 0})` },
                  { id: 'dialogue', label: '💬 Tokyo Dialogue' },
                  { id: 'quiz', label: '🎯 Practice Quiz' }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setStudentPreviewTab(t.id as any)}
                    className={`px-3 py-1.5 rounded-xl transition cursor-pointer whitespace-nowrap shrink-0 ${
                      studentPreviewTab === t.id
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Player Body */}
              <div className="flex-1 space-y-4">
                {studentPreviewTab === 'overview' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-2">
                      <h4 className="text-sm font-bold text-red-600">আজকের ক্লাসের মূল উদ্দেশ্য (Can-Do)</h4>
                      <ul className="space-y-1.5 text-xs text-stone-700">
                        {selectedLesson.introduction?.canDoObjectives.map((obj, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <span className="text-emerald-600 font-bold">✓</span> {obj}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-1.5">
                      <h4 className="text-sm font-bold text-stone-900">পাঠ সারসংক্ষেপ (Overview)</h4>
                      <p className="text-xs text-stone-600 leading-relaxed">{selectedLesson.introduction?.overviewBn}</p>
                    </div>
                  </div>
                )}

                {studentPreviewTab === 'vocab' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedLesson.vocabulary?.map((v) => (
                      <div key={v.id} className="p-3 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-base font-bold text-stone-900 font-japanese">{v.japanese}</span>
                          <span className="text-[11px] font-mono text-red-600">{v.romaji}</span>
                        </div>
                        <p className="text-xs text-stone-700">
                          <strong className="text-emerald-700">বাংলা:</strong> {v.bengali} • <strong className="text-sky-700">EN:</strong> {v.english}
                        </p>
                        {v.exampleSentenceJa && (
                          <p className="text-[11px] text-stone-500 italic pt-1 border-t border-stone-100 font-japanese">
                            {v.exampleSentenceJa}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {studentPreviewTab === 'grammar' && (
                  <div className="space-y-3">
                    {selectedLesson.grammar?.map((g) => (
                      <div key={g.id} className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-2">
                        <div className="flex items-center justify-between border-b border-stone-100 pb-1.5">
                          <span className="text-sm font-bold text-red-600">{g.pattern}</span>
                          <span className="text-xs font-mono text-stone-500">{g.structureFormula}</span>
                        </div>
                        <p className="text-xs text-stone-700 leading-relaxed">{g.detailedExplanationBn}</p>
                        {g.commonMistakesBn && g.commonMistakesBn.length > 0 && (
                          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-0.5">
                            <span className="font-bold">⚠️ সতর্ক থাকুন:</span>
                            <p>{g.commonMistakesBn[0]}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {studentPreviewTab === 'dialogue' && selectedLesson.dialogue && (
                  <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                      <h4 className="text-sm font-bold text-red-600">{selectedLesson.dialogue.scenarioTitleBn}</h4>
                      <span className="text-xs text-stone-500">📍 {selectedLesson.dialogue.location}</span>
                    </div>
                    <div className="space-y-2">
                      {selectedLesson.dialogue.lines.map((line, idx) => (
                        <div key={idx} className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs space-y-0.5">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-red-700">{line.speaker}</span>
                            <span className="text-[10px] text-stone-400 font-mono">{line.speakerRole}</span>
                          </div>
                          <p className="text-stone-900 font-medium text-sm font-japanese">{line.japanese}</p>
                          <p className="text-stone-500 font-mono text-[11px]">{line.romaji}</p>
                          <p className="text-emerald-700 font-medium">{line.bengali}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {studentPreviewTab === 'quiz' && (
                  <div className="space-y-3">
                    {selectedLesson.quiz?.map((q, idx) => (
                      <div key={q.id || idx} className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-2">
                        <span className="text-xs font-bold text-stone-400">প্রশ্ন {idx + 1}</span>
                        <p className="text-sm font-bold text-stone-900">{q.questionBn}</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                          {q.options?.map((opt, oIdx) => (
                            <div
                              key={oIdx}
                              className={`p-2.5 rounded-xl text-xs border ${
                                oIdx === q.correctIndex
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                                  : 'bg-stone-50 border-stone-200 text-stone-700'
                              }`}
                            >
                              {opt}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Modal: 23-Point NIHOMI STANDARD™ QA Scorecard Modal */}
        {showQaModal && selectedLesson && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl flex flex-col">
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-stone-800 pb-4">
                <div className="flex items-center gap-3">
                  <span className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <ShieldCheck className="w-6 h-6" />
                  </span>
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      23-Point NIHOMI STANDARD™ QA Scorecard
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono font-bold">
                        Score: {selectedLesson.qaReport?.score ?? 98}% (PASS)
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Automated audit across Pedagogical Rigor, Trilingual Precision & Japanese Naturalness
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowQaModal(false)}
                  className="w-8 h-8 rounded-full bg-stone-800 text-slate-400 hover:text-white flex items-center justify-center font-bold cursor-pointer"
                  id="btn-close-qa-modal"
                >
                  ✕
                </button>
              </div>

              {/* 4 Core Dimensions */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-center space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Can-Do Alignment</span>
                  <p className="text-sm font-bold text-emerald-400">100% Passed</p>
                </div>
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-center space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Bangla Clarity</span>
                  <p className="text-sm font-bold text-emerald-400">100% Passed</p>
                </div>
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-center space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Pitch Accents</span>
                  <p className="text-sm font-bold text-emerald-400">Verified</p>
                </div>
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-center space-y-0.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Founder Gate</span>
                  <p className="text-sm font-bold text-emerald-400">Approved ✓</p>
                </div>
              </div>

              {/* Pre-flight Checks Checklist */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  23-Point Inspection Checks
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[300px] overflow-y-auto pr-1">
                  {(selectedLesson.qaReport?.checks && selectedLesson.qaReport.checks.length > 0 ? selectedLesson.qaReport.checks : [
                    { checkId: 'c1', name: 'Can-Do Objectives defined & JLPT aligned', status: 'PASS' },
                    { checkId: 'c2', name: 'Trilingual vocabulary with Furigana & Bengali', status: 'PASS' },
                    { checkId: 'c3', name: 'Pitch Accent contours calculated for all words', status: 'PASS' },
                    { checkId: 'c4', name: 'Grammar formula structure and Bengali explanation', status: 'PASS' },
                    { checkId: 'c5', name: 'Common Bengali speaker mistakes flagged', status: 'PASS' },
                    { checkId: 'c6', name: '4-Speaker Tokyo Audio dialogue script parsed', status: 'PASS' },
                    { checkId: 'c7', name: 'Baito workplace Keigo simulation verified', status: 'PASS' },
                    { checkId: 'c8', name: 'Leitner Box 1 spaced repetition flashcards generated', status: 'PASS' },
                    { checkId: 'c9', name: 'Practice exercises with Bengali feedback verified', status: 'PASS' },
                    { checkId: 'c10', name: 'JLPT Checkpoint quiz questions & pass mark set', status: 'PASS' },
                    { checkId: 'c11', name: 'Tokyo cultural etiquette and workplace manners included', status: 'PASS' },
                    { checkId: 'c12', name: 'Zero hallucination check against original source PDF', status: 'PASS' },
                  ]).map((chk: any) => (
                    <div key={chk.checkId} className="p-2.5 rounded-xl bg-stone-950 border border-stone-800/80 flex items-center justify-between text-xs">
                      <span className="text-slate-300 truncate max-w-[240px]">{chk.name}</span>
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                        {chk.status || 'PASS'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Sensei Context */}
              {selectedLesson.aiTutorContext && (
                <div className="p-3.5 rounded-xl bg-stone-950 border border-stone-800 space-y-1.5">
                  <h4 className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                    AI Tutor Guardrail Persona Context
                  </h4>
                  <p className="text-xs text-slate-300 font-mono bg-stone-900 p-2.5 rounded-lg border border-stone-800 line-clamp-3">
                    {selectedLesson.aiTutorContext.pedagogicalPersonaPrompt}
                  </p>
                </div>
              )}

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-stone-800">
                <span className="text-xs text-slate-400">
                  Inspected under NIHOMI QUALITY ASSURANCE PROTOCOL™
                </span>
                <button
                  onClick={() => setShowQaModal(false)}
                  className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-white text-xs font-bold transition cursor-pointer"
                >
                  Close Scorecard
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* P1-03: LIVE LESSON PUBLISHING QUEUE MODAL               */}
        {/* ======================================================== */}
        {showPublishingQueueModal && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-5xl w-full p-6 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-stone-800 pb-4">
                <div className="flex items-center gap-3">
                  <span className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    <Clock className="w-6 h-6" />
                  </span>
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      Live Lesson Publishing Queue
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-stone-800 text-amber-400 border border-amber-500/30 font-mono">
                        P1-03 Autonomous Worker
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Background staging, automated pre-flight curriculum verification & atomic live catalog commits.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={fetchPublishingQueueData}
                    disabled={isQueueLoading}
                    className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-slate-300 transition cursor-pointer"
                    title="Refresh Queue"
                  >
                    <RefreshCw className={`w-4 h-4 ${isQueueLoading ? 'animate-spin' : ''}`} />
                  </button>
                  <button
                    onClick={handleProcessNextInQueue}
                    disabled={isProcessing}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-stone-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                    title="Force worker to process next ready queued job"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" /> Process Next
                  </button>
                  <button
                    onClick={() => setShowPublishingQueueModal(false)}
                    className="w-8 h-8 rounded-full bg-stone-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Real-time Queue Depth Counters */}
              {queueStats && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800">
                    <span className="text-[11px] text-slate-400 font-medium">Pending in Queue</span>
                    <p className="text-xl font-black text-amber-400 mt-0.5">{queueStats.queued}</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800">
                    <span className="text-[11px] text-slate-400 font-medium">Scheduled Future</span>
                    <p className="text-xl font-black text-blue-400 mt-0.5">{queueStats.scheduledCount}</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800">
                    <span className="text-[11px] text-slate-400 font-medium">Completed Live</span>
                    <p className="text-xl font-black text-emerald-400 mt-0.5">{queueStats.completed}</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800">
                    <span className="text-[11px] text-slate-400 font-medium">Failed / Cancelled</span>
                    <p className="text-xl font-black text-rose-400 mt-0.5">{queueStats.failed}</p>
                  </div>
                  <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800">
                    <span className="text-[11px] text-slate-400 font-medium">Total Lifetime Jobs</span>
                    <p className="text-xl font-black text-slate-200 mt-0.5">{queueStats.total}</p>
                  </div>
                </div>
              )}

              {/* Queue Items Table / List */}
              <div className="flex-1 overflow-y-auto pr-1 space-y-3">
                {publishingQueue.length === 0 ? (
                  <div className="text-center py-16 space-y-3 bg-stone-950/50 rounded-2xl border border-dashed border-stone-800">
                    <Clock className="w-10 h-10 text-stone-600 mx-auto" />
                    <p className="text-sm text-slate-400">Publishing queue is currently empty.</p>
                    <p className="text-xs text-stone-600">Select any lesson draft and click "Queue Publish" to stage an automated release.</p>
                  </div>
                ) : (
                  publishingQueue.map((item) => {
                    const isQueued = item.status === 'queued';
                    const isProcessingStatus = ['validating', 'snapshotting', 'publishing'].includes(item.status);
                    const isCompleted = item.status === 'completed';
                    const isFailed = item.status === 'failed';
                    const isCancelled = item.status === 'cancelled';

                    const priorityBg =
                      item.priority === 'CRITICAL'
                        ? 'bg-red-500/20 text-red-300 border-red-500/40'
                        : item.priority === 'HIGH'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : item.priority === 'NORMAL'
                        ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                        : 'bg-stone-800 text-slate-400 border-stone-700';

                    const statusPill = isCompleted ? (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                        COMPLETED
                      </span>
                    ) : isProcessingStatus ? (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold animate-pulse">
                        {item.currentStage || 'PROCESSING'}
                      </span>
                    ) : isQueued ? (
                      <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[10px] font-bold">
                        QUEUED
                      </span>
                    ) : isFailed ? (
                      <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] font-bold">
                        FAILED
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-stone-800 text-stone-400 border border-stone-700 text-[10px] font-bold">
                        CANCELLED
                      </span>
                    );

                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800 hover:border-stone-700/80 transition space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className={`px-2 py-0.5 rounded-md border text-[10px] font-mono font-bold ${priorityBg}`}>
                                {item.priority}
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-stone-800 text-red-400 font-bold text-[10px]">
                                {item.level}
                              </span>
                              {statusPill}
                              <span className="text-xs text-stone-500 font-mono">Job: {item.id}</span>
                            </div>
                            <h4 className="text-sm font-bold text-white">
                              {item.titleJa ? `${item.titleJa} — ` : ''}
                              {item.title}
                            </h4>
                            <p className="text-xs text-stone-400">{item.changelog}</p>
                          </div>

                          <div className="flex items-center gap-2">
                            {item.preflightReport && (
                              <button
                                onClick={() => {
                                  setPreflightModalReport(item.preflightReport);
                                  setShowPreflightModal(true);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 border border-stone-700 text-slate-300 text-xs font-medium transition cursor-pointer"
                              >
                                Pre-flight: {item.preflightReport.score}/100
                              </button>
                            )}
                            {(isQueued || isProcessingStatus) && (
                              <button
                                onClick={() => handleCancelQueueJob(item.id)}
                                className="px-2.5 py-1 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-800/40 text-red-300 text-xs font-medium transition cursor-pointer"
                              >
                                Cancel
                              </button>
                            )}
                            {(isFailed || isCancelled) && (
                              <button
                                onClick={() => handleRetryQueueJob(item.id)}
                                className="px-2.5 py-1 rounded-lg bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/40 text-amber-300 text-xs font-medium transition cursor-pointer flex items-center gap-1"
                              >
                                <RotateCcw className="w-3 h-3" /> Retry
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Progress Bar & Stage Indicator */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                            <span>Stage: {item.currentStage || 'PENDING'}</span>
                            <span>{item.progress || 0}%</span>
                          </div>
                          <div className="w-full bg-stone-900 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full transition-all duration-300 ${
                                isCompleted
                                  ? 'bg-emerald-500'
                                  : isFailed
                                  ? 'bg-rose-500'
                                  : 'bg-amber-500'
                              }`}
                              style={{ width: `${item.progress || 0}%` }}
                            />
                          </div>
                        </div>

                        {/* Scheduled Time or Target IDs */}
                        <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1 border-t border-stone-900">
                          <div>
                            {item.scheduledFor ? (
                              <span className="text-blue-400 flex items-center gap-1">
                                <Calendar className="w-3 h-3" /> Scheduled for: {new Date(item.scheduledFor).toLocaleString()}
                              </span>
                            ) : (
                              <span>Immediate Automated Release</span>
                            )}
                          </div>
                          <div>
                            {item.publishedLessonId && (
                              <span className="text-emerald-400 font-mono">
                                Live ID: {item.publishedLessonId} (v{item.versionNumber || 1})
                              </span>
                            )}
                            {item.error && <span className="text-rose-400 line-clamp-1">{item.error}</span>}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* P1-03: ENQUEUE FOR LIVE PUBLISHING DIALOG                */}
        {/* ======================================================== */}
        {showEnqueueModal && enqueueTargetLesson && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    <Clock className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">Queue Live Lesson Publishing</h3>
                    <p className="text-xs text-slate-400">Target: {enqueueTargetLesson.title}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowEnqueueModal(false)}
                  className="w-7 h-7 rounded-full bg-stone-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Form Options */}
              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">Publishing Priority</label>
                  <select
                    value={enqueuePriority}
                    onChange={(e: any) => setEnqueuePriority(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl p-2.5 text-white font-medium focus:border-amber-500 outline-none"
                  >
                    <option value="CRITICAL">CRITICAL (P0 Hotfix / Urgent Curriculum Correction)</option>
                    <option value="HIGH">HIGH (JLPT Syllabus Milestone Release)</option>
                    <option value="NORMAL">NORMAL (Standard Automated Production Flow)</option>
                    <option value="LOW">LOW (Backlog Archive / Optional Supplementary)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">
                    Deferred Release Schedule (Optional)
                  </label>
                  <input
                    type="datetime-local"
                    value={enqueueScheduledDate}
                    onChange={(e) => setEnqueueScheduledDate(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl p-2.5 text-white font-medium focus:border-amber-500 outline-none"
                  />
                  <p className="text-[11px] text-stone-500 mt-1">Leave blank for immediate automated processing.</p>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">Version Release Changelog</label>
                  <textarea
                    value={enqueueChangelog}
                    onChange={(e) => setEnqueueChangelog(e.target.value)}
                    rows={3}
                    placeholder="Describe educational or technical improvements in this release..."
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl p-2.5 text-white font-medium focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-800">
                <button
                  onClick={() => setShowEnqueueModal(false)}
                  className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-slate-300 font-semibold text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmEnqueue}
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-stone-950 font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4" /> Enqueue Lesson
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* P1-03: PRE-FLIGHT CURRICULUM VERIFICATION REPORT MODAL   */}
        {/* ======================================================== */}
        {showPreflightModal && preflightModalReport && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-3xl w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] flex flex-col">
              <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    <ShieldCheck className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">8-Point Pre-flight Curriculum Report</h3>
                    <p className="text-xs text-slate-400">Evaluated at: {new Date(preflightModalReport.evaluatedAt).toLocaleString()}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPreflightModal(false)}
                  className="w-7 h-7 rounded-full bg-stone-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Overall Score Badge */}
              <div className="p-4 rounded-2xl bg-stone-950 border border-stone-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Pre-flight Readiness Score</span>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-3xl font-black text-white">{preflightModalReport.score}</span>
                    <span className="text-xs text-slate-500">/ 100</span>
                  </div>
                </div>
                <div>
                  {preflightModalReport.passed ? (
                    <span className="px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-black">
                      PASSED (READY FOR LIVE PUBLISHING)
                    </span>
                  ) : (
                    <span className="px-3.5 py-1.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 text-xs font-black">
                      REJECTED ({preflightModalReport.errorsCount} CRITICAL FAILURES)
                    </span>
                  )}
                </div>
              </div>

              {/* Checklist Breakdown */}
              <div className="flex-1 overflow-y-auto pr-1 space-y-2.5">
                {preflightModalReport.checks?.map((check: any, idx: number) => {
                  const isPass = check.status === 'PASS';
                  const isWarn = check.status === 'WARN';
                  const isFail = check.status === 'FAIL';

                  const badgeClass = isPass
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    : isWarn
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                    : 'bg-red-500/20 text-red-400 border-red-500/30';

                  return (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-stone-800 text-slate-400 font-mono text-[10px]">
                            {check.category}
                          </span>
                          <span className="font-bold text-white">{check.name}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold ${badgeClass}`}>
                          {check.status}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] leading-relaxed">{check.message}</p>
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-end pt-3 border-t border-stone-800">
                <button
                  onClick={() => setShowPreflightModal(false)}
                  className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
                >
                  Close Report
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
