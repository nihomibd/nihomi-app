import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Award,
  BarChart3,
  LogOut,
  Flame,
  Mic,
  PenTool,
  ArrowRight,
  User as UserIcon,
  Play,
  Sparkles,
  CheckCircle2,
  Clock,
  Trophy,
  ShieldCheck,
  Zap,
  Radio,
  Crown,
  Brain,
  Headphones,
  HardDrive
} from 'lucide-react';
import { DigitalStudentIdCard } from '../components/student/DigitalStudentIdCard';
import { LearningAnalyticsDashboard } from '../components/student/LearningAnalyticsDashboard';
import { KanjiWritingModal } from '../components/student/KanjiWritingModal';
import { LessonPlayerModal } from '../components/learning/LessonPlayerModal';
import { VoiceSenseiPractice } from "../components/practice/VoiceSenseiPractice";
import { TokyoPitchAccentLab } from '../components/voice/TokyoPitchAccentLab';
import { SRSFlashcardSession } from '../components/practice/SRSFlashcardSession';
import { BadgeSystem } from '../components/BadgeSystem';
import { GhostModeSRSWidget } from '../components/practice/GhostModeSRSWidget';
import { NextBestActionCard } from '../components/student/NextBestActionCard';
import { StreakWidget } from '../features/student-dashboard/components/StreakWidget';
import { Course, StudentProfile, NextBestAction } from '../types/nihomi';
import { useAuth } from '../context/AuthContext';
import { Ghost } from 'lucide-react';
import { ProUpgradeModal } from '../components/billing/ProUpgradeModal';

interface StudentPortalViewProps {
  initialTab?: 'learn' | 'practice' | 'assess' | 'progress' | 'profile' | 'badges' | 'dashboard' | 'settings' | 'subscription';
  onNavigate?: (view: string, params?: Record<string, any>) => void;
}

const KANJI_CARDS = [
  { kanji: '日', reading: 'にち・ひ', meaning: 'Sun, Day, Japan', level: 'N5' },
  { kanji: '本', reading: 'ほん・もと', meaning: 'Book, Origin', level: 'N5' },
  { kanji: '語', reading: 'ご・かたる', meaning: 'Language, Word', level: 'N5' },
  { kanji: '学', reading: 'がく・まなぶ', meaning: 'Study, Learn', level: 'N5' },
  { kanji: '生', reading: 'せい・いきる', meaning: 'Life, Student', level: 'N5' },
  { kanji: '先', reading: 'せん・さき', meaning: 'Ahead, Previous', level: 'N5' },
];

const DEFAULT_COURSE: Course = {
  id: 'minna-1',
  title: 'Minna no Nihongo Lesson 1',
  titleJa: 'みんなの日本語 第1課',
  level: 'N5',
  progressPercent: 40,
  totalLessons: 25,
  completedLessons: 1,
  currentLessonTitle: 'N1 は N2 です (Affirmation, Negation, & Questions)',
  category: 'GRAMMAR',
};

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({
  initialTab = 'learn',
  onNavigate,
}) => {
  const { user, profile, progress, logout } = useAuth();
  const resolveTab = (tab: string): 'learn' | 'practice' | 'assess' | 'progress' | 'badges' | 'profile' => {
    if (tab === 'dashboard') return 'learn';
    if (tab === 'settings' || tab === 'subscription') return 'profile';
    if (['learn', 'practice', 'assess', 'progress', 'badges', 'profile'].includes(tab)) {
      return tab as any;
    }
    return 'learn';
  };
  const [activeTab, setActiveTab] = useState<'learn' | 'practice' | 'assess' | 'progress' | 'badges' | 'profile'>(() => resolveTab(initialTab));

  // Pro status & upgrade modal
  const [isProModalOpen, setIsProModalOpen] = useState(false);
  const isPro =
    user?.role === 'founder' ||
    user?.role === 'admin' ||
    user?.planId === 'pro' ||
    user?.planId === 'japan_ready' ||
    (user as any)?.subscription?.planId === 'pro' ||
    (user as any)?.subscription?.planId === 'japan_ready' ||
    (user as any)?.subscription?.status === 'active';

  // Modals state
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [isSRSFlashcardsActive, setIsSRSFlashcardsActive] = useState(false);
  const [isWritingActive, setIsWritingActive] = useState(false);
  const [activeKanjiToDraw, setActiveKanjiToDraw] = useState<{ kanji: string; hiragana: string; english: string; strokes: number } | null>(null);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isPitchAccentLabOpen, setIsPitchAccentLabOpen] = useState(false);

  // Dynamic metrics from user actions & local storage
  const completedLessonsCount = useMemo(() => {
    try {
      const saved = localStorage.getItem('nihomi_completed_lessons');
      return saved ? JSON.parse(saved).length : (progress?.completedLessonsCount ?? 0);
    } catch {
      return progress?.completedLessonsCount ?? 0;
    }
  }, [progress]);

  const masteredKanjiCount = useMemo(() => {
    try {
      const saved = localStorage.getItem('nihomi_mastered_kanji_set');
      return saved ? JSON.parse(saved).length : 0;
    } catch {
      return 0;
    }
  }, []);

  const totalFocusSeconds = useMemo(() => {
    try {
      const saved = localStorage.getItem('nihomi_total_focus_seconds');
      return saved ? parseInt(saved, 10) : ((progress?.totalHours ?? 0) * 3600);
    } catch {
      return (progress?.totalHours ?? 0) * 3600;
    }
  }, [progress]);

  const computedTotalHours = Number((totalFocusSeconds / 3600).toFixed(1));

  const studentProfile: StudentProfile = {
    id: user?.studentId || 'NHO-' + (user?.id ? user.id.slice(0, 6).toUpperCase() : '100001'),
    name: user?.name || 'Nihomi Student',
    nameJa: user?.nameJa || 'スチューデント',
    email: user?.email || '',
    avatarUrl: user?.avatarUrl || '',
    currentLevel: (user?.currentLevel as any) || progress?.currentLevel || 'N5',
    targetLevel: (user?.targetLevel as any) || profile?.targetLevel || 'N4',
    targetExamDate: profile?.targetExamDate || '2026-07-05',
    enrolledDate: user?.createdAt ? user.createdAt.split('T')[0] : new Date().toISOString().split('T')[0],
    streakDays: progress?.streakDays ?? progress?.currentStreak ?? user?.streakDays ?? 0,
    totalStudyHours: Math.max(computedTotalHours, progress?.totalHours ?? 0),
    nihomiAccountId: user?.nihomiAccountId || 'ACC-' + (user?.id ? user.id.slice(0, 4).toUpperCase() : '1001'),
    tier: (user?.planId as any) || 'starter',
  };

  const nextAction: NextBestAction = {
    id: 'nba-1',
    type: 'LESSON',
    title: 'Minna no Nihongo Lesson 1 Grammar Master',
    subtitle: 'N1 は N2 です / N1 は N2 じゃありません',
    level: 'N5',
    estimatedMinutes: 12,
    rewardCoins: 25,
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] dark:bg-[#0a0a12] sepia:bg-[#fbf0d9] text-stone-900 dark:text-stone-100 font-sans pb-24 text-left transition-colors selection:bg-red-500 selection:text-white">
      
      {/* 1. TOP STUDENT STATUS BAR */}
      <div className="bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border-b border-stone-200/80 dark:border-stone-800 sepia:border-[#d9cbb2] sticky top-16 z-30 shadow-2xs">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            
            {/* Tab Navigation */}
            <div className="flex space-x-1 sm:space-x-2 overflow-x-auto no-scrollbar py-1">
              {[
                { id: 'learn', label: '1. Learn (学習)', icon: BookOpen },
                { id: 'practice', label: '2. Practice (練習)', icon: PenTool },
                { id: 'assess', label: '3. Assess (評価)', icon: Award },
                { id: 'badges', label: '4. Badges (実績)', icon: Trophy },
                { id: 'progress', label: '5. Analytics (分析)', icon: BarChart3 },
                { id: 'profile', label: '6. Student ID (パスポート)', icon: UserIcon },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`student-tab-${tab.id}`}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 cursor-pointer ${
                      isActive
                        ? 'bg-stone-900 dark:bg-white text-white dark:text-stone-900 shadow-2xs'
                        : 'text-stone-600 dark:text-stone-400 hover:text-stone-950 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Streak, Study Time & Plan Badge */}
            <div className="hidden sm:flex items-center space-x-2.5">
              <div className="flex items-center space-x-1 px-2.5 py-1 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/40 rounded-full text-xs font-bold text-amber-900 dark:text-amber-300">
                <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>{studentProfile.streakDays} Day Streak</span>
              </div>
              <div className="flex items-center space-x-1 px-2.5 py-1 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 rounded-full text-xs font-bold text-blue-900 dark:text-blue-300">
                <Clock className="w-3.5 h-3.5 text-blue-500" />
                <span>{studentProfile.totalStudyHours}h Focus</span>
              </div>
              {!isPro ? (
                <button
                  id="btn-portal-header-upgrade-pro"
                  type="button"
                  onClick={() => setIsProModalOpen(true)}
                  className="px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-stone-950 text-xs font-black rounded-full flex items-center gap-1 shadow-xs cursor-pointer transition-all active:scale-95"
                  title="Nihomi Pro — Unlock All Lessons"
                >
                  <Crown className="w-3.5 h-3.5 fill-stone-950" />
                  <span>Upgrade to PRO</span>
                </button>
              ) : (
                <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-700/50 text-xs font-mono font-bold rounded-full flex items-center gap-1">
                  <Crown className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </span>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* 2. TAB 1: LEARN (CURRICULUM & AI SENSEI ACTION) */}
      {activeTab === 'learn' && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          
          {/* Nihomi Pro™ Unlock Banner for Non-Pro students */}
          {!isPro && (
            <div
              id="portal-pro-banner"
              className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-stone-900 via-stone-950 to-stone-900 border-2 border-amber-500/40 p-6 shadow-xl text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6"
            >
              <div className="space-y-2 max-w-xl">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-extrabold uppercase tracking-wide">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Nihomi Pro™ Exclusive</span>
                </div>
                <h3 className="text-xl font-black text-white">
                  সম্পূর্ণ JLPT N5 এর ২৫টি লেসন ও AI ভয়েস টিউটর আনলক করুন
                </h3>
                <p className="text-xs text-stone-300 leading-relaxed">
                  লেসন ০১–০৫ সম্পূর্ণ ফ্রি। লেসন ০৬–২৫ এর অ্যাডভান্সড ব্যাকরণ, কানজি ড্রয়িং এবং টোকিও অ্যাকসেন্ট ফিডব্যাক পেতে Pro নিন মাত্র ৳৫৯৯/মাসে।
                </p>
              </div>
              <button
                id="btn-portal-upgrade-cta"
                type="button"
                onClick={() => setIsProModalOpen(true)}
                className="px-6 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-stone-950 font-black text-xs rounded-2xl shadow-lg flex items-center gap-2 cursor-pointer active:scale-95 shrink-0"
              >
                <Crown className="w-4 h-4 fill-stone-950" />
                <span>Upgrade to PRO — আনলক করুন</span>
              </button>
            </div>
          )}

          {/* Dynamic Next Best Learning Action Card (MemoryOS Driven) */}
          <NextBestActionCard
            userId={user?.id}
            completedLessonsCount={completedLessonsCount}
            onLaunchLesson={(lessonId) => {
              if (onNavigate) {
                onNavigate('lesson', { lessonId: lessonId || 'n5-l1' });
              } else {
                setIsLessonModalOpen(true);
              }
            }}
            onLaunchReview={(concept) => {
              setIsSRSFlashcardsActive(true);
            }}
            onOpenZeroGateway={() => {
              if (onNavigate) {
                onNavigate('kana');
              } else {
                setIsLessonModalOpen(true);
              }
            }}
          />

          {/* Daily Streak & Gamification Retention Widget */}
          <StreakWidget
            onActivityClick={(type) => {
              if (type === 'KANA') {
                onNavigate?.('kana');
              } else if (type === 'LISTENING') {
                onNavigate?.('listening-lab');
              } else if (type === 'QUIZ') {
                if (onNavigate) onNavigate('quizzes');
                else setActiveTab('assess');
              } else if (type === 'AI_CHAT') {
                setIsVoiceActive(true);
              }
            }}
          />

          {/* Quick AI Practice Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div
              id="card-listening-lab"
              onClick={() => (onNavigate ? onNavigate('listening-lab') : null)}
              className="p-5 bg-gradient-to-br from-red-500/10 to-amber-500/5 bg-white dark:bg-[#12121e] sepia:bg-[#f6ebd4] border border-red-500/30 rounded-2xl hover:border-red-500 transition-all cursor-pointer space-y-2 group shadow-xs"
            >
              <div className="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 flex items-center justify-center font-bold text-xs">
                <Headphones className="w-4 h-4" />
              </div>
              <div className="flex items-center space-x-1.5">
                <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100 group-hover:text-red-400 transition-colors">
                  লিসেনিং অডিও ল্যাব
                </h4>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 font-bold">
                  第1-25課
                </span>
              </div>
              <p className="text-xs text-stone-500">মিন্না নো নিহোঙ্গো ১–২৫ এর খাঁটি অডিও ও Choukai কুইজ</p>
            </div>

            <div
              id="card-srs-deck"
              onClick={() => setIsSRSFlashcardsActive(true)}
              className="p-5 bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border border-stone-200 dark:border-stone-800 rounded-2xl hover:border-stone-400 transition-all cursor-pointer space-y-2"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-xs">
                SRS
              </div>
              <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">Spaced Repetition Deck</h4>
              <p className="text-xs text-stone-500">Review your due Kanji & Vocab memory cards</p>
            </div>

            <div
              id="card-voice-practice"
              onClick={() => setIsVoiceActive(true)}
              className="p-5 bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border border-stone-200 dark:border-stone-800 rounded-2xl hover:border-stone-400 transition-all cursor-pointer space-y-2"
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                <Mic className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">Voice Sensei Practice</h4>
              <p className="text-xs text-stone-500">Real-time Tokyo pronunciation coaching</p>
            </div>

            <div
              id="card-pitch-accent-lab"
              onClick={() => setIsPitchAccentLabOpen(true)}
              className="p-5 bg-gradient-to-br from-amber-500/5 to-red-500/5 dark:from-amber-950/20 dark:to-red-950/20 bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border border-amber-500/30 dark:border-amber-500/20 rounded-2xl hover:border-amber-500 transition-all cursor-pointer space-y-2 group shadow-xs"
            >
              <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center font-bold text-xs">
                <Radio className="w-4 h-4 animate-pulse" />
              </div>
              <div className="flex items-center space-x-1.5">
                <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">Tokyo Pitch-Accent Lab</h4>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold">
                  東京式
                </span>
              </div>
              <p className="text-xs text-stone-500">Master Odaka, Atamadaka, Nakadaka & Heiban minimal pairs</p>
            </div>

            <div
              id="card-quizzes"
              onClick={() => onNavigate ? onNavigate('quizzes') : setActiveTab('assess')}
              className="p-5 bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border border-stone-200 dark:border-stone-800 rounded-2xl hover:border-stone-400 transition-all cursor-pointer space-y-2"
            >
              <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-xs">
                <Award className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">JLPT N5 Quizzes & Drills</h4>
              <p className="text-xs text-stone-500">Practice grammar questions & mock tests</p>
            </div>

            <div
              id="card-leaderboard-shortcut"
              onClick={() => onNavigate ? onNavigate('leaderboard') : null}
              className="p-5 bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] border border-stone-200 dark:border-stone-800 rounded-2xl hover:border-stone-400 transition-all cursor-pointer space-y-2"
            >
              <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-xs">
                <Trophy className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">Community Leaderboard</h4>
              <p className="text-xs text-stone-500">Check weekly XP rankings & student honor roll</p>
            </div>

            <div
              id="card-ghost-mode"
              onClick={() => onNavigate ? onNavigate('ghost-mode') : setActiveTab('practice')}
              className="p-5 bg-[#0f101c] border border-red-500/30 rounded-2xl hover:border-red-500 transition-all cursor-pointer space-y-2 group shadow-sm col-span-1 sm:col-span-2 lg:col-span-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 rounded-xl bg-red-950/60 border border-red-500/40 text-red-400 flex items-center justify-center font-bold text-xs">
                    <Ghost className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white group-hover:text-red-400 transition-colors">
                      Ghost Mode™ SRS Weak-Spot Recovery
                    </h4>
                    <p className="text-xs text-stone-400">
                      Master difficult particles (は vs が, に vs で) and verb forms with SM-2 spaced repetition
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-red-600/20 text-red-400 text-xs font-bold font-mono rounded-lg border border-red-500/30 flex items-center space-x-1">
                  <span>Open Lab</span>
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>

            <div
              id="card-nihomi-cloud-portal"
              onClick={() => onNavigate ? onNavigate('cloud') : null}
              className="p-5 bg-gradient-to-br from-indigo-500/10 via-slate-900 to-indigo-950/30 border border-indigo-500/30 rounded-2xl hover:border-indigo-400 transition-all cursor-pointer space-y-2 group shadow-sm col-span-1 sm:col-span-2 lg:col-span-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-bold text-xs">
                    <HardDrive className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white group-hover:text-indigo-400 transition-colors flex items-center gap-2">
                      <span>Nihomi Cloud™ & Japan Readiness Locker</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                        Personal Vault
                      </span>
                    </h4>
                    <p className="text-xs text-stone-400">
                      আপনার পাসপোর্ট, COE, ভিসা ও স্টাডি মেটেরিয়ালের সুরক্ষিত ক্লাউড স্টোরেজ এবং AI ডকুমেন্ট সামারি
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-indigo-600/20 text-indigo-300 text-xs font-bold font-mono rounded-lg border border-indigo-500/30 flex items-center space-x-1">
                  <span>Open Vault</span>
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* 3. TAB 2: PRACTICE (KANJI & MEMORY) */}
      {activeTab === 'practice' && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          {/* SRS Flashcard Memory Deck Quick Access Hero */}
          <div
            id="srs-deck-practice-hero"
            onClick={() => setIsSRSFlashcardsActive(true)}
            className="p-6 bg-gradient-to-r from-blue-900/30 via-slate-900 to-indigo-900/30 border-2 border-blue-500/30 hover:border-blue-500 rounded-3xl cursor-pointer shadow-xl transition-all group flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-500/40 text-blue-400 flex items-center justify-center font-bold text-base shadow-md group-hover:scale-105 transition-transform">
                <Brain className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 border border-blue-500/40 text-blue-300">
                    SRS SM-2 Memory Engine
                  </span>
                  <span className="text-xs text-stone-400 font-mono">Leitner 5-Box Deck</span>
                </div>
                <h3 className="text-lg font-black text-white group-hover:text-blue-300 transition-colors mt-0.5">
                  Flashcard SRS Memory Deck (স্পেসড রিপিটিশন ফ্ল্যাশ কার্ড)
                </h3>
                <p className="text-xs text-stone-400">
                  Interactive flip cards (Kanji/Hiragana front &bull; Bengali meaning & Tokyo pitch back &bull; Easy/Hard rating)
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsSRSFlashcardsActive(true);
              }}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all flex items-center gap-2 shrink-0 group-hover:shadow-blue-500/25 cursor-pointer"
            >
              <span>Launch Flashcard Deck</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Dedicated Ghost Mode SRS Drill Section */}
          <GhostModeSRSWidget />

          <div className="space-y-1 pt-4 border-t border-stone-200 dark:border-stone-800">
            <h2 className="text-2xl font-black text-stone-950 dark:text-white">Active Kanji Stroke Matrix</h2>
            <p className="text-xs text-stone-500 font-medium">Click any Kanji card below to practice stroke order on interactive canvas</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {KANJI_CARDS.map((k) => (
              <div
                key={k?.kanji}
                id={`kanji-card-${k?.kanji}`}
                onClick={() => {
                  setActiveKanjiToDraw({ kanji: k?.kanji, hiragana: k.reading, english: k.meaning, strokes: 4 });
                  setIsWritingActive(true);
                }}
                className="bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] p-4 rounded-2xl border border-stone-200 dark:border-stone-800 hover:border-stone-400 text-center cursor-pointer transition-all shadow-2xs hover:scale-102 space-y-1"
              >
                <div className="text-3xl font-black text-stone-900 dark:text-white font-japanese">{k?.kanji}</div>
                <div className="text-[10px] text-stone-500 font-japanese truncate">{k.reading}</div>
                <div className="text-[10px] font-bold text-stone-800 dark:text-stone-200 truncate">{k.meaning}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. TAB 3: ASSESS (EVALUATION & QUIZZES) */}
      {activeTab === 'assess' && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-stone-950 dark:text-white">Assessment & JLPT Readiness</h2>
            <p className="text-xs text-stone-500 font-medium">Test your knowledge across Vocabulary, Grammar, Reading, and Listening</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] p-6 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 flex items-center justify-center font-black">
                  N5
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900 dark:text-white">JLPT N5 Full Diagnostic</h3>
                  <p className="text-xs text-stone-500">18 questions covering particle mechanics and essential kanji</p>
                </div>
              </div>
              <ul className="space-y-2 text-xs text-stone-600 dark:text-stone-400">
                <li className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Grammar Particles (は, が, に, で, を)</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Basic Verb Conjugations (ます, ません, ました)</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Time, Numbers, and Direction words</span>
                </li>
              </ul>
              <button
                id="btn-start-diagnostic"
                onClick={() => onNavigate ? onNavigate('quizzes') : setActiveTab('learn')}
                className="w-full py-3 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer transition-all"
              >
                <span>Take Diagnostic Quiz</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="bg-white dark:bg-stone-900 sepia:bg-[#f6ebd4] p-6 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-black">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900 dark:text-white">JLPT Mock Exam Mode</h3>
                  <p className="text-xs text-stone-500">Timed simulation under authentic JLPT scoring rubrics</p>
                </div>
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
                Experience the timed pressure of standard JLPT exam conditions with automatic scoring and error-breakdown recommendations.
              </p>
              <button
                id="btn-start-mock-exam"
                onClick={() => onNavigate ? onNavigate('quizzes') : setActiveTab('learn')}
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer transition-all"
              >
                <span>Launch Mock Exam (Timed)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. TAB 4: BADGES & ACHIEVEMENTS (GALLERY) */}
      {activeTab === 'badges' && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
          <BadgeSystem
            currentStreak={studentProfile.streakDays}
            completedLessonsCount={completedLessonsCount}
            masteredKanjiCount={masteredKanjiCount}
          />
        </div>
      )}

      {/* 6. TAB 5: PROGRESS & DNA */}
      {activeTab === 'progress' && (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          <LearningAnalyticsDashboard
            studentName={studentProfile.name}
            currentLevel={studentProfile.currentLevel}
            totalStudyHours={studentProfile.totalStudyHours}
            studyStreakDays={studentProfile.streakDays}
            onLaunchSrsReview={() => setIsSRSFlashcardsActive(true)}
          />

          {/* Embedded Badges Preview in Analytics */}
          <div className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-stone-900 dark:text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span>Unlocked Milestone Badges</span>
              </h3>
              <button
                onClick={() => setActiveTab('badges')}
                className="text-xs font-bold text-red-600 hover:underline"
              >
                View Full Gallery →
              </button>
            </div>
            <BadgeSystem
              currentStreak={studentProfile.streakDays}
              completedLessonsCount={completedLessonsCount}
              masteredKanjiCount={masteredKanjiCount}
              compact={true}
            />
          </div>
        </div>
      )}

      {/* 7. TAB 6: STUDENT PASSPORT / PROFILE */}
      {activeTab === 'profile' && (
        <div className="max-w-4xl mx-auto px-4 pt-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            <div className="md:col-span-1 space-y-4">
              <DigitalStudentIdCard student={studentProfile} />
              
              <div className="p-4 bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 text-center space-y-3">
                <button
                  id="btn-student-logout"
                  onClick={logout}
                  className="w-full py-2.5 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 text-red-600 rounded-xl text-xs font-bold transition-colors flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out of Nihomi</span>
                </button>
              </div>
            </div>

            <div className="md:col-span-2 space-y-6">
              <div className="bg-white dark:bg-stone-900 p-6 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-black text-stone-900 dark:text-white flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-500" />
                    <span>Achievement Showcase</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('badges')}
                    className="text-xs font-bold text-stone-500 hover:text-stone-900 dark:hover:text-white"
                  >
                    All Badges →
                  </button>
                </div>
                
                <BadgeSystem
                  currentStreak={studentProfile.streakDays}
                  completedLessonsCount={completedLessonsCount}
                  masteredKanjiCount={masteredKanjiCount}
                  compact={true}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      {isLessonModalOpen && (
        <LessonPlayerModal
          isOpen={isLessonModalOpen}
          onClose={() => setIsLessonModalOpen(false)}
          course={DEFAULT_COURSE}
        />
      )}

      {isSRSFlashcardsActive && (
        <SRSFlashcardSession
          isOpen={isSRSFlashcardsActive}
          onClose={() => setIsSRSFlashcardsActive(false)}
        />
      )}

      {isWritingActive && (
        <KanjiWritingModal
          isOpen={isWritingActive}
          onClose={() => setIsWritingActive(false)}
          targetKanji={activeKanjiToDraw || undefined}
        />
      )}

      {isVoiceActive && (
        <VoiceSenseiPractice
          isOpen={isVoiceActive}
          onClose={() => setIsVoiceActive(false)}
        />
      )}

      {isPitchAccentLabOpen && (
        <TokyoPitchAccentLab
          isOpen={isPitchAccentLabOpen}
          onClose={() => setIsPitchAccentLabOpen(false)}
        />
      )}

      {/* Global Pro Upgrade Modal for Student Portal */}
      <ProUpgradeModal
        isOpen={isProModalOpen}
        onClose={() => setIsProModalOpen(false)}
        defaultPlanInterval="monthly"
        onSuccess={() => setIsProModalOpen(false)}
      />

    </div>
  );
};
