import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  Minus,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  HelpCircle,
  CreditCard,
  Smartphone,
  Lock,
  ExternalLink
} from 'lucide-react';
import { Plan, PlanId, BillingInterval } from '../types';
import { useAuth } from '../context/AuthContext';
import { CheckoutModal } from '../components/CheckoutModal';

interface PricingViewProps {
  onSelectPlan?: (planId: PlanId) => void;
  onNavigate?: (view: string) => void;
}

interface FeatureComparisonRow {
  name: string;
  starter: string | boolean;
  pro: string | boolean;
  japanReady: string | boolean;
}

interface FeatureComparisonCategory {
  category: string;
  rows: FeatureComparisonRow[];
}

export const PricingView: React.FC<PricingViewProps> = ({ onSelectPlan, onNavigate }) => {
  const { user, activePlanId } = useAuth();
  const [interval, setInterval] = useState<BillingInterval>('monthly');
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<Plan | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // 3 Core Plans: Starter, Pro, Japan Ready
  const plans: Array<{
    id: PlanId;
    name: string;
    nameJa: string;
    tagline: string;
    monthlyPrice: number;
    annualMonthlyEquivalent: number;
    annualBilledTotal: number;
    savingsAmount: number;
    isPopular: boolean;
    badge?: string;
    ctaText: string;
    features: string[];
  }> = [
    {
      id: 'starter',
      name: 'Starter',
      nameJa: 'スターター',
      tagline: 'Essential Japanese for motivated beginners.',
      monthlyPrice: 299,
      annualMonthlyEquivalent: 239,
      annualBilledTotal: 2870,
      savingsAmount: 718,
      isPopular: false,
      ctaText: 'Get Started',
      features: [
        'Complete JLPT N5 25-Lesson Curriculum',
        '46 Kana Interactive Stroke & Audio Lab',
        '100 AI Sensei queries per month',
        'Essential N5 vocabulary & audio drills',
        'Standard mobile & tablet sync',
        'Community discussion & peer practice'
      ]
    },
    {
      id: 'pro',
      name: 'Pro',
      nameJa: 'プロ',
      tagline: 'Most popular for passing JLPT & career momentum.',
      monthlyPrice: 599,
      annualMonthlyEquivalent: 479,
      annualBilledTotal: 5750,
      savingsAmount: 1438,
      isPopular: true,
      badge: 'Most Popular',
      ctaText: 'Upgrade to Pro',
      features: [
        'Everything in Starter, plus:',
        'Full JLPT N5 + N4 + N3 Accelerated Curriculum',
        '1,000 AI Sensei Coaching Queries / Month',
        'BaitoOS™ Tokyo Convenience Store Simulator',
        'Official 180-Mark JLPT Timed Mock Exams',
        'Pitch-accent audio feedback & shadowing',
        'Verifiable Digital Certificate of Completion'
      ]
    },
    {
      id: 'japan_ready',
      name: 'Japan Ready',
      nameJa: '日本レディ',
      tagline: 'Ultimate preparation for working and relocating to Japan.',
      monthlyPrice: 999,
      annualMonthlyEquivalent: 799,
      annualBilledTotal: 9590,
      savingsAmount: 2398,
      isPopular: false,
      ctaText: 'Get Japan Ready',
      features: [
        'Everything in Pro, plus:',
        'Unlimited Priority AI Sensei Mentorship',
        'Tokyo Workplace Keigo & Business Etiquette',
        'SSW, TITP & Tech Visa Interview Simulator',
        'Japanese Resume (Rirekisho / Shokumu) Generator',
        '1-on-1 Personalized Study Plan Diagnostics',
        'Direct Japan Relocation & Career Advisory Hub'
      ]
    }
  ];

  const comparisonCategories: FeatureComparisonCategory[] = [
    {
      category: 'Curriculum & Mastery',
      rows: [
        {
          name: 'JLPT N5 Core Lessons (Minna no Nihongo 1-25)',
          starter: true,
          pro: true,
          japanReady: true
        },
        {
          name: 'JLPT N4 & N3 Intermediate Levels',
          starter: false,
          pro: true,
          japanReady: true
        },
        {
          name: '46 Kana & 100 Essential Kanji Labs',
          starter: true,
          pro: true,
          japanReady: true
        },
        {
          name: '180-Mark Full JLPT Timed Mock Exams',
          starter: '1 practice quiz',
          pro: 'Full JLPT Pro Exams',
          japanReady: 'Unlimited Mock Exams'
        },
        {
          name: 'Native Tokyo Audio Dialogues (Choukai)',
          starter: 'Standard',
          pro: 'High Fidelity + Shadowing',
          japanReady: 'Full Studio Library'
        }
      ]
    },
    {
      category: 'AI Sensei & Intelligence',
      rows: [
        {
          name: 'AI Sensei Coaching Monthly Quota',
          starter: '100 queries/mo',
          pro: '1,000 queries/mo',
          japanReady: 'Unlimited Priority'
        },
        {
          name: 'Grammar Correction & Bengali Explanations',
          starter: true,
          pro: true,
          japanReady: true
        },
        {
          name: 'Tokyo Pitch-Accent & Audio Evaluation',
          starter: false,
          pro: true,
          japanReady: true
        },
        {
          name: 'BaitoOS™ Conbini Work Simulator',
          starter: false,
          pro: 'Full Scenario Access',
          japanReady: 'Advanced Scenarios'
        }
      ]
    },
    {
      category: 'Career & Japan Relocation',
      rows: [
        {
          name: 'Workplace Keigo & Business Communication',
          starter: false,
          pro: false,
          japanReady: true
        },
        {
          name: 'Japan Embassy & Job Visa Interview Defense',
          starter: false,
          pro: false,
          japanReady: true
        },
        {
          name: 'Bilingual JIS Japanese Resume Generator',
          starter: false,
          pro: false,
          japanReady: true
        },
        {
          name: 'Verifiable Digital Certificate of Completion',
          starter: false,
          pro: true,
          japanReady: 'Verified Digital Credential'
        },
        {
          name: 'Priority Technical & Academic Support',
          starter: 'Standard',
          pro: 'Priority WhatsApp Desk',
          japanReady: 'Dedicated Advisor'
        }
      ]
    }
  ];

  const faqs = [
    {
      question: 'How do payments work in Bangladesh?',
      answer:
        'We support direct instant payments in Bangladeshi Taka (৳) through bKash Tokenized Checkout, Nagad, Rocket, and all local Visa/Mastercard debit and credit cards via SSLCommerz. No international credit card or currency conversion fees are required.'
    },
    {
      question: 'Can I switch or cancel my plan anytime?',
      answer:
        'Yes. You have complete autonomy. You can upgrade, downgrade, or cancel your subscription at any time with a single click from your Student Portal. Your plan privileges will remain active until the end of your billing cycle.'
    },
    {
      question: 'What is the difference between Starter and Pro?',
      answer:
        'Starter gives you complete mastery of JLPT N5, Kana, and foundational grammar with 100 AI queries. Pro unlocks N4 and N3 curriculum, 1,000 AI Sensei queries, official 180-mark mock exams, BaitoOS™ Tokyo convenience store simulations, and verifiable completion certificates.'
    },
    {
      question: 'What is included in the Japan Ready plan?',
      answer:
        'Japan Ready is specifically designed for students, engineers, and SSW/TITP professionals preparing to move to Japan. It includes unlimited AI mentorship, business Keigo, visa interview simulations, Japanese resume generation, and dedicated relocation guidance.'
    }
  ];

  const handlePlanAction = (planId: PlanId) => {
    if (onSelectPlan) {
      onSelectPlan(planId);
      return;
    }

    if (!user) {
      if (onNavigate) {
        onNavigate('auth');
      }
      return;
    }

    // Construct Plan object for checkout modal
    const target = plans.find((p) => p.id === planId);
    if (!target) return;

    const modalPlanPayload: Plan = {
      id: target.id,
      name: target.name,
      displayNameJa: target.nameJa,
      tagline: target.tagline,
      description: target.tagline,
      isPopular: target.isPopular,
      order: target.id === 'starter' ? 1 : target.id === 'pro' ? 2 : 3,
      monthlyPrice: target.monthlyPrice,
      yearlyPrice: target.annualBilledTotal,
      currency: 'BDT',
      aiMonthlyLimit: target.id === 'starter' ? 100 : target.id === 'pro' ? 1000 : 99999,
      features: target.features,
      entitlements: []
    };

    setSelectedPlanForCheckout(modalPlanPayload);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F9F9FB] text-stone-900 font-sans selection:bg-stone-900 selection:text-white antialiased">
      {/* Checkout Modal */}
      {selectedPlanForCheckout && (
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          selectedPlan={selectedPlanForCheckout}
          initialInterval={interval}
          onSuccess={() => {
            setIsCheckoutOpen(false);
            if (onNavigate) onNavigate('dashboard');
          }}
        />
      )}

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 sm:pt-24 sm:pb-32">
        {/* ========================================================================= */}
        {/* 1. HERO & TOGGLE SECTION                                                 */}
        {/* ========================================================================= */}
        <header className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <p className="text-xs sm:text-sm font-semibold tracking-wider text-stone-500 uppercase mb-3 font-mono">
            NIHOMI TUITION & CAREER ENROLLMENT
          </p>
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-stone-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-base sm:text-lg text-stone-500 max-w-xl mx-auto leading-relaxed">
            Investment in your Japan career &amp; JLPT mastery.
          </p>

          {/* Smooth Sliding Pill Toggle */}
          <div className="mt-8 sm:mt-10 inline-flex items-center justify-center p-1 bg-stone-200/60 rounded-full shadow-inner">
            <div className="relative flex items-center">
              {/* Monthly Button */}
              <button
                type="button"
                onClick={() => setInterval('monthly')}
                className={`relative z-10 px-5 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-medium transition-colors duration-200 cursor-pointer ${
                  interval === 'monthly' ? 'text-stone-900' : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Monthly
              </button>

              {/* Annual Button */}
              <button
                type="button"
                onClick={() => setInterval('yearly')}
                className={`relative z-10 px-5 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-medium transition-colors duration-200 cursor-pointer flex items-center space-x-1.5 ${
                  interval === 'yearly' ? 'text-stone-900' : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <span>Annual</span>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                  Save 20%
                </span>
              </button>

              {/* Sliding Active Pill Background */}
              <motion.div
                className="absolute top-0 bottom-0 rounded-full bg-white shadow-sm"
                initial={false}
                animate={{
                  left: interval === 'monthly' ? '0%' : '50%',
                  width: '50%'
                }}
                transition={{ type: 'spring', stiffness: 450, damping: 35 }}
              />
            </div>
          </div>
        </header>

        {/* ========================================================================= */}
        {/* 2. CORE PRICING TIERS (Strictly 3 Plans)                                 */}
        {/* ========================================================================= */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 items-stretch mb-16">
          {plans.map((plan) => {
            const isCurrent = activePlanId === plan.id;
            const displayPrice = interval === 'yearly' ? plan.annualMonthlyEquivalent : plan.monthlyPrice;

            return (
              <div
                key={plan.id}
                className={`relative flex flex-col justify-between rounded-3xl bg-white p-8 sm:p-9 transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_16px_40px_rgb(0,0,0,0.07)] ${
                  plan.isPopular
                    ? 'border-t-2 border-emerald-600 ring-1 ring-stone-900/5'
                    : 'border border-stone-200/50'
                }`}
              >
                {/* Popular Pill Badge */}
                {plan.isPopular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span className="inline-flex items-center space-x-1 px-3 py-1 rounded-full text-[11px] font-semibold tracking-wide bg-stone-900 text-white shadow-sm">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      <span>{plan.badge}</span>
                    </span>
                  </div>
                )}

                <div>
                  {/* Plan Header */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-stone-400 font-japanese">
                      {plan.nameJa}
                    </span>
                    {isCurrent && (
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                        Current Plan
                      </span>
                    )}
                  </div>

                  <h2 className="text-2xl font-medium tracking-tight text-stone-900">
                    {plan.name}
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-500 mt-1 min-h-[38px] leading-relaxed">
                    {plan.tagline}
                  </p>

                  {/* Price */}
                  <div className="mt-6 mb-6 pb-6 border-b border-stone-100">
                    <div className="flex items-baseline space-x-1">
                      <span className="text-4xl sm:text-5xl font-light tracking-tight text-stone-900">
                        ৳{displayPrice.toLocaleString()}
                      </span>
                      <span className="text-xs text-stone-400 font-medium">/ month</span>
                    </div>

                    {/* Billed info */}
                    <div className="mt-1 text-xs text-stone-400">
                      {interval === 'yearly' ? (
                        <span>Billed annually (৳{plan.annualBilledTotal.toLocaleString()}/yr)</span>
                      ) : (
                        <span>Billed monthly in BDT</span>
                      )}
                    </div>
                  </div>

                  {/* Key Features List */}
                  <div className="space-y-3 mb-8">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-stone-400">
                      Included with {plan.name}:
                    </p>
                    {plan.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-start space-x-3 text-xs sm:text-sm text-stone-600">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="leading-snug">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tactical CTA Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => handlePlanAction(plan.id)}
                    className={`w-full py-3.5 px-6 rounded-2xl text-xs sm:text-sm font-medium transition-all duration-150 cursor-pointer flex items-center justify-center space-x-2 active:scale-[0.98] ${
                      plan.isPopular
                        ? 'bg-stone-900 hover:bg-stone-800 text-white shadow-sm'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-900'
                    }`}
                  >
                    <span>{plan.ctaText}</span>
                    <ArrowRight className="w-3.5 h-3.5 opacity-70 group-hover:opacity-100" />
                  </button>
                </div>
              </div>
            );
          })}
        </section>

        {/* ========================================================================= */}
        {/* 3. TRUST & PAYMENT BAR (Muted / Grayscale Soft Minimalism)               */}
        {/* ========================================================================= */}
        <section className="mb-20 sm:mb-24 py-6 px-6 rounded-2xl bg-white/70 border border-stone-200/40 text-center max-w-4xl mx-auto shadow-[0_4px_20px_rgb(0,0,0,0.02)]">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-2 text-stone-600">
              <ShieldCheck className="w-4 h-4 text-stone-400" />
              <span className="text-xs sm:text-sm font-medium">100% Secure Payments in Bangladesh</span>
            </div>

            {/* Muted payment badges */}
            <div className="flex items-center space-x-4 sm:space-x-6 text-stone-400 text-xs font-mono tracking-wider">
              <span className="hover:text-stone-700 transition-colors">bKash</span>
              <span className="text-stone-300">•</span>
              <span className="hover:text-stone-700 transition-colors">Nagad</span>
              <span className="text-stone-300">•</span>
              <span className="hover:text-stone-700 transition-colors">SSLCommerz</span>
              <span className="text-stone-300">•</span>
              <span className="hover:text-stone-700 transition-colors">Visa / Mastercard</span>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 4. DETAILED FEATURE COMPARISON (Apple Style - No Vertical Borders)        */}
        {/* ========================================================================= */}
        <section className="mb-24 sm:mb-32">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <p className="text-xs font-semibold tracking-wider text-stone-400 uppercase mb-2 font-mono">
              SPECIFICATION MATRIX
            </p>
            <h2 className="text-2xl sm:text-4xl font-normal tracking-tight text-stone-900">
              Compare Features
            </h2>
            <p className="text-xs sm:text-sm text-stone-500 mt-2">
              Every curriculum entitlement and AI capability side-by-side.
            </p>
          </div>

          <div className="overflow-x-auto -mx-4 sm:mx-0">
            <div className="min-w-[620px] px-4 sm:px-0">
              <table className="w-full text-left border-collapse">
                {/* Header Row */}
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="py-4 pr-6 text-sm font-medium text-stone-400 w-2/5">
                      Platform Capability
                    </th>
                    <th className="py-4 px-4 text-center text-sm font-medium text-stone-900 w-1/5">
                      Starter
                    </th>
                    <th className="py-4 px-4 text-center text-sm font-medium text-emerald-800 w-1/5">
                      Pro
                    </th>
                    <th className="py-4 pl-4 text-center text-sm font-medium text-stone-900 w-1/5">
                      Japan Ready
                    </th>
                  </tr>
                </thead>

                {/* Table Body with Categorized Rows */}
                <tbody>
                  {comparisonCategories.map((group, gIdx) => (
                    <React.Fragment key={gIdx}>
                      {/* Category Header Row */}
                      <tr>
                        <td
                          colSpan={4}
                          className="pt-8 pb-3 text-xs font-semibold tracking-wider uppercase text-stone-400 font-mono"
                        >
                          {group.category}
                        </td>
                      </tr>

                      {/* Item Rows - Strict rule: NO vertical borders, ONLY border-b border-gray-100 */}
                      {group.rows.map((row, rIdx) => (
                        <tr
                          key={rIdx}
                          className="border-b border-gray-100 hover:bg-stone-50/50 transition-colors"
                        >
                          <td className="py-3.5 pr-6 text-xs sm:text-sm text-stone-700 font-normal">
                            {row.name}
                          </td>

                          {/* Starter */}
                          <td className="py-3.5 px-4 text-center text-xs sm:text-sm text-stone-600">
                            {typeof row.starter === 'boolean' ? (
                              row.starter ? (
                                <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                              ) : (
                                <Minus className="w-4 h-4 text-stone-300 mx-auto" />
                              )
                            ) : (
                              <span>{row.starter}</span>
                            )}
                          </td>

                          {/* Pro */}
                          <td className="py-3.5 px-4 text-center text-xs sm:text-sm font-medium text-stone-900">
                            {typeof row.pro === 'boolean' ? (
                              row.pro ? (
                                <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                              ) : (
                                <Minus className="w-4 h-4 text-stone-300 mx-auto" />
                              )
                            ) : (
                              <span>{row.pro}</span>
                            )}
                          </td>

                          {/* Japan Ready */}
                          <td className="py-3.5 pl-4 text-center text-xs sm:text-sm text-stone-600">
                            {typeof row.japanReady === 'boolean' ? (
                              row.japanReady ? (
                                <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                              ) : (
                                <Minus className="w-4 h-4 text-stone-300 mx-auto" />
                              )
                            ) : (
                              <span>{row.japanReady}</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 5. FAQ SECTION (Spaced 2x2 Grid, Faint Background, No Harsh Shadows)      */}
        {/* ========================================================================= */}
        <section className="mb-24 sm:mb-32 max-w-5xl mx-auto">
          <div className="text-center max-w-xl mx-auto mb-12 sm:mb-16">
            <p className="text-xs font-semibold tracking-wider text-stone-400 uppercase mb-2 font-mono">
              QUESTIONS & ANSWERS
            </p>
            <h2 className="text-2xl sm:text-4xl font-normal tracking-tight text-stone-900">
              Frequently Asked Questions
            </h2>
            <p className="text-xs sm:text-sm text-stone-500 mt-2">
              Common inquiries regarding payments, cancellations, and curriculum.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="p-6 sm:p-7 rounded-2xl bg-gray-50/80 border border-gray-100 transition-all"
              >
                <div className="flex items-start space-x-3 mb-2.5">
                  <HelpCircle className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                  <h3 className="text-sm sm:text-base font-medium text-stone-900">
                    {faq.question}
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-stone-500 leading-relaxed pl-7">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ========================================================================= */}
        {/* 6. MINIMAL FOOTER                                                        */}
        {/* ========================================================================= */}
        <footer className="pt-8 border-t border-stone-200/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400">
          {/* Left: Branding */}
          <div className="flex items-center space-x-2">
            <span className="font-medium text-stone-800">NIHOMI (ニホミ)</span>
            <span>•</span>
            <span>The Continuous Japanese Learning &amp; Relocation Platform</span>
          </div>

          {/* Right: Clean Links */}
          <nav className="flex items-center space-x-6 text-stone-500">
            <button
              onClick={() => onNavigate && onNavigate('privacy')}
              className="hover:text-stone-900 transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onNavigate && onNavigate('terms')}
              className="hover:text-stone-900 transition-colors cursor-pointer"
            >
              Terms of Service
            </button>
            <button
              onClick={() => onNavigate && onNavigate('refund-policy')}
              className="hover:text-stone-900 transition-colors cursor-pointer"
            >
              Refund Policy
            </button>
            <button
              onClick={() => onNavigate && onNavigate('contact')}
              className="hover:text-stone-900 transition-colors cursor-pointer"
            >
              Contact
            </button>
          </nav>
        </footer>
      </main>
    </div>
  );
};
