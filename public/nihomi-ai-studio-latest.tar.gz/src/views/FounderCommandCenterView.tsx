import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Sparkles,
  Target,
  Cpu,
  ShieldCheck,
  Coins,
  Database,
  Users,
  FileText,
  Lock,
  Crown,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiRequest } from '../lib/api';

import { FounderCockpitTab } from '../components/founder/FounderCockpitTab';
import { FounderAiCeoTab } from '../components/founder/FounderAiCeoTab';
import { FounderTargetsTab } from '../components/founder/FounderTargetsTab';
import { FounderAiOfficeTab } from '../components/founder/FounderAiOfficeTab';
import { FounderApprovalsTab } from '../components/founder/FounderApprovalsTab';
import { FounderBudgetTab } from '../components/founder/FounderBudgetTab';
import { FounderBrainTab } from '../components/founder/FounderBrainTab';
import { FounderAuditLogTab } from '../components/founder/FounderAuditLogTab';
import { FounderStudentsTab } from '../components/founder/FounderStudentsTab';

interface FounderCommandCenterViewProps {
  onNavigate: (view: string) => void;
}

export const FounderCommandCenterView: React.FC<FounderCommandCenterViewProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'cockpit' | 'ai-ceo' | 'targets' | 'ai-office' | 'approvals' | 'budget' | 'brain' | 'students' | 'audit'
  >('cockpit');

  const [cockpitData, setCockpitData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const isFounder = user?.email?.toLowerCase() === 'mdtanvirkabirbiplob@gmail.com';

  const fetchCockpitData = async () => {
    setIsLoading(true);
    try {
      const res = await apiRequest('/api/founder/cockpit');
      if (res.success) {
        setCockpitData(res);
      }
    } catch {
      // quiet fallback
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isFounder) {
      fetchCockpitData();
    }
  }, [isFounder]);

  if (!isFounder) {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white flex items-center justify-center p-6 text-center font-sans">
        <div className="max-w-md w-full bg-stone-900/90 border border-red-500/30 rounded-3xl p-8 space-y-6 shadow-2xl backdrop-blur-md">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center mx-auto text-red-400">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <div className="inline-block px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 text-xs font-mono font-bold">
              SECURITY RESTRICTION • 403 FORBIDDEN
            </div>
            <h2 className="text-xl font-black text-white">Founder Executive Authorization Required</h2>
            <p className="text-sm text-stone-400 leading-relaxed">
              This terminal is strictly isolated for the verified primary Founder identity (<span className="text-stone-300 font-mono text-xs">mdtanvirkabirbiplob@gmail.com</span>). Student and standard roles cannot access or execute cockpit commands.
            </p>
          </div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-red-600/20 cursor-pointer"
          >
            Return to Student Portal
          </button>
        </div>
      </div>
    );
  }

  const navTabs = [
    { id: 'cockpit', label: '1. Executive Cockpit', icon: LayoutDashboard },
    { id: 'ai-ceo', label: '2. AI CEO Desk', icon: Sparkles },
    { id: 'targets', label: '3. Strategic Objectives', icon: Target },
    { id: 'ai-office', label: '4. AI Office Status', icon: Cpu },
    { id: 'approvals', label: '5. Approval Queue', icon: ShieldCheck },
    { id: 'budget', label: '6. Budget Firewall', icon: Coins },
    { id: 'brain', label: '7. Company Brain', icon: Database },
    { id: 'students', label: '8. Student Roster', icon: Users },
    { id: 'audit', label: '9. Audit Logs', icon: FileText }
  ];

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-stone-900 font-sans antialiased text-left selection:bg-red-500 selection:text-white pb-24">
      {/* 1. TOP FOUNDER BAR */}
      <div className="bg-stone-950 text-white border-b border-stone-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-amber-500/20 text-amber-300 text-xs font-bold rounded-full border border-amber-500/30">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>FOUNDER EXECUTIVE HQ • GATE 2 ACTIVE</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Nihomi Global Command Center
            </h1>
            <p className="text-xs text-stone-400 font-mono">
              Lead Architect & Founder: MD Tanvir Kabir Biplob (mdtanvirkabirbiplob@gmail.com)
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onNavigate('dashboard')}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer border border-stone-700"
            >
              Switch to Student View
            </button>
            <button
              onClick={() => onNavigate('landing')}
              className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-950 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Public Website →
            </button>
          </div>
        </div>
      </div>

      {/* 2. SUB-NAVIGATION TABS */}
      <div className="bg-white border-b border-stone-200/80 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-2 sm:space-x-3 h-14 overflow-x-auto no-scrollbar items-center">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center space-x-1.5 shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-stone-950 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-950 hover:bg-stone-100'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. MAIN CONTENT CONTAINER */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {activeTab === 'cockpit' && (
          <FounderCockpitTab
            businessOverview={cockpitData?.businessOverview}
            activeObjective={cockpitData?.activeObjective}
            telemetry={cockpitData?.telemetry}
            onNavigateTab={(tabId) => setActiveTab(tabId as any)}
            onRefresh={fetchCockpitData}
          />
        )}

        {activeTab === 'ai-ceo' && <FounderAiCeoTab />}

        {activeTab === 'targets' && <FounderTargetsTab />}

        {activeTab === 'ai-office' && <FounderAiOfficeTab />}

        {activeTab === 'approvals' && <FounderApprovalsTab />}

        {activeTab === 'budget' && <FounderBudgetTab />}

        {activeTab === 'brain' && <FounderBrainTab />}

        {activeTab === 'students' && <FounderStudentsTab />}

        {activeTab === 'audit' && <FounderAuditLogTab />}
      </div>
    </div>
  );
};
