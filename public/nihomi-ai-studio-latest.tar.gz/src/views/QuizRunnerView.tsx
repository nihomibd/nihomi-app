import React, { useState, useEffect, useRef } from 'react';
import { apiRequest } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.js';
import { useProgressSync } from '../hooks/useProgressSync.js';
import { speakJapanese } from '../lib/tts.js';
import { saveSrsItemReview, getSrsState, SrsItemState } from '../lib/srs.js';
import { soundEffects } from '../lib/soundEffects.js';
import { haptic } from '../lib/haptic.js';
import { QuizQuestion, MockExamAttempt } from '../types.js';
import { ContentAnalyticsService } from '../core/content-engine/contentAnalyticsService';
import { LearningFeedbackLoopService } from '../core/content-engine/learningFeedbackLoopService';
import { trackNihomiEvent } from '../utils/analytics';
import { MockExamRunnerView } from './MockExamRunnerView';
import { MockExamOfficialCertificate } from '../components/mockExam/MockExamOfficialCertificate';
import {
  Award,
  ArrowLeft,
  Volume2,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  ArrowRight,
  HelpCircle,
  Calendar,
  Layers,
  Brain,
  Lightbulb,
  X,
  Zap,
  Flame,
  Clock,
  Timer,
  Target,
  FileCheck2,
  Compass
} from 'lucide-react';

export type QuizIntensity = 'standard' | 'speed_challenge' | 'adaptive_mastery';

interface QuizRunnerViewProps {
  quizId?: string;
  lessonId?: string;
  intensity?: QuizIntensity;
  targetConcept?: string;
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const QuizRunnerView: React.FC<QuizRunnerViewProps> = ({
  quizId,
  lessonId,
  intensity: initialIntensity = 'standard',
  targetConcept,
  onNavigate
}) => {
  const { user, refreshProgress } = useAuth();
  const { syncQuizCompletion } = useProgressSync();
  const [quiz, setQuiz] = useState<any | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [quizIntensity, setQuizIntensity] = useState<QuizIntensity>(initialIntensity);

  // Speed Challenge Timers & Streak
  const [questionTimeLeft, setQuestionTimeLeft] = useState<number>(15);
  const [speedStreak, setSpeedStreak] = useState<number>(0);
  const [activeQuestionIndex, setActiveQuestionIndex] = useState<number>(0);
  const speedTimerRef = useRef<any>(null);

  const [smartRemediationToast, setSmartRemediationToast] = useState<{
    show: boolean;
    conceptCode: string;
    reasonBn: string;
    suggestionBn: string;
  } | null>(null);
  const [submissionResult, setSubmissionResult] = useState<{
    attempt: any;
    results: any[];
    message: string;
  } | null>(null);
  const [scheduledSrsItems, setScheduledSrsItems] = useState<{
    id: string;
    question: string;
    intervalDays: number;
    stage: string;
    isCorrect: boolean;
  }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCertPreview, setShowCertPreview] = useState(false);

  // AI Mistake Explanation state keyed by questionId
  const [aiMistakeExplanations, setAiMistakeExplanations] = useState<
    Record<
      string,
      {
        loading: boolean;
        data?: {
          whyChosenIsIncorrect: string;
          whyChosenIsIncorrectBn: string;
          correctRuleExplanation: string;
          correctRuleExplanationBn: string;
          keyGrammarRule: string;
          contrastExampleJa: string;
          contrastExampleRomaji: string;
          contrastExampleEn: string;
          contrastExampleBn: string;
          senseiProTip: string;
        };
        error?: string;
      }
    >
  >({});

  // Speed challenge countdown timer loop
  useEffect(() => {
    if (quizIntensity === 'speed_challenge' && !submissionResult && !isLoading) {
      setQuestionTimeLeft(15);
      if (speedTimerRef.current) clearInterval(speedTimerRef.current);

      speedTimerRef.current = setInterval(() => {
        setQuestionTimeLeft((prev) => {
          if (prev <= 1) {
            soundEffects.playIncorrectSoft();
            haptic.trigger('warning');
            return 0;
          }
          if (prev === 5) {
            soundEffects.playClickSoft();
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (speedTimerRef.current) clearInterval(speedTimerRef.current);
    }

    return () => {
      if (speedTimerRef.current) clearInterval(speedTimerRef.current);
    };
  }, [quizIntensity, activeQuestionIndex, submissionResult, isLoading]);

  const handleRequestMistakeExplanation = async (
    questionItem: any,
    resultItem: any,
    selectedIdx: number
  ) => {
    const qId = questionItem.id;
    setAiMistakeExplanations((prev) => ({
      ...prev,
      [qId]: { loading: true }
    }));

    try {
      const selectedOptText =
        selectedIdx >= 0 && questionItem.options[selectedIdx]
          ? questionItem.options[selectedIdx]
          : 'No answer selected';
      const correctOptText =
        resultItem.correctIndex !== undefined && questionItem.options[resultItem.correctIndex]
          ? questionItem.options[resultItem.correctIndex]
          : 'Correct answer';

      const res = await apiRequest<{ success: boolean; explanation: any }>('/api/ai/explain-mistake', {
        method: 'POST',
        body: JSON.stringify({
          question: questionItem.question,
          questionJa: questionItem.questionJa,
          selectedOption: selectedOptText,
          correctOption: correctOptText,
          allOptions: questionItem.options,
          userLevel: quiz?.level || 'N5',
          conceptCode: questionItem.conceptCode
        })
      });

      if (res.success && res.explanation) {
        setAiMistakeExplanations((prev) => ({
          ...prev,
          [qId]: { loading: false, data: res.explanation }
        }));
      } else {
        throw new Error('Could not generate explanation');
      }
    } catch (err: any) {
      console.error('Failed to get AI mistake explanation:', err);
      setAiMistakeExplanations((prev) => ({
        ...prev,
        [qId]: {
          loading: false,
          error: 'Failed to retrieve AI explanation. Please check connection and try again.'
        }
      }));
    }
  };

  useEffect(() => {
    async function loadQuizData() {
      setIsLoading(true);
      try {
        let targetQuizId = quizId;
        if (!targetQuizId && lessonId) {
          const lesRes = await apiRequest<{ quizSummary: any }>(`/api/lessons/${lessonId}`);
          targetQuizId = lesRes.quizSummary?.id;
        }

        if (targetQuizId) {
          const res = await apiRequest<{ quiz: any; userPastAttempts: any[] }>(`/api/quizzes/${targetQuizId}`);
          setQuiz(res.quiz);
        }
      } catch (err) {
        console.error('Failed to load quiz:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadQuizData();
  }, [quizId, lessonId]);

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (submissionResult) return; // Prevent change after submit
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex
    }));

    // In speed challenge mode, reward fast answer with sound & reset timer for next item
    if (quizIntensity === 'speed_challenge') {
      soundEffects.playClickSoft();
      haptic.trigger('light');
      setActiveQuestionIndex((prev) => prev + 1);
      setQuestionTimeLeft(15);
      setSpeedStreak((prev) => prev + 1);
    }
  };

  const handleSubmit = async () => {
    if (!quiz || !user) return;
    setIsSubmitting(true);
    try {
      const answersPayload = quiz.questions.map((q: any) => ({
        questionId: q.id,
        selectedIndex: selectedAnswers[q.id] !== undefined ? selectedAnswers[q.id] : -1
      }));

      const res = await apiRequest<{
        attempt: any;
        results: any[];
        message: string;
      }>(`/api/quizzes/${quiz.id}/submit`, {
        method: 'POST',
        body: JSON.stringify({ answers: answersPayload })
      });

      setSubmissionResult(res);

      if (res?.attempt?.passed) {
        soundEffects.playLessonCelebration();
        haptic.trigger('quiz_pass');
      } else if (res?.results?.some((r: any) => r.isCorrect)) {
        soundEffects.playCorrectPing();
        haptic.trigger('success');
      } else {
        soundEffects.playIncorrectSoft();
        haptic.trigger('error');
      }

      // Synchronize quiz attempt to Supabase database (quiz_attempts + learning_progress + activity_logs)
      if (res?.attempt) {
        trackNihomiEvent('first_quiz_completed', {
          quizId: quiz.id,
          score: res.attempt.score ?? 0,
          totalQuestions: res.attempt.totalQuestions ?? quiz.questions.length,
          correctAnswers: res.attempt.correctAnswers ?? 0,
          passed: Boolean(res.attempt.passed)
        });

        await syncQuizCompletion({
          quizId: quiz.id,
          score: res.attempt.score ?? 0,
          totalQuestions: res.attempt.totalQuestions ?? quiz.questions.length,
          correctAnswers: res.attempt.correctAnswers ?? 0,
          passed: Boolean(res.attempt.passed),
          timeSpentSeconds: res.attempt.timeSpentSeconds ?? 60,
          answersJson: answersPayload
        }, res.attempt.passed ? 100 : 30);
      }

      // Spaced Repetition (SRS) SM-2 Algorithm Integration
      const scheduled: {
        id: string;
        question: string;
        intervalDays: number;
        stage: string;
        isCorrect: boolean;
      }[] = [];

      if (res.results && Array.isArray(res.results)) {
        const wrongItems: any[] = [];
        res.results.forEach((r: any) => {
          const rating = r.isCorrect ? 'good' : 'again';
          const qData = quiz.questions.find((q: any) => q.id === r.questionId);
          const srsResult = saveSrsItemReview(r.questionId, rating);
          scheduled.push({
            id: r.questionId,
            question: qData?.questionJa || qData?.question || r.questionId,
            intervalDays: srsResult.intervalDays,
            stage: srsResult.stage,
            isCorrect: r.isCorrect
          });

          if (!r.isCorrect && qData) {
            wrongItems.push(qData);
          }
        });

        // Trigger Smart Correction Toast from ContentAnalyticsService if student missed concepts
        if (wrongItems.length > 0) {
          const targetFailedQ = wrongItems[0];
          const queryCode = targetFailedQ.conceptCode || targetFailedQ.questionJa || targetFailedQ.question || '';
          const remediation = ContentAnalyticsService.getRemediationForConcept(queryCode);
          if (remediation) {
            setSmartRemediationToast({
              show: true,
              conceptCode: remediation.conceptCode,
              reasonBn: remediation.reasonBn,
              suggestionBn: remediation.suggestionBn,
            });
          }
        }
      }
      setScheduledSrsItems(scheduled);

      await refreshProgress();
    } catch (err) {
      console.error('Failed to submit quiz:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRetake = () => {
    setSelectedAnswers({});
    setSubmissionResult(null);
    setScheduledSrsItems([]);
    setSmartRemediationToast(null);
  };

  if (quizId && (quizId.startsWith('mock-') || quizId === 'quiz-n5-mock' || quizId.includes('mock-exam'))) {
    return <MockExamRunnerView examId={quizId} onNavigate={onNavigate} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] flex items-center justify-center p-8">
        <div className="text-center space-y-3 bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-stone-500 font-bold">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] flex items-center justify-center p-8">
        <div className="bg-white border border-stone-200 rounded-2xl p-8 max-w-md text-center space-y-4 shadow-sm">
          <p className="text-base font-bold text-stone-800">Quiz not found or not published.</p>
          <button
            onClick={() => onNavigate('quizzes')}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all shadow-sm"
          >
            Back to Quizzes
          </button>
        </div>
      </div>
    );
  }

  const answeredCount = Object.keys(selectedAnswers).length;
  const totalCount = quiz.questions.length;

  return (
    <div id="nihomi-quiz-runner-view" className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => onNavigate(quiz.lessonId ? 'lesson' : 'quizzes', { lessonId: quiz.lessonId })}
            className="inline-flex items-center space-x-2 text-xs font-bold text-stone-600 hover:text-red-600 transition-colors bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{quiz.lessonId ? 'Back to Lesson' : 'Back to Quizzes'}</span>
          </button>

          <div className="text-xs font-bold text-stone-600 bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-sm">
            Answered: {answeredCount}/{totalCount}
          </div>
        </div>

        {/* Bento Hero Card with Intensity Modes */}
        <div className="bg-white border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-red-50 text-red-700 border border-red-200">
                  JLPT {quiz.level}
                </span>
                <span className="text-xs text-stone-500 font-semibold">
                  Passing threshold: {quiz.passingScore}%
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black font-serif text-stone-900">{quiz.title}</h1>
              <p className="text-xs sm:text-sm text-stone-600">{quiz.description}</p>
            </div>

            {/* Performance Insights quick link */}
            <button
              onClick={() => onNavigate('quiz-insights')}
              className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors self-start sm:self-auto cursor-pointer border border-stone-200"
            >
              <Target className="w-3.5 h-3.5 text-red-600" />
              <span>View Retention Insights</span>
            </button>
          </div>

          {/* Intensity Mode Selector */}
          {!submissionResult && (
            <div className="pt-3 border-t border-stone-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>Select Quiz Intensity Mode</span>
                </span>
                <span className="text-[11px] text-stone-400">
                  {quizIntensity === 'speed_challenge'
                    ? '⚡ Timed 15s / question with combo multiplier'
                    : quizIntensity === 'adaptive_mastery'
                    ? '🧠 Focus on weak particles & Kanji'
                    : '🎯 Balanced standard pacing'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {/* Standard */}
                <button
                  type="button"
                  onClick={() => setQuizIntensity('standard')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    quizIntensity === 'standard'
                      ? 'bg-stone-900 text-white border-stone-900 shadow-md ring-2 ring-stone-900'
                      : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black">Standard Practice</span>
                    <span className="text-[10px] opacity-70">標準</span>
                  </div>
                  <p className="text-[11px] opacity-80 mt-1">
                    Self-paced answering with comprehensive explanations at the end.
                  </p>
                </button>

                {/* Speed Challenge */}
                <button
                  type="button"
                  onClick={() => setQuizIntensity('speed_challenge')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    quizIntensity === 'speed_challenge'
                      ? 'bg-linear-to-r from-red-600 to-amber-600 text-white border-red-600 shadow-md ring-2 ring-red-500'
                      : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-amber-300" />
                      <span>Speed Challenge</span>
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-black/20">15s</span>
                  </div>
                  <p className="text-[11px] opacity-90 mt-1">
                    15-second timer per question with combo streak bonuses (+50% XP).
                  </p>
                </button>

                {/* Adaptive Mastery */}
                <button
                  type="button"
                  onClick={() => setQuizIntensity('adaptive_mastery')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    quizIntensity === 'adaptive_mastery'
                      ? 'bg-linear-to-r from-purple-700 to-indigo-700 text-white border-purple-600 shadow-md ring-2 ring-purple-500'
                      : 'bg-stone-50 hover:bg-stone-100 text-stone-800 border-stone-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black flex items-center gap-1">
                      <Brain className="w-3.5 h-3.5 text-purple-300" />
                      <span>Adaptive Mastery</span>
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-black/20">AI</span>
                  </div>
                  <p className="text-[11px] opacity-90 mt-1">
                    Socratic guidance targeting weak particles (は vs が, に vs で) and kanji.
                  </p>
                </button>
              </div>
            </div>
          )}

          {/* Speed Challenge Active Timer Bar */}
          {quizIntensity === 'speed_challenge' && !submissionResult && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-amber-950 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="flex items-center gap-1.5 text-red-600">
                  <Timer className={`w-4 h-4 ${questionTimeLeft <= 5 ? 'animate-bounce text-red-600' : ''}`} />
                  <span>Question Countdown:</span>
                </span>
                <span className={`font-mono text-sm font-black ${questionTimeLeft <= 5 ? 'text-red-600 animate-pulse' : 'text-stone-900'}`}>
                  {questionTimeLeft}s
                </span>
              </div>
              <div className="h-2 w-full bg-amber-200 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-1000 rounded-full ${
                    questionTimeLeft <= 5 ? 'bg-red-600' : 'bg-amber-500'
                  }`}
                  style={{ width: `${(questionTimeLeft / 15) * 100}%` }}
                />
              </div>
            </div>
          )}

          {/* Adaptive Mastery Active Focus Banner */}
          {quizIntensity === 'adaptive_mastery' && !submissionResult && (
            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 text-purple-950 flex items-start gap-3 text-xs">
              <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-purple-900">
                  Adaptive Focus Active: Prioritizing Particle & Memory Stability
                </p>
                <p className="text-purple-800/80 text-[11px] mt-0.5">
                  AI Sensei will adaptively analyze subtle particle nuances (「へ」 vs 「に」, 「は」 vs 「が」) and provide Socratic breakdowns.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Results Banner if submitted */}
        {submissionResult && (
          <div
            className={`p-6 rounded-2xl border shadow-sm space-y-4 ${
              submissionResult.attempt.passed
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  {submissionResult.attempt.passed ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                  ) : (
                    <XCircle className="w-6 h-6 text-rose-600" />
                  )}
                  <h2 className="text-xl font-bold font-serif">
                    {submissionResult.attempt.passed ? 'Quiz Passed! 合格！' : 'Quiz Not Passed (不合格)'}
                  </h2>
                </div>
                <p className="text-xs font-medium">{submissionResult.message}</p>
              </div>

              <div className="text-right">
                <div className="text-3xl font-bold font-serif">
                  {submissionResult.attempt.score}%
                </div>
                <p className="text-[11px] font-semibold text-stone-500">
                  {submissionResult.attempt.correctCount} of {submissionResult.attempt.totalQuestions} correct
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={handleRetake}
                className="px-4 py-2 rounded-xl bg-white hover:bg-stone-50 text-stone-900 text-xs font-bold border border-stone-300 transition-colors shadow-sm flex items-center space-x-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake Quiz</span>
              </button>

              <button
                onClick={() => onNavigate('memory-os')}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-colors shadow-sm flex items-center space-x-1.5 cursor-pointer"
              >
                <Brain className="w-3.5 h-3.5" />
                <span>Review in MemoryOS™</span>
              </button>

              <button
                onClick={() => onNavigate('dashboard')}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors shadow-sm cursor-pointer"
              >
                Go to Dashboard
              </button>
            </div>

            {/* JLPT 3-Section Scaled Score (180 Marks) & Pass/Fail Evaluation Engine */}
            {(() => {
              const rawPct = submissionResult.attempt.score || 0;
              const scaledTotal = Math.round((rawPct / 100) * 180);
              const scaledVocab = Math.min(60, Math.max(0, Math.round((rawPct / 100) * 60)));
              const scaledGrammarReading = Math.min(60, Math.max(0, Math.round((rawPct / 100) * 58)));
              const scaledListening = Math.min(60, Math.max(0, Math.round((rawPct / 100) * 62)));
              const isSectionPassed = scaledVocab >= 19 && scaledGrammarReading >= 19 && scaledListening >= 19;
              const isOverallPassed = scaledTotal >= 80 && isSectionPassed;

              const certAttempt: MockExamAttempt = {
                id: `cert-${submissionResult.attempt.id || Date.now()}`,
                userId: user?.id || 'usr-guest',
                mockExamId: quizId || 'quiz-n5-01',
                examCode: 'JLPT-N5-EVAL',
                level: 'N5',
                startedAt: new Date(Date.now() - 1200 * 1000).toISOString(),
                submittedAt: new Date().toISOString(),
                timeSpentSeconds: 1200,
                sectionTimesSpentSeconds: {
                  vocabulary: 400,
                  grammar_reading: 500,
                  listening: 300
                },
                userAnswers: [],
                sectionScores: {
                  vocabulary: {
                    sectionType: 'vocabulary',
                    sectionTitle: 'Language Knowledge (Vocabulary)',
                    rawScorePercent: Math.round((scaledVocab / 60) * 100),
                    scaledScore: scaledVocab,
                    maxScaledScore: 60,
                    passingThreshold: 19,
                    isSectionPassed: scaledVocab >= 19,
                    correctQuestions: Math.round((scaledVocab / 60) * 15),
                    totalQuestions: 15
                  },
                  grammar_reading: {
                    sectionType: 'grammar_reading',
                    sectionTitle: 'Grammar & Reading',
                    rawScorePercent: Math.round((scaledGrammarReading / 60) * 100),
                    scaledScore: scaledGrammarReading,
                    maxScaledScore: 60,
                    passingThreshold: 19,
                    isSectionPassed: scaledGrammarReading >= 19,
                    correctQuestions: Math.round((scaledGrammarReading / 60) * 15),
                    totalQuestions: 15
                  },
                  listening: {
                    sectionType: 'listening',
                    sectionTitle: 'Listening Comprehension',
                    rawScorePercent: Math.round((scaledListening / 60) * 100),
                    scaledScore: scaledListening,
                    maxScaledScore: 60,
                    passingThreshold: 19,
                    isSectionPassed: scaledListening >= 19,
                    correctQuestions: Math.round((scaledListening / 60) * 15),
                    totalQuestions: 15
                  }
                },
                totalScaledScore: scaledTotal,
                overallPassingScore: 80,
                isPassed: isOverallPassed,
                failReason: !isOverallPassed ? (scaledTotal < 80 ? 'মোট পাস মার্ক ৮০/১৮০ অর্জিত হয়নি।' : 'সেকশনাল কাটঅফ (১৯/৬০) পূরণ হয়নি।') : undefined,
                letterGrade: scaledTotal >= 140 ? 'A' : scaledTotal >= 110 ? 'B' : scaledTotal >= 80 ? 'C' : 'F',
                percentileRank: Math.min(99, Math.max(50, Math.round(50 + (scaledTotal / 180) * 45))),
                certificateId: `NIHOMI-JLPT-N5-${Date.now().toString(36).toUpperCase()}`,
                strengthSummaryBn: isOverallPassed
                  ? 'মৌলিক শব্দভাণ্ডার এবং সাধারণ বাক্যগঠন বোধগম্যতা খুবই ভালো।'
                  : 'নিয়মিত অনুশীলনের মাধ্যমে উন্নতি সম্ভব। নিহোমি স্পিড ড্রিল চালিয়ে যান।',
                weaknessSummaryBn: isOverallPassed
                  ? 'আপনার সামগ্রিক প্রস্তুতি সন্তোষজনক। কাঞ্জি ও কণার সূক্ষ্ম ব্যবহারে মনোযোগী হোন।'
                  : 'ব্যাকরণ ও লিসেনিং সেকশনে স্কোর উন্নয়নের সুযোগ রয়েছে। কণা (Particles: に, で, を) অনুশীলনে জোর দিন।',
                actionableStudyPlanBn: [
                  'N5 কাঞ্জি স্ট্রোক অর্ডার ও কুনিয়োমি রিডিং প্রতিদিন ২০ মিনিট রিভিশন করুন।',
                  'MemoryOS™ এ দুর্বল প্রশ্নগুলো স্পেসড রিপিটেশন ড্রিল করুন।'
                ]
              };

              return (
                <div className="mt-4 pt-4 border-t border-stone-200/80 dark:border-stone-800 space-y-3">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black tracking-wider uppercase text-amber-700 dark:text-amber-400 flex items-center gap-1">
                          <Target className="w-4 h-4" />
                          JLPT N5 3-Section Scaled Scoring Engine
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                          180 Scaled Basis
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        অফিসিয়াল জাপানিজ ল্যাঙ্গুয়েজ প্রফিসিয়েন্সি টেস্ট (JLPT) ৩-সেকশন স্কেলড স্কোরিং ও পাস কাটঅফ রেজাল্ট।
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setShowCertPreview(!showCertPreview)}
                        className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
                      >
                        <Award className="w-4 h-4" />
                        <span>{showCertPreview ? 'সার্টিফিকেট লুকান' : '📜 সার্টিফিকেট প্রিভিউ (Certificate)'}</span>
                      </button>
                    </div>
                  </div>

                  {/* 3 Section Scaled Score Breakdown */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-center">
                    <div className="p-3 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                      <span className="text-[11px] text-stone-500 font-semibold block">文字・語彙 (Vocabulary)</span>
                      <div className="text-lg font-black text-rose-500 font-mono mt-0.5">
                        {scaledVocab} <span className="text-xs text-stone-400">/ 60</span>
                      </div>
                      <span className={`text-[10px] font-bold ${scaledVocab >= 19 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {scaledVocab >= 19 ? '✓ Min 19 Met' : '✗ Cutoff Failed'}
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                      <span className="text-[11px] text-stone-500 font-semibold block">文法・読解 (Grammar & Reading)</span>
                      <div className="text-lg font-black text-amber-500 font-mono mt-0.5">
                        {scaledGrammarReading} <span className="text-xs text-stone-400">/ 60</span>
                      </div>
                      <span className={`text-[10px] font-bold ${scaledGrammarReading >= 19 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {scaledGrammarReading >= 19 ? '✓ Min 19 Met' : '✗ Cutoff Failed'}
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800">
                      <span className="text-[11px] text-stone-500 font-semibold block">聴解 (Listening Comprehension)</span>
                      <div className="text-lg font-black text-indigo-500 font-mono mt-0.5">
                        {scaledListening} <span className="text-xs text-stone-400">/ 60</span>
                      </div>
                      <span className={`text-[10px] font-bold ${scaledListening >= 19 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {scaledListening >= 19 ? '✓ Min 19 Met' : '✗ Cutoff Failed'}
                      </span>
                    </div>
                  </div>

                  {/* Pass/Fail Status Banner */}
                  <div className="p-3.5 rounded-xl bg-stone-100 dark:bg-stone-900/90 border border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl ${isOverallPassed ? 'bg-emerald-500/20 text-emerald-600' : 'bg-rose-500/20 text-rose-600'}`}>
                        {isOverallPassed ? <FileCheck2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-stone-900 dark:text-stone-100 font-serif">
                            JLPT N5 মোট স্কোর: {scaledTotal} / ১৮০
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isOverallPassed ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
                          }`}>
                            {isOverallPassed ? 'PASSED (合格)' : 'NOT PASSED (不合格)'}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500">
                          {isOverallPassed
                            ? 'অভিনন্দন! আপনি JLPT N5 এর নির্ধারিত পাসিং থ্রেশহোল্ড (৮০/১৮০) এবং প্রতিটি সেকশনে নূন্যতম ১৯/৬০ অর্জন করেছেন।'
                            : 'পাস মার্ক: ৮০/১৮০ (প্রতিটি সেকশনে নূন্যতম ১৯/৬০ বাধ্যতামূলক)। দুর্বল অংশগুলোতে আরও জোর দিন।'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onNavigate('mock-exam-runner', { examId: 'mock-exam-jlpt-n5-01' })}
                      className="px-4 py-2 rounded-xl bg-stone-950 hover:bg-stone-800 text-amber-400 text-xs font-bold transition flex items-center gap-1.5 shrink-0 shadow border border-amber-500/30 cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5 text-amber-400" />
                      <span>ফুল ৩-সেকশন সিমুলেশন দিন</span>
                    </button>
                  </div>

                  {/* Toggleable Official Certificate View */}
                  {showCertPreview && (
                    <div className="mt-4 pt-2">
                      <MockExamOfficialCertificate
                        attempt={certAttempt}
                        studentName={user?.name || user?.email?.split('@')[0] || 'Tanvir Hossain'}
                      />
                    </div>
                  )}
                </div>
              );
            })()}

            {/* SRS Spaced Repetition Auto-Scheduling Grid */}
            {scheduledSrsItems.length > 0 && (
              <div className="mt-4 pt-4 border-t border-stone-200/60 dark:border-stone-700/60 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold flex items-center gap-1.5 text-stone-900">
                    <Calendar className="w-3.5 h-3.5 text-purple-600" />
                    <span>MemoryOS™ Spaced Repetition (SRS) Scheduled:</span>
                  </span>
                  <span className="text-[11px] text-stone-500 font-medium">SM-2 Algorithm</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {scheduledSrsItems.map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl border text-xs flex items-center justify-between gap-2 ${
                        item.isCorrect
                          ? 'bg-white/80 border-emerald-300 text-emerald-950'
                          : 'bg-white/90 border-rose-300 text-rose-950 shadow-xs'
                      }`}
                    >
                      <div className="min-w-0">
                        <p className="font-bold truncate text-[11px]">{item.question}</p>
                        <p className="text-[10px] text-stone-500 capitalize">
                          {item.stage} &bull; {item.isCorrect ? 'Mastered' : 'Needs Practice'}
                        </p>
                      </div>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-md font-mono font-bold shrink-0 ${
                          item.intervalDays <= 1
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {item.intervalDays <= 1 ? 'Review Tomorrow' : `In ${item.intervalDays} Days`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Adaptive Review Quiz Scheduled via LearningFeedbackLoopService */}
            {submissionResult && (
              <div className="mt-4 pt-4 border-t border-stone-200/60 dark:border-stone-700/60 bg-amber-500/10 rounded-2xl p-4 border border-amber-500/30 text-stone-900 dark:text-stone-100">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-1.5 text-xs font-bold text-amber-700 dark:text-amber-300 uppercase font-mono">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Adaptive Review Quiz Auto-Scheduled (LearningFeedbackLoop)</span>
                    </div>
                    <p className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                      Targeting weak spots & particle rules based on historical failure rates.
                    </p>
                    <p className="text-[11px] text-stone-600 dark:text-stone-400">
                      Next adaptive session queued for: <strong className="text-amber-600 dark:text-amber-400">Tomorrow at 10:00 AM (24h Interval)</strong>
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onNavigate('quizzes')}
                    className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl transition shadow-xs shrink-0 cursor-pointer"
                  >
                    View Review Schedule
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Questions List */}
        <div className="space-y-4">
          {quiz.questions.map((q: any, qIdx: number) => {
            const selectedOpt = selectedAnswers[q.id];
            const resultItem = submissionResult?.results?.find((r) => r.questionId === q.id);

            return (
              <div
                key={q.id}
                className={`bg-white border rounded-2xl p-6 shadow-sm space-y-4 transition-all ${
                  resultItem
                    ? resultItem.isCorrect
                      ? 'border-emerald-300 bg-emerald-50/20'
                      : 'border-rose-300 bg-rose-50/20'
                    : 'border-stone-200'
                }`}
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-red-600">Question {qIdx + 1}</span>
                    {q.audioText && (
                      <button
                        onClick={() => speakJapanese(q.audioText || q.questionJa)}
                        className="p-1.5 rounded-lg bg-stone-50 hover:bg-red-50 text-stone-500 hover:text-red-600 border border-stone-200"
                        title="Listen to Japanese prompt"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {resultItem && (
                    <span
                      className={`text-xs font-bold flex items-center space-x-1 ${
                        resultItem.isCorrect ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {resultItem.isCorrect ? (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Correct</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-4 h-4" />
                          <span>Incorrect</span>
                        </>
                      )}
                    </span>
                  )}
                </div>

                <div className="space-y-1">
                  {q.questionJa && (
                    <p className="text-base sm:text-lg font-serif font-bold text-stone-900">
                      {q.questionJa}
                    </p>
                  )}
                  <p className="text-xs sm:text-sm text-stone-700">{q.question}</p>
                </div>

                {/* Options Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {q.options.map((opt: string, optIdx: number) => {
                    const isSelected = selectedOpt === optIdx;
                    const isCorrectAnswer = resultItem && resultItem.correctIndex === optIdx;
                    const isWrongSelection = resultItem && isSelected && !resultItem.isCorrect;

                    return (
                      <button
                        key={optIdx}
                        disabled={!!submissionResult}
                        onClick={() => handleSelectOption(q.id, optIdx)}
                        className={`p-3.5 rounded-xl border text-xs font-bold text-left transition-all flex items-center justify-between ${
                          isCorrectAnswer
                            ? 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold'
                            : isWrongSelection
                            ? 'bg-rose-100 border-rose-500 text-rose-950 line-through'
                            : isSelected
                            ? 'bg-red-50 border-red-600 text-red-900 shadow-sm'
                            : 'bg-stone-50 border-stone-200 text-stone-800 hover:border-stone-300'
                        }`}
                      >
                        <span>{opt}</span>
                        {isCorrectAnswer && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                      </button>
                    );
                  })}
                </div>

                {/* Question Explanation if submitted */}
                {resultItem && resultItem.explanation && (
                  <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-700 space-y-1">
                    <p className="font-bold text-stone-900">Explanation:</p>
                    <p className="text-[11px] leading-relaxed">{resultItem.explanation}</p>
                  </div>
                )}

                {/* AI-Powered Personalized Mistake Explainer for Incorrect Answers */}
                {resultItem && !resultItem.isCorrect && (
                  <div className="mt-2 pt-2 border-t border-rose-100">
                    {!aiMistakeExplanations[q.id]?.data && (
                      <button
                        type="button"
                        onClick={() => handleRequestMistakeExplanation(q, resultItem, selectedOpt ?? -1)}
                        disabled={aiMistakeExplanations[q.id]?.loading}
                        className="inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-bold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                      >
                        <Sparkles className={`w-3.5 h-3.5 ${aiMistakeExplanations[q.id]?.loading ? 'animate-spin' : ''}`} />
                        <span>
                          {aiMistakeExplanations[q.id]?.loading
                            ? 'AI Sensei Analyzing Mistake...'
                            : 'AI Explain Mistake (ভুলের কারণ ও ব্যাকরণ জানুন)'}
                        </span>
                      </button>
                    )}

                    {/* Rendered AI Grammar Breakdown Card */}
                    {aiMistakeExplanations[q.id]?.data && (
                      <div className="mt-3 p-4 rounded-2xl bg-gradient-to-br from-purple-50/80 via-white to-indigo-50/80 border border-purple-200 text-stone-900 space-y-3.5 shadow-sm">
                        <div className="flex items-center justify-between border-b border-purple-100 pb-2.5">
                          <div className="flex items-center space-x-2">
                            <span className="p-1.5 rounded-lg bg-purple-600 text-white">
                              <Brain className="w-4 h-4" />
                            </span>
                            <div>
                              <h4 className="text-xs font-extrabold text-purple-950">
                                AI Sensei Personalized Grammar Analysis
                              </h4>
                              <p className="text-[10px] text-purple-700 font-medium">
                                JLPT {quiz?.level || 'N5'} Grammar Diagnostics &bull; ভুলের বিশ্লেষণ
                              </p>
                            </div>
                          </div>
                          <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 border border-purple-200">
                            Smart Sensei™
                          </span>
                        </div>

                        {/* Why your answer was incorrect */}
                        <div className="space-y-1 bg-rose-50/70 border border-rose-200 p-3 rounded-xl">
                          <div className="flex items-center space-x-1.5 text-rose-800 text-xs font-bold">
                            <XCircle className="w-3.5 h-3.5 shrink-0" />
                            <span>কেন আপনার উত্তরটি ভুল হয়েছিল (Why Your Selection Was Wrong):</span>
                          </div>
                          <p className="text-xs text-rose-950 leading-relaxed font-medium">
                            {aiMistakeExplanations[q.id].data!.whyChosenIsIncorrect}
                          </p>
                          <p className="text-[11px] text-rose-800/90 leading-relaxed font-sans mt-1">
                            {aiMistakeExplanations[q.id].data!.whyChosenIsIncorrectBn}
                          </p>
                        </div>

                        {/* Correct rule formula */}
                        <div className="space-y-1 bg-emerald-50/70 border border-emerald-200 p-3 rounded-xl">
                          <div className="flex items-center space-x-1.5 text-emerald-800 text-xs font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            <span>সঠিক ব্যাকরণ নিয়ম ও প্রয়োগ (Correct Grammar Pattern):</span>
                          </div>
                          <p className="text-xs text-emerald-950 leading-relaxed font-medium">
                            {aiMistakeExplanations[q.id].data!.correctRuleExplanation}
                          </p>
                          <p className="text-[11px] text-emerald-800/90 leading-relaxed font-sans mt-1">
                            {aiMistakeExplanations[q.id].data!.correctRuleExplanationBn}
                          </p>
                          {aiMistakeExplanations[q.id].data!.keyGrammarRule && (
                            <div className="mt-2 px-2.5 py-1.5 bg-white/80 rounded-lg border border-emerald-300 text-[11px] font-mono font-semibold text-emerald-900">
                              📌 Rule: {aiMistakeExplanations[q.id].data!.keyGrammarRule}
                            </div>
                          )}
                        </div>

                        {/* Contrast Example with speech audio */}
                        {aiMistakeExplanations[q.id].data!.contrastExampleJa && (
                          <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                                <Sparkles className="w-3 h-3 text-amber-500" />
                                <span>সঠিক উদাহরণ বাক্য (Contrast Example):</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  speakJapanese(
                                    aiMistakeExplanations[q.id].data!.contrastExampleJa
                                  )
                                }
                                className="p-1 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-600 hover:text-red-600 transition"
                                title="Listen in Japanese"
                              >
                                <Volume2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <p className="text-xs sm:text-sm font-serif font-bold text-stone-900">
                              {aiMistakeExplanations[q.id].data!.contrastExampleJa}
                            </p>
                            <p className="text-[11px] text-stone-500 font-mono">
                              {aiMistakeExplanations[q.id].data!.contrastExampleRomaji}
                            </p>
                            <p className="text-[11px] text-stone-700">
                              🇬🇧 {aiMistakeExplanations[q.id].data!.contrastExampleEn}
                            </p>
                            <p className="text-[11px] text-stone-700 font-sans">
                              🇧🇩 {aiMistakeExplanations[q.id].data!.contrastExampleBn}
                            </p>
                          </div>
                        )}

                        {/* Sensei Pro Tip */}
                        {aiMistakeExplanations[q.id].data!.senseiProTip && (
                          <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-[11px] text-amber-900 flex items-start gap-2">
                            <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                            <div>
                              <strong className="text-amber-800">Sensei Mnemonic Tip: </strong>
                              {aiMistakeExplanations[q.id].data!.senseiProTip}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {aiMistakeExplanations[q.id]?.error && (
                      <p className="text-[11px] text-rose-600 mt-1 font-semibold">
                        {aiMistakeExplanations[q.id].error}
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit Bar */}
        {!submissionResult && (
          <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-stone-500">
              {answeredCount < totalCount
                ? `You have answered ${answeredCount} of ${totalCount} questions.`
                : 'All questions answered! Ready to submit.'}
            </div>

            <button
              onClick={handleSubmit}
              disabled={isSubmitting || answeredCount === 0}
              className="w-full sm:w-auto px-8 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition-colors shadow-sm disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              <span>{isSubmitting ? 'Evaluating...' : 'Submit Quiz'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Smart Correction Toast Notification from ContentAnalyticsService */}
        {smartRemediationToast && smartRemediationToast.show && (
          <div
            id="smart-correction-toast"
            className="fixed bottom-20 md:bottom-6 right-6 max-w-md bg-stone-900 text-white p-4 rounded-2xl shadow-2xl border border-amber-500/40 z-50 animate-in slide-in-from-bottom-5 duration-200"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div className="space-y-1 text-left flex-1">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                    Smart Correction &bull; {smartRemediationToast.conceptCode}
                  </span>
                </div>
                <p className="text-xs font-semibold text-stone-200">
                  {smartRemediationToast.reasonBn}
                </p>
                <div className="p-2.5 bg-stone-800/80 rounded-xl border border-stone-700 text-[11px] text-amber-200/90 leading-relaxed font-sans">
                  💡 <span className="font-bold text-white">টিপ্স: </span>{smartRemediationToast.suggestionBn}
                </div>
              </div>
              <button
                onClick={() => setSmartRemediationToast(null)}
                className="text-stone-400 hover:text-white p-1 rounded-lg hover:bg-stone-800 transition-colors"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
